from pathlib import Path
import json,gzip,hashlib,sys,datetime,xml.etree.ElementTree as ET,tempfile,shutil,subprocess,os
r=Path('/Users/smzdm/projects/ai_paper');sys.path.insert(0,str(r/'src'))
from ai_value.graph import load,validate
from ai_value.source_results import named_results
sha=lambda b:hashlib.sha256(b).hexdigest()
out=r/'reports/reproducibility/20261021-circulant-hadamard';now=datetime.datetime.now(datetime.timezone.utc).isoformat()
nodes,edges=load(r);v=json.loads(gzip.decompress((r/'reports/graph/knowledge.json.gz').read_bytes()));tree=ET.fromstring(gzip.decompress((r/'reports/graph/knowledge.graphml.gz').read_bytes()));ns={'g':'http://graphml.graphdrawing.org/xmlns'}
assert {n['id'] for n in v['nodes']}==set(nodes)=={n.attrib['id'] for n in tree.findall('.//g:node',ns)}
assert {e['id'] for e in v['edges']}=={e['id'] for e in edges}=={e.attrib['id'] for e in tree.findall('.//g:edge',ns)}
assert len({e['id'] for e in edges})==len(edges)
assert all(e['source'] in nodes and e['target'] in nodes for e in edges)
assert all(e.attrib['source'] in nodes and e.attrib['target'] in nodes for e in tree.findall('.//g:edge',ns))
files={p.name:{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in (r/'reports/graph').iterdir() if p.is_file()}
q=dict(recorded_at=now,core_tests_passed=42,validation=validate(r),full_graph_and_gzip_exports_consistent=True,edge_ids_unique=True,endpoints_valid=True,files=files,browser_visual_check='Not refreshed in this package; viewer code unchanged',local_Lean_or_Comparator=False,remote_CI=False)
(out/'graph-export.json').write_text(json.dumps(q,indent=2)+'\n')
j=json.loads((r/'data/provenance/readings/F-179.json').read_text());idx=json.loads(gzip.decompress((r/j['formal_index']['path']).read_bytes()))
for f in j['read_files']+j['formal_read_files']+idx['local_files']:assert sha((r/f['path']).read_bytes())==f['sha256'],f['path']
analysis=nodes['ANALYSIS-F-179']['properties'];found={}
for p,mapping in analysis['result_ids_by_source'].items():
 for z in named_results((r/p).read_text()):
  id=mapping[z['label']];assert nodes[id]['properties']['natural_label']==z['label'];found[z['label']]=id
assert len(found)==8
assert all(m.startswith(('Lean.','Mathlib.')) or m=='Mathlib' for m in idx['external_modules_not_present'])
old=json.loads(gzip.decompress((r/'data/graph/history/GEN-20261021-036-before.json.gz').read_bytes()))['records']
head=subprocess.run(['git','show','HEAD:data/graph/nodes.jsonl'],cwd=r,capture_output=True,text=True,check=True)
previous={n['id']:n for n in map(json.loads,head.stdout.splitlines())};assert all(previous[n['id']]==n for n in old)
for id in ['APP-076-01','APP-076-02']:assert previous[id]==nodes[id]
receipt=dict(recorded_at=now,natural_files=8,natural_lines=1240,named_bindings=len(found),selected_formal_files=len(j['formal_read_files']),indexed_files=len(idx['local_files']),all_source_hashes_match=True,external_modules=len(idx['external_modules_not_present']),external_modules_only_Lean_or_Mathlib=True,prior_nodes_match_HEAD=len(old),both_existing_F076_cards_unchanged=True,curation_archive_roundtrip=True,scope='Static source/lexical checks; no kernel build or mathematical proof validation')
(out/'source-and-history-integrity.json').write_text(json.dumps(receipt,indent=2)+'\n')
with tempfile.TemporaryDirectory(prefix='ai-paper-cleancirculant-') as td:
 dest=Path(td)
 for directory in ['src','tests','scripts','configs','schemas','data','experiments']:
  if (r/directory).exists():shutil.copytree(r/directory,dest/directory,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
 for n in nodes.values():
  for s in n.get('sources',[]):
   path=s.get('path','')
   if path and not path.startswith('math/'):
    target=dest/path;target.parent.mkdir(parents=True,exist_ok=True)
    if not target.exists():shutil.copy2(r/path,target)
 for d in ['reports/cards','reports/families','reports/failures','state']:(dest/d).mkdir(parents=True,exist_ok=True)
 assert not (dest/'math').exists()
 result=subprocess.run([sys.executable,'scripts/check.py'],cwd=dest,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),capture_output=True,text=True)
 clean=dict(recorded_at=now,upstream_clone_present=False,exit_code=result.returncode,stdout=result.stdout,stderr=result.stderr,cleanup='TemporaryDirectory removed; minimal referenced files, no math clone',remote_CI=False)
 (out/'clean-directory.json').write_text(json.dumps(clean,indent=2)+'\n');assert result.returncode==0,result.stderr[-1000:]
print(json.dumps(dict(nodes=len(nodes),edges=len(edges),canonical_citations=q['validation']['citations_checked'],clean_checks=clean['exit_code'],temporary_copy_removed=True)))
