import hashlib,json,pathlib,urllib.request,datetime
root=pathlib.Path('/private/tmp/ai-paper-WP096')
receipt=[]
cap=10*1024*1024
total=0
def get(name,url):
 global total
 item={'name':name,'url':url,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'ai-paper-research/1.0','Accept':'application/vnd.github+json' if 'api.github.com' in url else '*/*'})
  with urllib.request.urlopen(req,timeout=25) as r:
   b=r.read(min(cap-total,4*1024*1024)+1)
   if len(b)>min(cap-total,4*1024*1024):raise ValueError('response exceeds bounded acquisition cap')
   item.update(final_url=r.url,status=r.status,bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
  total+=len(b);(root/name).write_bytes(b)
 except Exception as e:item.update(error=type(e).__name__+': '+str(e))
 receipt.append(item);(root/'acquisition.json').write_text(json.dumps({'total_bytes':total,'cap':cap,'sources':receipt},ensure_ascii=False,indent=2)+'\n')
 return item
a=get('qepcad-commit.json','https://api.github.com/repos/chriswestbrown/qepcad/commits/master')
if 'sha256' in a:
 j=json.loads((root/'qepcad-commit.json').read_bytes());sha=j['sha'];print('QEPCAD_PIN',sha)
 get('qepcad-tree.json',f'https://api.github.com/repos/chriswestbrown/qepcad/git/trees/{sha}?recursive=1')
get('redlog-rlqe.html','https://www.redlog.eu/documentation/service.php?key=rlqe')
get('redlog-rlgqe.html','https://www.redlog.eu/documentation/service.php?key=rlgqe')
get('redlog-manual.pdf','https://andreasseidl.com/publications/DSS04b.pdf')
get('raglib-home.html','https://safey.perso.lip6.fr/RAGLib/')
get('raglib-distribution.html','https://perso.lip6.fr/Mohab.Safey/RAGLib/distrib.html')
get('gaillard-safey-v2.html','https://arxiv.org/html/2402.07782v2')
print(json.dumps({'total_bytes':total,'sources':[{k:v for k,v in r.items() if k in ['name','bytes','error','sha256']} for r in receipt]},indent=2))
