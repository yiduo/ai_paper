import gzip,hashlib,io,json,pathlib,tarfile,shutil,datetime
R=pathlib.Path('/Users/smzdm/projects/ai_paper');T=pathlib.Path('/private/tmp/ai-paper-WP096');OUT=R/'reports/reproducibility/20261023-symbolic-limit'
def sha(b):return hashlib.sha256(b).hexdigest()
acq=json.loads((T/'acquisition.json').read_text());removed_sources=[]
for x in acq['sources']:
 if 'sha256' not in x:continue
 p=T/x['name'];b=p.read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256']
 removed_sources.append({'name':x['name'],'bytes':len(b),'sha256':sha(b)})
software=R/'data/provenance/tools/qepcad-selected-0f570797-20261023.tar.gz'
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(software.read_bytes())),mode='r:') as tf:
 for x in acq['sources']:
  if x['name'].startswith('qepcad-') and not x['name'].endswith('.json'):
   name=x['name'][len('qepcad-'):].replace('__','/');assert sha(tf.extractfile(name).read())==x['sha256']
own=sorted([p for p in T.iterdir() if p.is_file() and (p.suffix in ['.py','.log'] or p.name=='acquisition.json')])
buf=io.BytesIO();manifest=[]
with tarfile.open(fileobj=buf,mode='w') as tf:
 for p in own:
  b=p.read_bytes();manifest.append({'name':p.name,'bytes':len(b),'sha256':sha(b)})
  info=tarfile.TarInfo(p.name);info.size=len(b);info.mode=0o644;info.mtime=0;tf.addfile(info,io.BytesIO(b))
raw=buf.getvalue();z=gzip.compress(raw,mtime=0);assert gzip.decompress(z)==raw
archive=OUT/'helpers-and-logs.tar.gz';archive.write_bytes(z)
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(archive.read_bytes())),mode='r:') as tf:
 assert set(tf.getnames())=={x['name'] for x in manifest}
 for x in manifest:assert sha(tf.extractfile(x['name']).read())==x['sha256']
allowed={x['name'] for x in removed_sources}|{p.name for p in own}
assert not(T/'no-math-clean').exists()
assert all(p.is_file() and p.name in allowed for p in T.iterdir())
for p in list(T.iterdir()):p.unlink()
T.rmdir()
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'temporary_source_bytes_hash_verified_then_removed':sum(x['bytes'] for x in removed_sources),'temporary_source_files':removed_sources,'own_helper_log_bytes_compressed_verified_then_removed':sum(x['bytes'] for x in manifest),'own_helper_log_members':manifest,'archive':str(archive.relative_to(R)),'archive_gzip_bytes':len(z),'archive_sha256':sha(z),'archive_member_roundtrip_verified':True,'separately_retained_selected_qepcad_documents_gzip_bytes':software.stat().st_size,'clean_directory_removed_bytes':61086750,'temporary_directory_removed':not T.exists(),'no_math_copy_dependency_install_or_github_write':True,'external_fulltext_redistributed':False}
b=(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n').encode();packed=gzip.compress(b,mtime=0);assert gzip.decompress(packed)==b;(OUT/'storage.json.gz').write_bytes(packed)
print(json.dumps({k:v for k,v in receipt.items() if k not in ['temporary_source_files','own_helper_log_members']},indent=2))
