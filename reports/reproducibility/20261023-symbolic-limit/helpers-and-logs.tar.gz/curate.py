"""WP096 source qualification, never a solver benchmark or mathematical proof."""
import copy,datetime,gzip,hashlib,io,json,pathlib,tarfile
R=pathlib.Path('/Users/smzdm/projects/ai_paper')
T=pathlib.Path('/private/tmp/ai-paper-WP096')
NOW=datetime.datetime.now(datetime.timezone.utc).isoformat()
GEN='GEN-20261023-093'
BASE='842a129'
UP='1581d4cbdd69a0faf34b2089614fe2a814316a6a'
PIN='0f57079731afb850d0960f2265f00de8b9e213a0'
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(p,j):
 p=R/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
def pack(p,j):
 b=(json.dumps(j,ensure_ascii=False,indent=2)+'\n').encode();z=gzip.compress(b,mtime=0)
 assert sha(gzip.decompress(z))==sha(b)
 p=R/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z)
 return {'path':str(p.relative_to(R)),'gzip_bytes':len(z),'raw_bytes':len(b),'raw_sha256':sha(b)}

acq=json.loads((T/'acquisition.json').read_text())
assert acq['total_bytes']<=10485760
members=[x for x in acq['sources'] if x['name'].startswith('qepcad-') and not x['name'].endswith('.json')]
assert len(members)==9
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as tf:
 for x in members:
  b=(T/x['name']).read_bytes();assert sha(b)==x['sha256']
  n=x['name'][len('qepcad-'):].replace('__','/')
  info=tarfile.TarInfo(n);info.size=len(b);info.mtime=0;info.mode=0o644;tf.addfile(info,io.BytesIO(b))
raw=buf.getvalue();z=gzip.compress(raw,mtime=0);assert gzip.decompress(z)==raw
archive='data/provenance/tools/qepcad-selected-0f570797-20261023.tar.gz'
(R/archive).write_bytes(z)
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(z)),mode='r:') as tf:
 for x in members:
  name=x['name'][len('qepcad-'):].replace('__','/')
  assert sha(tf.extractfile(name).read())==x['sha256']
archive_info={'path':archive,'sha256':sha(z),'compressed_bytes':len(z),'members':[{**x,'archive_member':x['name'][len('qepcad-'):].replace('__','/'),'raw_lines':len((T/x['name']).read_text().splitlines()),'actually_read':'entire selected document,not implementation/dependency body'} for x in members],'member_roundtrip_sha_verified':True,'license_member':'qesource/LICENSE','execution':False}
paper=next(x for x in acq['sources'] if x['name']=='gaillard-safey-v2.html')
assert b'2402.07782v2' in (T/paper['name']).read_bytes()
findings=[
 {'id':'full_original_qe','evidence':'REDLOG rlqe web documentation;QEPCAD pinned EnterForm/Lifting/Solution','observation':'Existing real-algebra QE accepts quantified polynomial formulas and can return exact quantifier-free sets;for exact algebraic-analytic branches and centre the full moving-witness limit formula is a baseline contract. This is expressibility,not a locally executed independent judge.','boundary':'Arbitrary analytic coefficients are not thereby rational-polynomial inputs. Preserve branch/domain encodings and every epsilon/delta/witness quantifier;do not reuse the jet adapter in the reference.'},
 {'id':'redlog_modes','evidence':'https://www.redlog.eu/documentation/service.php?key=rlqe web body actually read;historical manual rlgqe primary search excerpt only','observation':'rlqe correctness with assumptions is conditional on those assumptions. Virtual substitution has a degree restriction and normally combines with partial CAD;disabling fallback can leave quantifiers. Generic elimination extends assumptions in the historical manual excerpt.','boundary':'Do not accept residual quantified output as QF or remove exceptional centres by unexamined assumptions. Current rlgqe service body was inaccessible;the author-manual PDF failed hostname verification. No modern generic implementation was audited.'},
 {'id':'qepcad_all_cells','evidence':'public_html/B/user/Solution.html whole145rawlines,especially115-118;Lifting.html whole46','observation':'solution-extension T can add projection factors to return a Tarski formula;E returns indexed-root extended language;F deliberately ignores lower-dimensional cells. Lifting documentation describes truth on all cells.','boundary':'F-mode or sample-point equality alone is not full set equivalence. A comparison through symmetric-difference QE must preserve lower-dimensional and exceptional strata;no such computation was run.'},
 {'id':'qepcad_order_and_retries','evidence':'EnterForm.html whole127;Projection.html whole109;regressiontests/README whole47;applicationTestSet whole84','observation':'Variable order,degree,formula splitting and projection choices matter. The projection page explicitly labels itself out of date and describes a possible-error/restart path. Regression README warns textually different formulas may be equivalent. Seven selected regression input blocks use ordinary quantified polynomial formulas.','boundary':'The pinned repository revision is not a claim to a newly released binary. Historical projection advice is not verified current branch behaviour. Charge order search,retries,solution construction and exact equivalence checking;no solver or regression was executed. F/G quantifiers do not automatically express t approaching zero.'},
 {'id':'raglib_interface','evidence':'RAGlib author homepage and distribution page,entire web bodies read','observation':'Documented interfaces decide real feasibility and sample each connected component of polynomial systems. The author distribution page lists release3.4(December2017),Maple/FGb prerequisites and older mixed-system genericity warnings.','boundary':'The dated release page is not a live installation report or assurance all old genericity restrictions persist in3.4. The selected page does not supply joint-limit or sufficient-jet-order certificates. No Maple/FGb/RAGlib install or execution.'},
 {'id':'actual_root_classification_caller','evidence':'Gaillard/Safey El Din2402.07782v2 Introduction Assumptions1,2,Problem1,Theorem1.1;Section4.2 Algorithm2/Th4.9/proof;Section5','observation':'An actual RAGlib consumer samples non-vanishing determinant regions for parametric real-root classification,including camera P3P. Problem1 requires a dense union of regions,not all parameter points. Algorithm2 explicitly excludes w_infinity=0 and minors=0;correctness also assumes a good randomly selected rational basis change.','boundary':'Generically nonempty finite complex fibres are required;regular-sequence/Assumption2 additionally serve complexity,while the practical implementation says it uses only Assumption1. Do not mistake root counts/chambers or this dense-region output for an exact joint upper-limit set,or claim that all boundary data are supplied.'},
 {'id':'published_cost_not_local_cost','evidence':'2402.07782v2 Section5,Table1 and P3P paragraphs','observation':'The authors separately report Hermite matrices,minors,determinants and sample-point times on Xeon6244 with1.5TB RAM. In the general5parameter P3P example,computing sample points outside the discriminant is explicitly a further step.','boundary':'Published timings concern another algorithm/task/platform,not APP05801 full cost or local replication. Do not call determinant generation full classification or borrow those speedups. Adaptive Puiseux/Newton and certified Taylor remain unimplemented comparison obligations,not measured losers.'},
 {'id':'certificate_and_caller_gap','evidence':'All three selected projects and original APP05801 conditional plan','observation':'Within selected primary scopes,no actual caller batch was established that requests the precise moving-witness joint-limit output and provides or budgets discovery/verification of all source slack,fixed-fibre-distance,inverse-scale,remainder and sufficient-order certificates.','boundary':'This bounded absence is not global nonexistence,formal rejection,source theorem error or a failed performance experiment. No admitted workload,no preregistered experiment and no initial-check credit.'}
]
ledger={
 'work_package':'WP-096','generation_id':GEN,'recorded_at':NOW,'project_base_commit':BASE,'upstream_commit':UP,'candidate_id':'APP-058-01',
 'source_projects_budget':3,'source_projects_examined':['REDLOG','QEPCAD B','RAGlib,including a documented paper consumer'],
 'download_limit_bytes':10485760,'download_total_bytes':acq['total_bytes'],'acquisition_receipts':acq['sources'],
 'retained_selected_software_documents':archive_info,
 'actual_source_scopes':[
  {'project':'REDLOG','url':'https://www.redlog.eu/documentation/service.php?key=rlqe','read':'Full web-tool rendered rlqe body;not local direct body','local_byte_content_status':'Two direct37byte HTML skeletons are acquisition failures for content;their hashes do not identify documentation prose','generic_read':'Historical original manual search excerpt,not full body/current implementation','generic_primary_url':'https://andreasseidl.com/publications/DSS04b.pdf'},
  {'project':'QEPCAD B','repository':'https://github.com/chriswestbrown/qepcad','commit':PIN,'commit_date':'2021-03-09T17:59:52Z','selected_documents':9,'selected_document_raw_lines':sum(m['raw_lines'] for m in archive_info['members']),'scope':'Full bodies of selected README,input/solution/projection/lifting docs,regression README/application input and license;not C/C++ proof or dependency audit','actual_application_input_blocks':7,'binary_run':False},
  {'project':'RAGlib','url':'https://safey.perso.lip6.fr/RAGLib/','distribution_url':'https://perso.lip6.fr/Mohab.Safey/RAGLib/distrib.html','read':'Both whole web-tool rendered pages,including dated release3.4 and historical interface changes;no local original bytes obtained','software_version_claim':'Author release-page list only,not latest package/binary verified'},
  {'project':'RAGlib actual consumer','url':paper['url'],'source_revision':'2402.07782v2(2025-01-24)','sha256':paper['sha256'],'local_acquired_bytes':paper['bytes'],'read':'Introduction including Assumptions1/2,Problem1,Theorem1.1;Section4.2 Lemmas4.7/4.8,Algorithm2,Th4.9 and proof;Section5/Table1/P3P. Not all Sections2,3,4.1,4.3 or full historical proof closure.','local_fulltext_retention':'Temporary HTML removed after acquisition/hash verification;no full paper redistribution'}
 ],
 'findings':findings,
 'runtime_observation':{'scope':'Current PATH only,not full-machine inventory','found':{'redcsl':None,'reduce':None,'qepcad':None,'Maple':None,'wolframscript':None},'dependency_installs':0},
 'admission':{'related_actual_use_found':True,'exact_joint_limit_caller_admitted':False,'representative_batch_frozen':False,'all_source_certificates_available':False,'certificate_discovery_and_verification_cost_established':False,'independent_full_original_family_judge_executed':False,'adaptive_puiseux_baseline_executed':False,'same_order_certified_taylor_baseline_executed':False,'full_cost_comparison_executed':False,'decision':'not_admitted_after_bounded_qualification'},
 'hypothesis_and_plan_changed':False,'new_candidate_count':0,'new_initial_check_count':0,'new_numerical_or_symbolic_run':False,'human_review':False,'second_provider':False,'full_family_complete':False,
 'retrieval_limits':['Initial normal shell DNS unavailable;bounded verified-TLS escalation used.','USNA direct web403;author public GitHub mirror pinned instead.','REDLOG37byte HTTP200 skeletons are not full content;rlqe web cache body and historical generic excerpt distinguished.','Author manual TLS hostname mismatch and web timeout retained;no insecure TLS workaround.','RAGlib direct TLS handshakes timed out;web primary bodies read,local bytes/hash unknown.','Paper2402.07782v2 was HTML;no PDF acquisition/render or pixel inspection claimed.'],
 'decision':'Keep APP05801 near/待定/候选 with original prediction and empty runs;lower immediate implementation priority. Stop at3projects and redirect WP097 to low-coverage group theory F256 complete current natural sources. No global absence or formal否定.',
 'publication':{'github_write':False,'cadence':'local routine work;meaningful milestone publication batches only','official_math_excluded':True,'last_verified_public_snapshot':'f0c3ddc05b4e8de3bb104216e2eb8ffa5d7875a0'}
}
lp='data/provenance/demand/F-058-symbolic-limit-contracts.json';dump(lp,ledger)
policy='data/provenance/research-at-generation-093.json';(R/policy).write_bytes((R/'configs/research.json').read_bytes())
def source(path,locator):return {'path':path,'sha256':sha((R/path).read_bytes()),'locator':locator,'commit':None}
ls=source(lp,'WP096 three bounded primary projects;full-set versus dense-region output,actual RAGlib caller,source certificates and complete-cost gaps;no experiment')
ps=source(policy,'Frozen research and reduced-publication-cadence policy')
ats=source(archive,'Nine selected unmodified QEPCAD documents/input/license;member hashes verified;not executable build')
def external(url,locator,**kw):return {'url':url,'locator':locator,**kw}
new=[]
def node(id,kind,title,props=None,sources=None):
 p={'title':title,'family_ids':['F-058'],'model_generation_id':GEN,'credibility':'unknown','dependency_closure_complete':False};p.update(props or {})
 n={'id':id,'kind':kind,'version':1,'created_at':NOW,'evidence_status':'source_content_checked','properties':p,'sources':sources or [ls]};new.append(n);return n
node(GEN,'generation','F058 symbolic caller,complete-set judge and cost qualification',{'provider':'OpenAI','model':'Current user-selected session;exact backend unknown','project_base_commit':BASE,'human_review':None,'independent_second_provider':None,'task':'Bounded source qualification,not application validation or independent theorem review'},[ls,ps])
node('LIT-058-REDLOG-RLQE','literature','REDLOG exact and assumption-restricted quantifier-elimination interface',{'selected_only':True,'original_link':'https://www.redlog.eu/documentation/service.php?key=rlqe','source_scope':ledger['actual_source_scopes'][0],'content_verified':True},[ls,external('https://www.redlog.eu/documentation/service.php?key=rlqe','Full web rendered rlqe body on2026-10-23;direct37byte skeleton is not body identity',content_checked=True),external('https://andreasseidl.com/publications/DSS04b.pdf','Historical rlgqe original search excerpt only;fullPDF unavailable due hostname mismatch;not current implementation verification',content_checked=False)])
qsrc=[ls,ats]
for m in archive_info['members']:
 if any(w in m['archive_member'] for w in ['EnterForm','Solution','Projection','Lifting']):qsrc.append(external(m['url'],f"Entire selected {m['raw_lines']} raw lines;source revision pinned,not runtime behaviour",sha256=m['sha256'],source_revision=PIN,content_checked=True))
node('LIT-058-QEPCAD-INTERFACE','literature','Pinned QEPCAD B formula,all-cell and solution-mode documents',{'source_commit':PIN,'original_link':f'https://github.com/chriswestbrown/qepcad/tree/{PIN}','selected_only':True,'source_scope':ledger['actual_source_scopes'][1],'content_verified':True},qsrc)
node('LIT-058-RAGLIB-INTERFACE','literature','RAGlib feasibility and connected-component sample interfaces',{'selected_only':True,'content_verified':True,'original_link':'https://safey.perso.lip6.fr/RAGLib/','source_scope':ledger['actual_source_scopes'][2]},[ls,external('https://safey.perso.lip6.fr/RAGLib/','Entire author web homepage;local byte identity unknown',content_checked=True),external('https://perso.lip6.fr/Mohab.Safey/RAGLib/distrib.html','Entire dated distribution page;3.4 listed December2017;not live binary or inherited restriction verification',content_checked=True)])
node('LIT-058-PARAMETRIC-ROOT-V2','literature','Gaillard/Safey El Din parametric real-root classification v2,selected ranges',{'selected_only':True,'content_verified':True,'original_link':paper['url'],'arxiv_id':'2402.07782','doi':'10.1145/3666000.3669718','source_revision':'2402.07782v2','source_scope':ledger['actual_source_scopes'][3]['read'],'scope_boundary':'Generically finite complex fibres and dense parameter-region coverage;not all-strata joint upper limit or full proof review'},[ls,external(paper['url'],ledger['actual_source_scopes'][3]['read'],source_revision='2402.07782v2',sha256=paper['sha256'],content_checked=True)])
node('PROB-058-RAGLIB-P3P','problem','Actual parametric root classification and camera P3P consumer',{'input':'Rational polynomial equalities/strict inequalities,generically nonempty finite complex fibres,parameters','output':'Semialgebraic regions with invariant root counts,dense union under Problem1;sampling uses RAGlib','scope_boundary':'Related actual consumer;not a qualified moving-witness joint-limit workload. General5parameter P3P sampling remains a further step in selected publication.'})
node('PART-058-ORIGINAL-FAMILY-QE','method','Independent full original-family QE comparator contract',{'input':'Full epsilon/delta moving-witness formula with exact algebraic centre,certified algebraic-analytic branch and domain encoding','output':'Exact original joint upper-limit set intersect reporting window,including all lower-dimensional strata','conditions':['Judge independent of jet adapter','No arbitrary analytic-to-polynomial substitution','Normal complete-QE mode,no residual quantifiers or unchecked parameter assumptions','No F full-dimensional-only solution mode'],'cannot_transfer':'Expressibility and documentation do not establish local executable judgement or speed;all preprocessing/solver/equivalence costs charged'})
node('PART-058-BOUNDARY-COMPLETE-OUTPUT','method','All-strata exact-set comparison requirement',{'input':'Candidate formula and independent original-family formula over same reporting window','output':'Exact empty symmetric difference,not equality on samples or dense regions','conditions':['Preserve strict inequalities,empty fibres,branch loci and lower-dimensional components','Do not restrict witnesses to reporting window without separately redefining target'],'cannot_transfer':'No such exact comparison implemented or executed;root-count chambers are a different output contract'})
node('PART-058-FULL-COST-GATE','method','Account for certificates,old preprocessing,retries and exact comparison',{'input':'Actually admitted representative workload with exact premise certificates and independent judge','output':'Full comparable cost including discovery,verification,setup,failed attempts,old optimizations and final set construction','conditions':['Same certificates and budgets for strongest old methods','Freeze amortization,failures,coverage,denominators and timeouts before outputs'],'cannot_transfer':'Published other-task timings do not imply local speedup;no certified order discovery algorithm supplied'})
for id,title,ids in [
 ('CHECK-058-JOINT-CALLER-GAP','Related caller does not establish exact joint-limit admission',['raglib_interface','actual_root_classification_caller','certificate_and_caller_gap']),
 ('CHECK-058-BOUNDARY-JUDGE-GAP','Selected dense/full-dimensional modes do not supply full-set judge',['full_original_qe','redlog_modes','qepcad_all_cells','actual_root_classification_caller']),
 ('CHECK-058-CERTIFICATE-COST-GAP','Effective certificates and full-cost baseline not yet supplied',['qepcad_order_and_retries','published_cost_not_local_cost','certificate_and_caller_gap'])]:
 node(id,'review',title,{'review_type':'Same-session original source qualification,not human or independent-provider review','new_application_run':False,'finding_ids':ids,'findings':[f for f in findings if f['id'] in ids],'decision':'Keep candidate pending;not admitted for experiment,no formal rejection'})
node('XPL-058-SYMBOLIC-QUALIFICATION','exploration','Three-project symbolic joint-limit qualification',{'candidate_id':'APP-058-01','source_project_count':3,'findings':findings,'new_candidate_count':0,'new_initial_check_count':0,'new_application_run':False,'decision':ledger['decision']})

nf=R/'data/graph/nodes.jsonl';ef=R/'data/graph/edges.jsonl'
old_lines=nf.read_text().splitlines();old_nodes={json.loads(l)['id']:json.loads(l) for l in old_lines};old_edge_bytes=ef.read_bytes()
assert not(set(n['id'] for n in new)&set(old_nodes))
old=copy.deepcopy(old_nodes['APP-058-01']);candidate=copy.deepcopy(old)
prior=pack('data/graph/history/GEN093-APP05801-before.json.gz',old)
candidate.update(version=old['version']+1,updated_at=NOW,updated_by_generation_id=GEN,prior_version_archive=prior['path'])
p=candidate['properties'];p.update(demand_audit=lp,demand_status='related_actual_root_classification_use_found_exact_joint_limit_not_admitted',priority_reason='Retain conditional near candidate;lower immediate implementation priority after bounded three-project qualification:source certificates,actual joint-limit caller and executable all-strata judge/full cost remain unestablished')
p['limitations'].append('WP096 primary REDLOG/QEPCAD/RAGlib qualification:generic or full-dimensional-only solutions omit exceptional/lower-dimensional data;actual RAGlib root-count consumer does not supply the requested joint-limit interface. No complete certificate pipeline or full-cost comparison established in selected scopes;not global absence or source theorem rejection.')
p['summary'].update(demand_audit=lp,status='conditional_not_admitted_after_three_project_qualification',actual_related_consumer=True,exact_joint_limit_caller_admitted=False,independent_original_family_judge_run=False)
candidate['sources'].append(ls)
for k in ['prediction','test_spec','run_ids','dedup_key','source_ids','part_ids','full_joint_limit_quantifier_formula','application_result','workflow','theoretical_grade']:
 assert candidate['properties'][k]==old['properties'][k],k
edges=[]
def edge(a,rel,b,loc):
 e={'id':'E-'+sha(f'{a}|{rel}|{b}'.encode())[:16].upper(),'source':a,'relation':rel,'target':b,'version':1,'created_at':NOW,'evidence_status':'source_content_checked','source_locator':loc,'source_commit':UP};edges.append(e)
for n in new:
 if n['id']!=GEN:edge(n['id'],'generated_by',GEN,'WP096 source qualification;no external experiment or human review')
edge('PROB-058-RAGLIB-P3P','derived_from','LIT-058-PARAMETRIC-ROOT-V2','Actual Section5 RAGlib sampling/P3P role;not full exact joint-limit admission')
edge('PROB-058-RAGLIB-P3P','uses','LIT-058-RAGLIB-INTERFACE','Actual paper names RAGlib for sample points;all software dependencies not audited')
for lid in ['LIT-058-REDLOG-RLQE','LIT-058-QEPCAD-INTERFACE']:edge('PART-058-ORIGINAL-FAMILY-QE','derived_from',lid,'Documented old polynomial-QE interface;not new finite-jet algorithm or locally executed judge')
edge('PART-058-BOUNDARY-COMPLETE-OUTPUT','derived_from','LIT-058-QEPCAD-INTERFACE','Full-dimensional-only mode unsuitable for all-strata equality')
for c,targets in {
 'CHECK-058-JOINT-CALLER-GAP':['PROB-058-RAGLIB-P3P','LIT-058-RAGLIB-INTERFACE'],
 'CHECK-058-BOUNDARY-JUDGE-GAP':['PART-058-ORIGINAL-FAMILY-QE','PART-058-BOUNDARY-COMPLETE-OUTPUT','LIT-058-PARAMETRIC-ROOT-V2'],
 'CHECK-058-CERTIFICATE-COST-GAP':['PART-058-FULL-COST-GATE','LIT-058-QEPCAD-INTERFACE','LIT-058-PARAMETRIC-ROOT-V2']}.items():
 for target in targets:edge(c,'derived_from',target,'Bounded functional qualification evidence,not mathematical truth grading')
 edge('APP-058-01','depends_on',c,'Unresolved functional admission gate;changes require candidate review,not theorem rejection')
for m in ['PART-058-ORIGINAL-FAMILY-QE','PART-058-FULL-COST-GATE','PART-058-BOUNDARY-COMPLETE-OUTPUT']:edge('APP-058-01','compared_with',m,'Comparison obligation before a separately preregistered experiment;not run')
edge('APP-058-01','explored_in','XPL-058-SYMBOLIC-QUALIFICATION','Exploration context is not a mandatory global source proof input')
edge('XPL-058-SYMBOLIC-QUALIFICATION','examines','PROB-058-RAGLIB-P3P','Related primary caller only;exact candidate not admitted')
seen={json.loads(l)['id'] for l in old_edge_bytes.decode().splitlines() if l.strip()}
assert not(seen&set(e['id'] for e in edges))
nf.write_text('\n'.join(json.dumps(candidate,ensure_ascii=False,sort_keys=True) if json.loads(l)['id']=='APP-058-01' else l for l in old_lines)+'\n'+''.join(json.dumps(n,ensure_ascii=False,sort_keys=True)+'\n' for n in new))
with ef.open('a') as f:
 for e in edges:f.write(json.dumps(e,ensure_ascii=False,sort_keys=True)+'\n')
after={json.loads(l)['id']:json.loads(l) for l in nf.read_text().splitlines()}
assert all(after[k]==v for k,v in old_nodes.items() if k!='APP-058-01')
assert ef.read_bytes().startswith(old_edge_bytes)
quality={'at':NOW,'generation':GEN,'old_canonical_records':len(old_nodes),'unchanged_old_records':len(old_nodes)-1,'versioned_candidates':1,'new_records':len(new),'new_explicit_edges':len(edges),'all_old_edges_exact':True,'original_candidate_prediction_plan_runs_and_scope_exact':True,'prior_candidate_archive':prior,'software_archive':archive_info,'download_total_bytes':acq['total_bytes'],'no_benchmark_no_install_no_github_write':True}
dump('reports/reproducibility/20261023-symbolic-limit/curation.json',quality)
dump('state/reading-progress/WP-096.json',{'work_package':'WP-096','status':'canonical_source_qualification_complete_qa_pending','started_at':'2026-10-23T02:24:01.512499+00:00','updated_at':NOW,'project_base_commit':BASE,'generation_id':GEN,'input_candidate':'APP-058-01','actual_projects_read':ledger['actual_source_scopes'],'source_limit_projects':3,'source_projects_examined':3,'download_cap_bytes':10485760,'new_download_bytes':acq['total_bytes'],'numeric_or_symbolic_benchmark_started':False,'actual_caller_admitted':False,'ledger':lp,'new_records':len(new),'new_explicit_edges':len(edges),'github_write':False,'remaining':['Core/fullgraph/source/impact/export/no-math clean checks','Compress own evidence/logs and remove verified temporary source bytes','Close WP096 and start low-coverage WP097 F256 actual body reading,not algorithm claims from title']})
print(json.dumps({'new_records':len(new),'new_explicit_edges':len(edges),'download_bytes':acq['total_bytes'],'software_archive_gzip_bytes':len(z),'actual_qepcad_selected_raw_lines':ledger['actual_source_scopes'][1]['selected_document_raw_lines'],'ledger_sha256':ls['sha256']},indent=2))
