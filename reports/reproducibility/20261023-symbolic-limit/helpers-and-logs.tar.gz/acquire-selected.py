import pathlib,json
root=pathlib.Path('/private/tmp/ai-paper-WP096')
exec((root/'acquire.py').read_text().split("a=get('qepcad-commit.json'")[0])
old=json.loads((root/'acquisition.json').read_text())
receipt=old['sources'];total=old['total_bytes']
sha=json.loads((root/'qepcad-commit.json').read_text())['sha']
paths=['README','qesource/README','qesource/LICENSE','public_html/B/user/EnterForm.html','public_html/B/user/Solution.html','public_html/B/user/Projection.html','public_html/B/user/Lifting.html','regressiontests/README','regressiontests/applicationTestSet']
for path in paths:
 get('qepcad-'+path.replace('/','__'),f'https://raw.githubusercontent.com/chriswestbrown/qepcad/{sha}/{path}')
print(json.dumps({'total_bytes':total,'new_members':len(paths),'successful_new_members':sum('sha256' in x for x in receipt[-len(paths):])},indent=2))
