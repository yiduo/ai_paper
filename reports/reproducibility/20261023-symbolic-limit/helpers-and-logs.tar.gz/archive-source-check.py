import pathlib,json,gzip,hashlib
R=pathlib.Path('/Users/smzdm/projects/ai_paper');rows=[]
for p in sorted((R/'experiments/runs').glob('*/manifest.json')):
 m=json.loads(p.read_text());j=json.loads(gzip.decompress((p.parent/m['source_snapshot']).read_bytes()))
 assert set(m['inputs'])==set(j),(p,'snapshot member set')
 for name,text in j.items():
  assert isinstance(text,str),(p,name)
  assert hashlib.sha256(text.encode()).hexdigest()==m['inputs'][name],(p,name,'source member hash')
 rows.append({'run_id':m['run_id'],'verified_source_members':len(j),'snapshot_members_and_input_hashes_exact':True,'scientific_replay':False})
b=(json.dumps({'archives':len(rows),'source_members':sum(x['verified_source_members'] for x in rows),'rows':rows},ensure_ascii=False,indent=2)+'\n').encode();z=gzip.compress(b,mtime=0);assert gzip.decompress(z)==b;(R/'reports/reproducibility/20261023-symbolic-limit/archive-source-members.json.gz').write_bytes(z)
print(json.dumps({'archives':len(rows),'source_members':sum(x['verified_source_members'] for x in rows)}))
