import gzip,hashlib,io,json,pathlib,subprocess,sys,tarfile,xml.etree.ElementTree as ET
R=pathlib.Path('/Users/smzdm/projects/ai_paper');T=pathlib.Path('/private/tmp/ai-paper-WP096');OUT=R/'reports/reproducibility/20261023-symbolic-limit'
sys.path.insert(0,str(R/'src'))
from ai_value.graph import load,affected_nodes,theoretical_grade
from ai_value.knowledge import export
def sha(b):return hashlib.sha256(b).hexdigest()
def write(name,j):
 b=(json.dumps(j,ensure_ascii=False,indent=2)+'\n').encode();z=gzip.compress(b,mtime=0);assert gzip.decompress(z)==b;(OUT/name).write_bytes(z)
nodes,edges=load(R)
cases=[]
def check(name,seed,yes,no):
 hit=affected_nodes(nodes,edges,set(seed));assert set(yes)<=hit,(name,'missing',set(yes)-hit);assert not(set(no)&hit),(name,'false',set(no)&hit)
 cases.append({'name':name,'changed':seed,'expected_review':yes,'expected_unaffected':no,'affected':sorted(hit),'pass':True})
u='CLM-058-U-THM-MAIN';b='CLM-058-B-THM-MAIN';app='APP-058-01'
check('old_qe_document_change_requires_candidate_qualification_refresh',['LIT-058-QEPCAD-INTERFACE'],[app,'CHECK-058-BOUNDARY-JUDGE-GAP'],[u,b])
check('raglib_actual_caller_change_requires_qualification_refresh',['LIT-058-RAGLIB-INTERFACE'],[app,'CHECK-058-JOINT-CALLER-GAP'],[u,b])
check('dense_root_output_cannot_silently_supply_joint_limit',['LIT-058-PARAMETRIC-ROOT-V2'],[app,'CHECK-058-BOUNDARY-JUDGE-GAP'],[u,b])
check('certificate_cost_gate_is_real_admission_prerequisite',['PART-058-FULL-COST-GATE'],[app,'CHECK-058-CERTIFICATE-COST-GAP'],[u,b])
check('local_source_method_change_requires_candidate_refresh',['CLM-058-U-PREP-FINITE-JET-SPECIALIZATION'],[app],[])
check('whole_bounded_main_not_a_local_candidate_proof_input',[b],[],[app])
check('classification_main_not_a_local_candidate_proof_input',[u],[],[app])
check('exploration_context_not_mandatory_proof_chain',['XPL-058-SYMBOLIC-QUALIFICATION'],[],[app,u,b])
assert theoretical_grade(nodes,edges,app)=='unknown'
write('impact.json.gz',{'cases':cases,'count':len(cases),'candidate_grade':'unknown','meaning':'Review routing only;no theorem refutation,proof certification or human review'})
ex=export(R)
jn=json.loads(gzip.decompress((R/'reports/graph/knowledge.json.gz').read_bytes()))
assert {n['id']:n for n in jn['nodes']}==nodes
assert jn['edges']==edges
tree=ET.fromstring(gzip.decompress((R/'reports/graph/knowledge.graphml.gz').read_bytes()));ns={'g':'http://graphml.graphdrawing.org/xmlns'}
gn={n.attrib['id']:json.loads(next(d.text for d in n if d.attrib.get('key')=='properties')) for n in tree.findall('.//g:node',ns)}
ge={e.attrib['id']:json.loads(next(d.text for d in e if d.attrib.get('key')=='evidence')) for e in tree.findall('.//g:edge',ns)}
assert gn==nodes;assert ge=={e['id']:e for e in edges}
write('exports.json.gz',{'export':ex,'json_full_node_edge_exact':True,'graphml_full_node_edge_exact':True,'nodes':len(nodes),'edges':len(edges)})
archives=[]
for p in sorted((R/'experiments/runs').glob('*/manifest.json')):
 m=json.loads(p.read_text());folder=p.parent;checked=[]
 for name,expected in m['outputs'].items():
  raw=(folder/name).read_bytes();assert sha(raw)==expected,(p,name)
  if name.endswith('.gz'):gzip.decompress(raw)
  checked.append(name)
 for name,desc in m.get('compressed_payloads',{}).items():
  raw=gzip.decompress((folder/name).read_bytes());assert sha(raw)==desc['uncompressed_sha256'],(p,name)
 snap=m.get('source_snapshot')
 if snap:
  j=json.loads(gzip.decompress((folder/snap).read_bytes()))
  # Snapshot schemas vary by experiment;the manifest output digest and gzip
  # integrity are checked here. No fabricated cross-schema source replay.
 archives.append({'run_id':m['run_id'],'outputs_checked':checked,'compressed_payload_roundtrip':True,'scientific_replay':False})
write('archives.json.gz',{'count':len(archives),'archives':archives,'reason_no_replay':'No experimental source/specification/data/comparator change in WP096;archive integrity is not application validation.'})
old=json.loads(gzip.decompress((R/'data/graph/history/GEN093-APP05801-before.json.gz').read_bytes()))
cur=nodes[app]
for key in ['prediction','test_spec','run_ids','dedup_key','source_ids','part_ids','full_joint_limit_quantifier_formula','application_result','workflow','theoretical_grade']:assert old['properties'][key]==cur['properties'][key]
canon=[json.loads(l) for l in (R/'data/graph/nodes.jsonl').read_text().splitlines()]
before=subprocess.check_output(['git','show','842a129:data/graph/nodes.jsonl'],cwd=R).decode().splitlines();bm={json.loads(l)['id']:json.loads(l) for l in before};am={n['id']:n for n in canon}
assert all(am[k]==n for k,n in bm.items() if k!=app)
old_edges=subprocess.check_output(['git','show','842a129:data/graph/edges.jsonl'],cwd=R);assert (R/'data/graph/edges.jsonl').read_bytes().startswith(old_edges)
assert (R/'experiments/plans/APP-058-01-conditional.json').read_bytes()==subprocess.check_output(['git','show','842a129:experiments/plans/APP-058-01-conditional.json'],cwd=R)
assert (R/'data/graph/reading_coverage.json').read_bytes()==subprocess.check_output(['git','show','842a129:data/graph/reading_coverage.json'],cwd=R)
write('canonical-preservation.json.gz',{'old_records_exact_other_than_versioned_candidate':len(bm)-1,'candidate_prior_exact':old==bm[app],'new_canonical_records':len(am)-len(bm),'all_old_edges_exact':True,'original_candidate_fields_exact':True,'original_conditional_plan_bytes_exact':True,'reading_coverage_bytes_exact':True,'human_reviews':0,'cross_provider_reviews':0,'new_application_experiments':0})
print(json.dumps({'nodes':len(nodes),'edges':len(edges),'canonical_records':len(canon),'impact_cases':len(cases),'archives':len(archives),'preservation':True},indent=2))
