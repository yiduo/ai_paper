import json,gzip,hashlib,pathlib,sys,subprocess,xml.etree.ElementTree as ET
R=pathlib.Path('/Users/smzdm/projects/ai_paper');T=pathlib.Path('/private/tmp/ai-paper-WP101');OUT=R/'reports/reproducibility/20261023-finitistic';sys.path.insert(0,str(R/'src'))
from ai_value.graph import load,affected_nodes,theoretical_grade
from ai_value.knowledge import export
def sha(b):return hashlib.sha256(b).hexdigest()
def write(n,j):
 b=(json.dumps(j,ensure_ascii=False,indent=2)+'\n').encode();z=gzip.compress(b,mtime=0);assert gzip.decompress(z)==b;(OUT/n).write_bytes(z)
nodes,edges=load(R);cases=[];main='CLM-198-THM-MAIN';asym='CLM-198-COR-LEFT-RIGHT-ASYMMETRY';gate='PART-198-CONCRETE-FIXTURE-GATE'
def check(n,seed,yes,no):
 hit=affected_nodes(nodes,edges,set(seed));assert set(yes)<=hit,(n,'missing',set(yes)-hit);assert not(set(no)&hit),(n,'false',set(no)&hit);cases.append({'name':n,'changed':seed,'expected_review':yes,'expected_unaffected':no,'affected':sorted(hit),'pass':True})
check('finite_quotient_selection_actual_main',['CLM-198-LEM-FINITE-CENTRAL-QUOTIENTS'],[main,asym,gate],['CLM-196-THM-MAIN'])
check('generic_realization_required',['CLM-198-THM-REALIZATION'],[main,asym,'CLM-198-UNLABELLED-ITERATION'],['OLD-198-MY-DERIVED-PD'])
check('nonflat_bar_required',['CLM-198-PROP-BAR-SPLITTING'],['CLM-198-COR-PD-DETECTION',main],['CLM-198-LEM-GROUP-FINITE-PRESENTATION'])
check('ordinary_simulation_required',['CLM-198-PROP-ORDINARY-SIMULATION'],[main],['CLM-198-PROP-LIFTED-DIAGRAM'])
check('Cummings_only_auxiliary',['LIT-198-CUMMINGS2024'],[asym,'CHECK-198-AUXILIARY-SIDES'],[main,gate])
check('recursive_FGR_gap_explicit',['LIT-198-FGR1975'],[asym],[main])
check('Rickard_side_transport',['OLD-198-RICKARD-GENERATION'],[asym],[main])
check('old_MY_stronger_formula_context',['OLD-198-MY-DERIVED-PD'],['CHECK-198-OLD-TRANSFER-SUFFICIENT'],[main,asym])
check('old_NRS_context_not_blackbox',['OLD-198-NRS-FINITE-ENCODING'],[],[main,asym])
check('internal_characteristic_two_companion_context',['P-ba058fe207bc26ec'],[],[main,asym])
check('originalA_side_not_auxiliaryLambda',['PART-198-LEFT-RIGHT-TRANSPORT'],[asym],[main])
check('unlabelled_corollary_not_faked_main_premise',['CLM-198-UNLABELLED-ITERATION'],[],[main])
check('F196_old_required_history_preserved',['OLD-196-HATCHER-HUREWICZ-MAP'],['CLM-196-THM-MAIN'],[main])
check('F256_actual_map_gate_preserved',['LIT-256-GAP-FP-INTERFACE'],['APP-256-01'],[main])
assert theoretical_grade(nodes,edges,main)=='unknown' and theoretical_grade(nodes,edges,asym)=='unknown'
write('impact.json.gz',{'cases':cases,'count':len(cases),'full_main_and_auxiliary_grades':'unknown','meaning':'Review routing,not mathematical approval'})
ex=export(R);j=json.loads(gzip.decompress((R/'reports/graph/knowledge.json.gz').read_bytes()));assert {n['id']:n for n in j['nodes']}==nodes and j['edges']==edges
tree=ET.fromstring(gzip.decompress((R/'reports/graph/knowledge.graphml.gz').read_bytes()));ns={'g':'http://graphml.graphdrawing.org/xmlns'}
gn={n.attrib['id']:json.loads(next(d.text for d in n if d.attrib.get('key')=='properties')) for n in tree.findall('.//g:node',ns)};ge={n.attrib['id']:json.loads(next(d.text for d in n if d.attrib.get('key')=='evidence')) for n in tree.findall('.//g:edge',ns)};assert gn==nodes and ge=={e['id']:e for e in edges}
write('exports.json.gz',{'export':ex,'json_full_nodes_edges_exact':True,'graphml_full_nodes_edges_exact':True})
archives=[];members=0
for p in sorted((R/'experiments/runs').glob('*/manifest.json')):
 m=json.loads(p.read_text())
 for name,h in m['outputs'].items():
  b=(p.parent/name).read_bytes();assert sha(b)==h
  if name.endswith('.gz'):gzip.decompress(b)
 for name,d in m.get('compressed_payloads',{}).items():assert sha(gzip.decompress((p.parent/name).read_bytes()))==d['uncompressed_sha256']
 s=json.loads(gzip.decompress((p.parent/m['source_snapshot']).read_bytes()));assert set(s)==set(m['inputs']);assert all(isinstance(t,str) and sha(t.encode())==m['inputs'][n] for n,t in s.items());members+=len(s)
 archives.append({'run_id':m['run_id'],'source_members':len(s),'all_output_and_decompressed_hashes_verified':True,'scientific_replay':False})
write('archives.json.gz',{'archives':archives,'count':len(archives),'source_members':members,'reason_no_replay':'No experimental code/spec/data/comparator changes;WP100 original-history reading not application validation'})
oldraw=subprocess.check_output(['git','show','195f674:data/graph/nodes.jsonl'],cwd=R);olded=subprocess.check_output(['git','show','195f674:data/graph/edges.jsonl'],cwd=R)
oldlines={json.loads(l)['id']:l for l in oldraw.splitlines()};newlines={json.loads(l)['id']:l for l in (R/'data/graph/nodes.jsonl').read_bytes().splitlines()};old={i:json.loads(l) for i,l in oldlines.items()};new={i:json.loads(l) for i,l in newlines.items()}
hist=json.loads(gzip.decompress((R/'data/graph/history/GEN098-code-citation-before.json.gz').read_bytes()));priors=hist['records'];changed={n['id'] for n in priors};assert len(changed)==3 and all(n==old[n['id']] for n in priors)
assert all(newlines[i]==l for i,l in oldlines.items() if i not in changed);assert all(new[i]['version']==old[i]['version']+1 for i in changed)
for x in hist['snapshots'].values():
 b=gzip.decompress((R/x['path']).read_bytes());assert sha(b)==x['uncompressed_sha256'];assert b==subprocess.check_output(['git','show','195f674:'+x['original_path']],cwd=R)
assert len(old)==4206 and len(new)-len(old)==65 and (R/'data/graph/edges.jsonl').read_bytes().startswith(olded)
assert all(new[i]==n for i,n in old.items() if n['kind']=='connection')
assert not subprocess.check_output(['git','diff','--name-only','195f674','--','experiments'],cwd=R,text=True).strip()
write('canonical-preservation.json.gz',{'base':'195f674','old_other_records_byte_exact':len(old)-len(changed),'exact_prior_records_archived':sorted(changed),'old_code_snapshots_decompressed_hashes_and_git_bytes_exact':True,'all_old_edge_bytes_prefix_exact':True,'all_old_candidates_and_all_experiments_exact':True,'new_records':65,'new_application_runs':0})
ledger=json.loads((R/'data/provenance/readings/F-198.json').read_text())
for f in ledger['read_files']+ledger['formal_actual_files']:assert sha((R/f['path']).read_bytes())==f['sha256']
for h in ledger['historical_works'].values():assert sha((T/h['name']).read_bytes())==h['sha256']
for p in ledger['actual_pdf_pixels']:assert sha(pathlib.Path(p['image']).read_bytes())==p['image_sha256'] and p['pixels_actually_viewed']
from ai_value.reporting import render
rendered=render(R);assert (rendered['nodes'],rendered['edges'])==(len(nodes),len(edges))
report=(R/'reports/families/F-198.md').read_text();assert '另无标签结果：1' in report and report.count('`CLM-198-UNLABELLED-ITERATION`')==1 and 'no natural choice' in report
for f in (R/'reports/families').glob('*.md'):
 if f.stem=='F-198':continue
 assert f.read_bytes()==subprocess.check_output(['git','show','195f674:'+str(f.relative_to(R))],cwd=R),f
assert len(new['ANALYSIS-F-198']['properties']['result_ids_by_label'])==15 and len(new['ANALYSIS-F-198']['properties']['unlabelled_result_ids'])==1
ss=[s for n in new.values() for s in n['sources']]
write('source-contracts.json.gz',{'source_tex_files':8,'source_tex_lines':1992,'bib_lines':208,'results_labelled':15,'unlabelled_corollary':1,'unlabelled_report_row_preserved':True,'all_old_family_reports_byte_exact':True,'methods':22,'formal_actual_fullfiles':14,'formal_partial_yaml':True,'selected_local_B':2,'remaining_C':14,'static_union_files':588,'static_declarations':3778,'old_originals':4,'actual_pixels':8,'source_and_original_hashes_verified':True,'all_canonical_annotations':len(ss),'local_annotations':sum('path'in s for s in ss),'external_annotations':sum('url'in s for s in ss),'external_without_byte_hash':sum('url'in s and not s.get('sha256') for s in ss),'download_bytes':872597})
added=set(new)-set(old);ne=len((R/'data/graph/edges.jsonl').read_bytes().splitlines())-len(olded.splitlines())
write('curation.json.gz',{'new_records':len(added),'new_ids':sorted(added),'new_explicit_edges':ne,'old_other_records_exact':4203,'prior_code_citation_records_versioned':3,'all_original_old_edge_bytes_preserved':True,'report_validation':rendered,'initial_failure':'Initialdatawritefollowedbyvalidationcaughtexistingmutablecodecitations;oldcodebytesnowfrozenwithexactpriors. No validationrulesrelaxed.'})
print(json.dumps({'nodes':len(nodes),'edges':len(edges),'canonical_records':len(new),'impact_cases':len(cases),'archives':len(archives),'source_members':members,'new_canonical':len(added),'new_edges':ne}))
