from pathlib import Path
import json,urllib.request,datetime,hashlib
T=Path('/private/tmp/ai-paper-WP101');p=T/'acquisition.json';j=json.loads(p.read_text());jobs=[x for x in j['requests'] if x.get('error')]
for old in jobs:
 d={'name':old['name'],'url':old['url'],'attempt':2,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  with urllib.request.urlopen(urllib.request.Request(old['url'],headers={'User-Agent':'ai-paper bounded original-source research'}),timeout=35) as r:
   b=r.read(j['cap']-j['downloaded_bytes']+1);d.update(status=r.status,final_url=r.url,bytes=len(b),content_type=r.headers.get('Content-Type'));assert len(b)<=j['cap']-j['downloaded_bytes'];assert b.startswith(b'%PDF');(T/old['name']).write_bytes(b);j['downloaded_bytes']+=len(b);d['sha256']=hashlib.sha256(b).hexdigest()
 except Exception as e:d['error']=repr(e)
 j['requests'].append(d);p.write_text(json.dumps(j,indent=2)+'\n');print(json.dumps(d),flush=True)
