from pathlib import Path
import json,gzip,hashlib,subprocess,datetime
R=Path('/Users/smzdm/projects/ai_paper');sha=lambda b:hashlib.sha256(b).hexdigest();now=datetime.datetime.now(datetime.timezone.utc).isoformat();GEN='GEN-20261023-098';paths=['src/ai_value/graph.py','src/ai_value/reporting.py','tests/test_research.py'];snap={}
for path in paths:
 b=subprocess.check_output(['git','show','195f674:'+path],cwd=R);z=gzip.compress(b,mtime=0);assert gzip.decompress(z)==b;p=R/'data/provenance/code/GEN098-before-unlabelled'/ (Path(path).name+'.gz');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z);snap[path]={'path':str(p.relative_to(R)),'sha256':sha(z),'uncompressed_sha256':sha(b),'bytes':len(b),'compressed_bytes':len(z),'original_path':path,'base_commit':'195f674'}
p=R/'data/graph/nodes.jsonl';lines=p.read_bytes().splitlines(keepends=True);prior=[];out=[];ids=[]
for l in lines:
 n=json.loads(l);hits=[s for s in n['sources'] if s.get('path')in paths]
 if hits:
  prior.append(json.loads(l));ids.append(n['id']);n['version']+=1;n['updated_at']=now;n['properties']['model_generation_id']=GEN
  for s in n['sources']:
   if s.get('path')in snap:
    oldpath=s['path'];x=snap[oldpath];assert s['sha256']==x['uncompressed_sha256'];s.update(path=x['path'],sha256=x['sha256'],locator=s['locator']+'; frozen pre-WP101 source from195f674;originalpath='+oldpath+';decompressedSHA256='+x['uncompressed_sha256']+';citation relocation only,no retroactive newtest claim')
  l=(json.dumps(n,ensure_ascii=False,sort_keys=True)+'\n').encode()
 out.append(l)
assert len(prior)==3
b=(json.dumps({'at':now,'reason':'Preserve exact prior code citation bytes before extending unlabelled-result export;old proof/route claims unchanged','records':prior,'snapshots':snap},ensure_ascii=False,indent=2)+'\n').encode();z=gzip.compress(b,mtime=0);assert gzip.decompress(z)==b;(R/'data/graph/history/GEN098-code-citation-before.json.gz').write_bytes(z);p.write_bytes(b''.join(out))
p=R/'data/graph/edges.jsonl';old=p.read_bytes();eids={json.loads(l)['id'] for l in old.splitlines()};edges=[]
for id in ids:
 eid='E-'+sha(f'{id}|generated_by|{GEN}'.encode())[:16].upper();assert eid not in eids;edges.append({'id':eid,'source':id,'relation':'generated_by','target':GEN,'version':1,'created_at':now,'evidence_status':'source_content_checked','source_locator':'WP101 freezes exact old code bytes;no mathematical/application promotion','source_commit':'1581d4cbdd69a0faf34b2089614fe2a814316a6a'})
p.write_bytes(old+b''.join((json.dumps(e,ensure_ascii=False,sort_keys=True)+'\n').encode() for e in edges));print(json.dumps({'revised_prior_records':ids,'old_code_snapshots':snap,'new_generation_edges':len(edges)}))
