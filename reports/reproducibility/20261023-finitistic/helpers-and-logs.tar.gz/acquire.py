from pathlib import Path
import urllib.request,json,hashlib,datetime
T=Path('/private/tmp/ai-paper-WP101');j={'cap':8388608,'downloaded_bytes':0,'requests':[]}
for name,url in [('NRS2004v2.pdf','https://arxiv.org/pdf/math/0205034v2'),('MinamotoYamaura2017v1.pdf','https://arxiv.org/pdf/1710.01469v1'),('Cummings2022v1.pdf','https://arxiv.org/pdf/2211.04394v1'),('Rickard2018v1.pdf','https://arxiv.org/pdf/1804.09801v1')]:
 d={'name':name,'url':url,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'ai-paper bounded original-source research reading'}),timeout=35) as r:
   b=r.read(j['cap']-j['downloaded_bytes']+1);d.update(status=r.status,final_url=r.url,bytes=len(b),content_type=r.headers.get('Content-Type'));assert len(b)<=j['cap']-j['downloaded_bytes'];assert b.startswith(b'%PDF');(T/name).write_bytes(b);j['downloaded_bytes']+=len(b);d['sha256']=hashlib.sha256(b).hexdigest()
 except Exception as e:d['error']=repr(e)
 j['requests'].append(d);(T/'acquisition.json').write_text(json.dumps(j,indent=2)+'\n');print(json.dumps(d),flush=True)
