from pathlib import Path
import json,gzip,hashlib,datetime,subprocess
r=Path('/Users/smzdm/projects/ai_paper');out=r/'reports/reproducibility/20261021-elasticity';now=datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda b:hashlib.sha256(b).hexdigest();ledger=r/'data/provenance/readings/F-372.json';l=json.loads(ledger.read_text());verified={}
for s in l['read_files']+l['formal_files_actually_read']:
 assert sha((r/s['path']).read_bytes())==s['sha256'];verified[s['path']]=s['sha256']
v=l['formal_index_only'];b=(r/v['path']).read_bytes();assert sha(b)==v['sha256'];d=json.loads(gzip.decompress(b))
for s in d['local_files']:assert sha((r/s['path']).read_bytes())==s['sha256']
old={x['id']:x for x in map(json.loads,subprocess.check_output(['git','show','HEAD:data/graph/nodes.jsonl'],cwd=r,text=True).splitlines())};cur={x['id']:x for x in map(json.loads,(r/'data/graph/nodes.jsonl').read_text().splitlines())};assert all(cur[k]==n for k,n in old.items())
n=cur['ANALYSIS-F-372'];prior=json.loads(gzip.decompress((r/n['prior_version_archive']).read_bytes()));assert prior['version']==1 and n['version']==2
archives=[]
for folder in sorted((r/'experiments/runs').iterdir()):
 if not (folder/'manifest.json').exists():continue
 m=json.loads((folder/'manifest.json').read_text())
 for name,s in m['outputs'].items():assert sha((folder/name).read_bytes())==s
 for name,s in m.get('compressed_payloads',{}).items():assert sha(gzip.decompress((folder/name).read_bytes()))==s['uncompressed_sha256']
 snap=json.loads(gzip.decompress((folder/'inputs.json.gz').read_bytes()));assert set(snap)==set(m['inputs']);assert all(sha(content.encode())==m['inputs'][name]for name,content in snap.items());archives.append(dict(run_id=m['run_id'],compressed_output_hashes_match=True,decompressed_payload_hashes_match=True,all_source_snapshot_hashes_match=True))
assert len(archives)==13;(out/'all-thirteen-archives-integrity.json').write_text(json.dumps(dict(recorded_at=now,archives=archives),indent=2)+'\n')
for name in ['replay-200-supported.json','replay-325-adverse.json']:
 d=json.loads((out/name).read_text());assert d['run_id']==d['replay_run_id'] and all(d['deterministic_outputs_match'].values())
t=Path('/private/tmp/ai-paper-F372');expected={}
for s in l['selected_original_scopes'].values():
 expected[s['file']]=s['pdf_sha256'];expected[Path(s['file']).with_suffix('.txt').name]=s['extracted_text_sha256']
expected['nu2003-page206.png']=l['selected_original_scopes']['NU2003']['rendered_page206_sha256'];assert set(p.name for p in t.iterdir())==set(expected);removed=[]
for name,digest in expected.items():
 p=t/name;b=p.read_bytes();assert sha(b)==digest;removed.append(dict(file=name,bytes=len(b),sha256=digest))
assert 'Ran 46 tests' in (out/'core-check-repaired.log').read_text() and 'canonical_citations' in (out/'core-check-repaired.log').read_text()
for f in removed:(t/f['file']).unlink()
t.rmdir();(out/'source-and-cleanup-integrity.json').write_text(json.dumps(dict(recorded_at=now,ledger_sha256=sha(ledger.read_bytes()),source_read_files_hash_verified=len(verified),all_42_static_index_members_hash_verified=True,old_canonical_nodes_unchanged_from_HEAD=len(old),new_analysis_failed_v1_archived=True,temporary_files=removed,temporary_bytes_removed=sum(f['bytes']for f in removed),temporary_directory_removed=True,original_papers_redistributed=False,upstream_copy=False,dependencies_installed=False,new_application_runs=False,representative_replay_temp_outputs_cleaned=True,local_Lean_or_Comparator=False),indent=2)+'\n');print(dict(sources=len(verified),index=42,old_nodes=len(old),temporary_bytes_removed=sum(f['bytes']for f in removed),archives=13))
