from pathlib import Path
import json,urllib.request,hashlib,datetime
T=Path('/private/tmp/ai-paper-WP103');cap=8388608;out=T/'acquisition.json';state=json.loads(out.read_text()) if out.exists() else {'cap_bytes':cap,'downloaded_bytes':0,'requests':[]}
def fetch(n,u):
 if any(x.get('name')==n and x.get('status')==200 for x in state['requests']):return
 row={'name':n,'url':u,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  with urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'ai-paper-research/0.1'}),timeout=25) as f:
   b=f.read(cap-state['downloaded_bytes']+1);assert len(b)<=cap-state['downloaded_bytes'];assert b.startswith(b'%PDF');(T/n).write_bytes(b);state['downloaded_bytes']+=len(b);row.update(status=f.status,final_url=f.url,bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
 except Exception as e:row['error']=repr(e)
 state['requests'].append(row);out.write_text(json.dumps(state,indent=2)+'\n');print(json.dumps(row),flush=True)
if __name__=='__main__':
 for n,u in [('Pardon2013.pdf','https://www.math.stonybrook.edu/~jpardon/manuscripts/08_hilbertsmith.pdf'),('HornbostelSchlichting2003.pdf','https://warwick.ac.uk/fac/sci/maths/people/staff/marco_schlichting/research/hermlocn.pdf'),('BalmerWalter2002.pdf','https://www.numdam.org/article/ASENS_2002_4_35_1_127_0.pdf'),('Woolf2008.pdf','https://ems.press/content/serial-article-files/43150?nt=1')]:fetch(n,u)
