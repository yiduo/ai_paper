from pathlib import Path
import json,gzip,hashlib,sys,subprocess,xml.etree.ElementTree as ET
R=Path('/Users/smzdm/projects/ai_paper');T=Path('/private/tmp/ai-paper-WP103');OUT=R/'reports/reproducibility/20261023-hilbert-smith';BASE='46923f1';sys.path.insert(0,str(R/'src'))
from ai_value.graph import load,affected_nodes,theoretical_grade
from ai_value.knowledge import export
from ai_value.reporting import render
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(n,j):
 b=(json.dumps(j,ensure_ascii=False,indent=2)+'\n').encode();z=gzip.compress(b,mtime=0);assert gzip.decompress(z)==b;(OUT/n).write_bytes(z)
nodes,edges=load(R);cases=[];lie='CLM-304-COR-LIE';main='CLM-304-THM-MAIN';flow='CLM-304-UNLABELLED-FLOW-ITERATE';app='APP-304-01';chase='CLM-304-LAT-FINITE-CHASES'
def check(name,seed,yes,no):
 h=affected_nodes(nodes,edges,set(seed));assert set(yes)<=h,(name,'missing',set(yes)-h);assert not(set(no)&h),(name,'false',set(no)&h);cases.append({'name':name,'changed':seed,'expected_review':yes,'expected_unaffected':no,'affected':sorted(h),'pass':True})
check('finite_chase_routes_source_and_component',[chase],['CLM-304-THM-BOUNDED-COMPARISON',main,lie,app],['LIT-304-SERRE1951'])
check('full_Lie_not_needed_for_finite_component',[lie],[flow,'PART-304-COMPACT-CLOSURE-FLOW'],[app,chase])
check('unlabelled_flow_not_forged_premise',[flow],['PART-304-COMPACT-CLOSURE-FLOW'],[main,lie,app])
check('classical_group_reduction_required',['LIT-304-PARDON2013'],[lie,flow],[main,app])
check('Newman_required_local_chart',['LIT-304-NEWMAN1931'],[main,lie],[chase,app])
check('Serre_finiteness_required',['LIT-304-SERRE1951'],['CLM-304-LEM-ODD-SPHERE-NULL',main,lie],[app])
check('Serre_degree_killing_required',['LIT-304-SERRE1953'],[main],[chase,app])
check('old_cofinality_context_not_current_blackbox',['LIT-304-HORNBOSTELSCHLICHTING2004'],['OLD-304-COFINAL-TATE-TWO'],[main,'CLM-304-THM-DENSE-DOUBLING',app])
check('BW_integral_localization_required',['LIT-304-BALMERWALTER2002'],['CLM-304-THM-WITT-LOCALIZATION',main],[chase,app])
check('Woolf_cone_input_vs_nonidentical_category',['LIT-304-WOOLF2008'],['CLM-304-CAT-SYMMETRIC-CONE','OLD-304-PERFECT-SHEAF-HOMOTOPY',main],[chase,app])
check('uniform_denominator_not_elementwise',['CLM-304-THM-BOUNDED-COMPARISON'],['CLM-304-THM-SPHERE-LATTICE',main],[app])
check('generic_signature_old_Hardt_required',['LIT-304-HARDT1980'],[main],['CLM-304-LEM-ODD-SPHERE-NULL',app])
check('quotient_germs_required_projectors',['CLM-304-THM-GERMS'],['CLM-304-PROP-SUM-CLASSES','CLM-304-PROP-CLASS-COVARIANCE',main],[app])
check('p2_sign_appendix_actual_support',['CLM-304-CAT-PRODUCT-SHIFT-SIGN'],['CLM-304-CAT-ENDPOINT-FORMS',main],[app])
check('algebraic_characters_not_completion',['CLM-304-LEM-CHARACTER-COPRODUCT'],['CLM-304-LEM-ORTHOGONALITY',main],[app])
check('finite_local_sheets_not_freefullaction',['CLM-304-LEM-FINITE-SHEETS'],['CLM-304-PROP-EQUAL-PARTS',main],[app])
check('F198_support_route_preserved',['CLM-198-LEM-RECTIFICATION'],['CLM-198-THM-MAIN','XPL-198-RECTIFICATION-CALLERS'],[main,app])
check('F198_real_QPA_context_preserved',['LIT-198-QPA-COMPLEX'],['CHECK-198-QPA-CALLER','XPL-198-RECTIFICATION-CALLERS'],['CLM-198-THM-MAIN',main,app])
check('F196_Hatcher_old_input_preserved',['OLD-196-HATCHER-HUREWICZ-MAP'],['CLM-196-THM-MAIN'],[main,app])
check('F256_actual_map_gate_preserved',['LIT-256-GAP-FP-INTERFACE'],['APP-256-01'],[main,app])
assert all(theoretical_grade(nodes,edges,i)=='unknown' for i in [lie,main,flow,app]);write('impact.json.gz',{'count':len(cases),'cases':cases,'full_grades':'unknown','meaning':'Review routing,not mathematical approval'})
ex=export(R);j=json.loads(gzip.decompress((R/'reports/graph/knowledge.json.gz').read_bytes()));assert {n['id']:n for n in j['nodes']}==nodes and j['edges']==edges
ns={'g':'http://graphml.graphdrawing.org/xmlns'};tree=ET.fromstring(gzip.decompress((R/'reports/graph/knowledge.graphml.gz').read_bytes()));gn={n.attrib['id']:json.loads(next(d.text for d in n if d.attrib.get('key')=='properties')) for n in tree.findall('.//g:node',ns)};ge={n.attrib['id']:json.loads(next(d.text for d in n if d.attrib.get('key')=='evidence')) for n in tree.findall('.//g:edge',ns)};assert gn==nodes and ge=={e['id']:e for e in edges};write('exports.json.gz',{'export':ex,'json_full_nodes_edges_exact':True,'graphml_full_nodes_edges_exact':True})
archives=[];members=0
for p in sorted((R/'experiments/runs').glob('*/manifest.json')):
 m=json.loads(p.read_text())
 for name,h in m['outputs'].items():
  b=(p.parent/name).read_bytes();assert sha(b)==h
  if name.endswith('.gz'):gzip.decompress(b)
 for name,d in m.get('compressed_payloads',{}).items():assert sha(gzip.decompress((p.parent/name).read_bytes()))==d['uncompressed_sha256']
 s=json.loads(gzip.decompress((p.parent/m['source_snapshot']).read_bytes()));assert set(s)==set(m['inputs']);assert all(isinstance(t,str) and sha(t.encode())==m['inputs'][n] for n,t in s.items());members+=len(s);archives.append({'run_id':m['run_id'],'source_members':len(s),'all_output_and_decompressed_hashes_verified':True,'scientific_replay':False})
write('archives.json.gz',{'archives':archives,'count':len(archives),'source_members':members,'reason_no_replay':'No experimental algorithm/spec/data/comparator changed;one new conditional unrun plan is not executable scientific code'})
oldraw=subprocess.check_output(['git','show',BASE+':data/graph/nodes.jsonl'],cwd=R);olded=subprocess.check_output(['git','show',BASE+':data/graph/edges.jsonl'],cwd=R);raw=(R/'data/graph/nodes.jsonl').read_bytes();eraw=(R/'data/graph/edges.jsonl').read_bytes();assert raw.startswith(oldraw) and eraw.startswith(olded);assert len(oldraw.splitlines())==4286 and len(raw.splitlines())==4399
old={json.loads(l)['id']:json.loads(l) for l in oldraw.splitlines()};cur={json.loads(l)['id']:json.loads(l) for l in raw.splitlines()};assert all(cur[i]==n for i,n in old.items())
# Every tracked old plan,experiment/source/test/reading ledger/family report stays byte-exact.
for prefix in ['experiments','src','tests','data/provenance/readings','reports/families']:
 paths=subprocess.check_output(['git','ls-tree','-r','--name-only',BASE,'--',prefix],cwd=R,text=True).splitlines()
 for p in paths:assert (R/p).read_bytes()==subprocess.check_output(['git','show',BASE+':'+p],cwd=R),p
oldcov=json.loads(subprocess.check_output(['git','show',BASE+':data/graph/reading_coverage.json'],cwd=R));cov=json.loads((R/'data/graph/reading_coverage.json').read_text());newcov=json.loads(json.dumps(cov));del newcov['partially_read_families']['F-304'];assert newcov==oldcov
write('canonical-preservation.json.gz',{'base':BASE,'old_records':4286,'alloldrecordlines_and_alloldedgebytes_exact':True,'alloldcandidates_and_trackedexperiments_plans_sources_tests_readingledgers_familyreports_exact':True,'only_new_coverage_entry':'F-304','new_records':113,'new_edges':295,'new_candidates':1,'new_initial_checks':0,'new_application_runs':0})
l=json.loads((R/'data/provenance/readings/F-304.json').read_text());assert len(l['results'])==40 and len(l['unlabelled_results'])==1 and len(l['methods'])==24 and len(l['source_sections'])==9
for f in l['read_files']:assert sha((R/f['path']).read_bytes())==f['sha256'] and f['actually_read']
for o in l['historical_selected_originals']:assert sha((T/o['name']).read_bytes())==o['sha256']
for p in l['actual_pdf_pixels']:assert sha(Path(p['image']).read_bytes())==p['image_sha256'] and p['pixels_actually_viewed']
assert len(l['historical_selected_originals'])==4 and len(l['unread_root_body_keys'])==36 and len(l['actual_pdf_pixels'])==12
assert l['new_candidates']==1 and l['new_initial_checks']==0 and not l['numeric_or_symbolic_run'];assert not l['formal_status']['registered_manuscript_formalization_claim'];assert all(n['properties']['credibility']=='C' for n in cur.values() if n['id'] in [x['id'] for x in l['results']+l['unlabelled_results']])
r=json.loads(gzip.decompress((R/l['review_output']).read_bytes()));assert not r['second_provider'] and not r['human_review'] and r['exact_backend']=='unknown' and set(r['roles'])=={'skeptic','defender'}
m=render(R);family=(R/'reports/families/F-304.md').read_text();assert flow in family and all(x['id'] in family and x['statement'].replace('|',r'\|') in family for x in l['results']);assert m['candidate_connections']==44 and m['externally_checked_cards']==13 and m['source_decomposition_drafts']==50 and m['partial_reading_families']==55
sources=[s for n in cur.values() for s in n['sources']]
write('source-contracts.json.gz',{'selected_original_works':4,'actual_pixels':12,'source_and_image_hashes_verified':True,'named_results':40,'unlabelled_results':1,'methods':24,'actual_tex_lines':3501,'bib_lines':452,'formal_local_B_bindings':0,'fullchain_unknown':True,'all_canonical_annotations':len(sources),'local_annotations':sum('path'in s for s in sources),'external_annotations':sum('url'in s for s in sources),'external_without_byte_hash':sum('url'in s and not s.get('sha256') for s in sources),'download_bytes':l['acquisition']['downloaded_bytes'],'metrics':m})
print(json.dumps({'nodes':len(nodes),'edges':len(edges),'canonical_records':len(cur),'impact_cases':len(cases),'archives':len(archives),'source_members':members,'all_canonical_annotations':len(sources),'core_citations':m['citations_checked'],'local_annotations':sum('path'in s for s in sources),'external_annotations':sum('url'in s for s in sources),'external_without_byte_hash':sum('url'in s and not s.get('sha256') for s in sources)}))
