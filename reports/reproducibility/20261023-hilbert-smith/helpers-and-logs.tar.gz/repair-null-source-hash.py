from pathlib import Path
import json,gzip,datetime,subprocess
R=Path('/Users/smzdm/projects/ai_paper');T=Path('/private/tmp/ai-paper-WP103');p=R/'data/graph/nodes.jsonl';raw=p.read_bytes();lines=raw.splitlines(keepends=True);prior=[];new=[];exact=[];now=datetime.datetime.now(datetime.timezone.utc).isoformat();arc='data/graph/history/GEN100-before-unknown-hash-normalization.json.gz'
for line in lines:
 n=json.loads(line)
 if any('url' in s and 'sha256' in s and s['sha256'] is None for s in n['sources']):
  assert n['id'].startswith('LIT-304-') and n['version']==1;prior.append(json.loads(line));exact.append(line)
  for s in n['sources']:
   if 'url'in s and s.get('sha256','absent') is None:del s['sha256']
  n.update(version=2,updated_at=now,updated_by_generation_id='GEN-20261023-100',prior_version_archive=arc);n['properties']['representation_correction']='Unknown external byte hash stays unknown;omit optional sha256 instead of explicit null to match existing provenance-audit contract. Mathematical statements,URLs,scope and evidence unchanged.';new.append((json.dumps(n,ensure_ascii=False,sort_keys=True)+'\n').encode())
 else:new.append(line)
assert len(prior)==32
for name,b in [(arc,(json.dumps({'reason':'Unknown-hash representation compatibility;no mathematical correction','records':prior},ensure_ascii=False,indent=2)+'\n').encode()),('data/graph/history/GEN100-before-unknown-hash-original-lines.jsonl.gz',b''.join(exact))]:
 z=gzip.compress(b,mtime=0);assert gzip.decompress(z)==b;(R/name).write_bytes(z)
p.write_bytes(b''.join(new));old=subprocess.check_output(['git','show','46923f1:data/graph/nodes.jsonl'],cwd=R);assert p.read_bytes().startswith(old)
(T/'core-first-failed.log').write_bytes((T/'core.log').read_bytes());(T/'unknown-hash-repair.json').write_text(json.dumps({'at':now,'new_records_versioned':32,'prior_records':arc,'exact_prior_lines':'data/graph/history/GEN100-before-unknown-hash-original-lines.jsonl.gz','failure':'audit_graph_provenance external legacy key concat None','repair':'Omit optional unknown hash field as existing records;no validator or software changes','old4286lines_exact':True,'mathematical_facts_changed':False},indent=2)+'\n');print(len(prior))
