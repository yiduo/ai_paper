from pathlib import Path
import json,gzip,hashlib,tarfile,io,datetime,subprocess
R=Path('/Users/smzdm/projects/ai_paper');T=Path('/private/tmp/ai-paper-WP103');O=R/'reports/reproducibility/20261023-hilbert-smith';now=datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda b:hashlib.sha256(b).hexdigest()
def write(p,j):(R/p).write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
clean=json.loads(gzip.decompress((O/'no-math-clean-directory.json.gz').read_bytes()));assert clean['exit_code']==0 and not clean['upstream_math_present'] and not (T/'no-math-clean').exists()
core=(T/'core.log').read_text();assert 'Ran 69 tests' in core and '\nOK\n' in core and '7624' in core
assert not subprocess.check_output(['git','-C','math','status','--porcelain'],cwd=R,text=True).strip();assert subprocess.check_output(['git','-C','math','rev-parse','HEAD'],cwd=R,text=True).strip()=='1581d4cbdd69a0faf34b2089614fe2a814316a6a'
assert sha((R/'722篇AI数学论文应用价值挖掘纲领.md').read_bytes())=='96fad398177fc3a54a87c07867456c5d84e66a7d538500b00ca4797d0a749c6e'
l=json.loads((R/'data/provenance/readings/F-304.json').read_text());acq=[x for x in l['acquisition']['requests'] if x.get('status')==200];assert len(acq)==4 and sum(x['bytes'] for x in acq)==1374189
for f in acq:assert sha((T/f['name']).read_bytes())==f['sha256']
for p in l['actual_pdf_pixels']:assert sha(Path(p['image']).read_bytes())==p['image_sha256'] and p['pixels_actually_viewed']
raw_names={x['name'] for x in acq}|{Path(x['name']).with_suffix('.txt').name for x in acq}|{'current-source.txt'}|{Path(p['image']).name for p in l['actual_pdf_pixels']};raw=[T/n for n in sorted(raw_names)];assert len(raw)==21 and all(p.is_file() for p in raw)
meta=[{'name':p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'retention':'Removed after actually read version/hash/range/pixel provenance saved;not republished'} for p in raw]
# Prior helper copies are already retained by the WP102 archive; verify before removing duplicates.
prior=R/'reports/reproducibility/20261023-rectification/helpers-and-logs.tar.gz'
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(prior.read_bytes())),mode='r:') as tar:
 for p in (T/'prior').iterdir():assert p.read_bytes()==tar.extractfile(p.name).read()
helpers=[p for p in T.iterdir() if p.is_file() and p.name not in raw_names];assert all(p.suffix in {'.py','.log','.json'} for p in helpers);mem={p.name:p.read_bytes() for p in helpers};buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as tar:
 for n,b in sorted(mem.items()):
  x=tarfile.TarInfo(n);x.size=len(b);x.mtime=0;x.mode=0o644;tar.addfile(x,io.BytesIO(b))
b=buf.getvalue();z=gzip.compress(b,mtime=0);assert gzip.decompress(z)==b
out=O/'helpers-and-logs.tar.gz';out.write_bytes(z)
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(out.read_bytes())),mode='r:') as tar:
 assert set(tar.getnames())==set(mem)
 for n,v in mem.items():assert tar.extractfile(n).read()==v
storage={'at':now,'temporary_root':str(T),'old_original_PDFs':4,'downloaded_bytes':1374189,'actual_pixels':12,'temporary_raw_files':meta,'temporary_raw_bytes_removed':sum(x['bytes'] for x in meta),'own_archive':str(out.relative_to(R)),'compressed_bytes':len(z),'uncompressed_tar_bytes':len(b),'compressed_sha256':sha(z),'uncompressed_tar_sha256':sha(b),'member_bytes':sum(map(len,mem.values())),'members':{n:{'bytes':len(v),'sha256':sha(v)} for n,v in sorted(mem.items())},'all_decompressed_member_bytes_verified_before_plaintext_removal':True,'failed_retrieval_and_metadata_failure_retained':True,'prior_helper_copies_checked_against_existing_archive':True,'new_record_representation_versions_archived':32,'official_math_clean_pinned':True,'root_charter_hash_unchanged':True,'new_numerical_or_symbolic_experiment_data':False,'software_installed_or_invoked':False,'external_fulltext_republished':False,'temporary_root_removed':False}
for p in raw:assert sha(p.read_bytes())==next(x['sha256'] for x in meta if x['name']==p.name);p.unlink()
for p in helpers:assert p.read_bytes()==mem[p.name];p.unlink()
for p in (T/'prior').iterdir():p.unlink()
(T/'prior').rmdir();T.rmdir();storage['temporary_root_removed']=not T.exists();write(str(O.relative_to(R))+'/storage.json',storage)
(O/'quality.md').write_text(f'''# WP103 quality receipt

2026-10-23. F304 full-current-source decomposition and a single demand-unqualified finite-chase hypothesis. Overall active_incomplete.

- All 69 core software tests, canonical validation, generated reports and full source-provenance audit passed with existing Python3.12.14 and bundled Node. No software installation or experiment implementation changes.
- 113 new canonical records and 295 explicit relations. All 4,286 old record lines and every old edge byte are exact against46923f1. Thirty-two new records were representation-versioned after the first full workflow rejected explicitnull external hashes:optional unknown fields now omitted,mathematical facts unchanged,exact prior objects/JSONL and initialfailure log retained. No validator change. Every old candidate, tracked experiment/plan/source/test, reading ledger and family report is byte-exact. Coverage changes only by the F304 entry.
- Full graph7,172 nodes/19,719 relations. 7,634 canonical annotations:7,624 core-validated,7,068 local hashed,566 external without retained bodies,387 without byte hashes. JSON and GraphML full node/edge objects equal graph.load. Twenty new/old propagation checks pass; the finite-chase candidate does not require the whole Hilbert–Smith theorem. Unknown complete grades and human/provider gates remain unchanged.
- All9TeX/3,501lines,452Bib andREADME17 read and hashed. Forty labelled results plus one source-located unlabelled flow consequence and24methods survive exports. All41 local source claims C,fullchain unknown. No matching formal registration observed in pinned exact-name/path/narrow challenge scope; no claim that no related lemma exists anywhere,no Lean/Comparator build.
- Four historical originals and twelve actually viewed PDF pages hash-verified. HS AppendixA.2 read from pixels because embeddedtext garbled;AppendixB navigation pixels are not fullproof credit. Pardon version/reduction,old cofinality2 bound,BW integral localization and Woolf perfect-category/excision limits remain explicit. Other36rootbody scopes and recursive history incomplete. Hatcher identity reuse adds no new degree-proof reading credit.
- One concrete pending APP30401,unrun conditional plan,actual isolated same-provider skeptic/defender opinions retained compressed;no independent-provider/human review. Realconsumer/batch/certifiedpremises/fullcost unestablished. Optimized cachedSNF,HNF and old quantitativefivelemma with separate annihilators may already suffice. No new initialcheck,scientificrun or performanceclaim.
- All15 scientific archives/267 source members passed output/decompression/input hashes. No scientific replay because experimental algorithm/data/judge unchanged; archive integrity is not new application evidence.
- Independent no-math clean directory:{clean['files']:,}files/{clean['copied_bytes']:,}bytes,all copied byte hashes checked,core/validation/report/provenance exit0. Without upstream,sourcehash audit uses pinned inventory rather than fresh math bytes. Clean directory removed; later receipt/state/documentation-only writes do not imply another scientific run.
- Download1,374,189bytes within4originals/8MiB cap. One normalTLS timeout and boundedretry success,metadata null-DOI failure,first source-audit nullhash compatibility failure and absent304formal-document observation retained. Broad irrelevant filename output gives no proofreading credit. README prior18-line narrative corrected toactual17 without byte/coverage change.
- External PDF/text/pixels totaling{storage['temporary_raw_bytes_removed']:,}bytes hash-verified and removed after ownscope/version/hash evidence saved. Own helpers/logs/opinions{storage['member_bytes']:,}bytes compressed to{len(z):,}bytes;all decompressed member bytes verified before plaintext removal. Prior helper duplicates verified against existingWP102archive. No external fulltext or official upstream source republished.
- math remains clean at1581d4cbdd69a0faf34b2089614fe2a814316a6a;root Chinese charter SHA unchanged. No GitHub push/write. Lastverifiedpublicf0c3ddc throughWP092/retro033 has its own earlier scopedCI;WP093-WP103/retro034-036 remain local until a meaningful reviewed milestone batch.

55 read families/50 current-source drafts,1,349labelled results plus2unlabelledmain/1corollary/1flowconsequence;F238partial95 separately.44candidates,13checks/13distincthypotheses,five narrowly supported/eightadverse. Completefamilies/history/human/provider/pilots0. Retrocounter2 after036;WP104 boundedconsumer qualification thenmandatory037. No overallgoal completion.
''')
c=json.loads((R/'state/checkpoint.json').read_text());c['saved_at']=now;c['metrics']=json.loads((R/'reports/metrics.json').read_text());c['recovery_observation'].update(checkpoint_core_check='69core20impact/fullcanonical-sourceFKgates/wholeJSONGraphML/15archives267members/no-mathclean exit0;ownhelperscompressed/decompressedverified;temporaryrootremoved',research_processes_observation='All WP103 core/QA/no-math sessions terminal;both isolatedroles completed;no scientificexperiment/preview/Lean/Comparator started');write('state/checkpoint.json',c)
p=R/'state/status.md';s=p.read_text();s=s.replace('本段及末尾WP100','本段及末尾WP103');start=s.index('规范图谱当前');end=s.index('\n\n四十一候选',start);s=s[:start]+'规范图谱当前7172节点、19719关系，7634条规范来源注释（7624核心研究类型）；55族实际阅读、50份当前全文草稿、1349带标签结果，另2无标签主定理、1无标签推论及1无标签流结论。44候选／13初检／13不同假设，限定支持五、不利八；完整族／历史／真人／第二供应商／试点仍0。WP103的69核心、20依赖传播、完整导出、15归档267源码成员和不含math干净目录均实际通过；临时原作已核验清理，自有记录压缩回解核验。下一WP104有界核真实有限比较消费者，之后强制复盘037。没有GitHub推送，日常仅本地保存／提交，重要里程碑合并发布。'+s[end:];s=s.replace('\n\n四十一候选/十三初检卡','\n\n以下为历次工作记录，数字保留为当时快照。\n\n四十一候选/十三初检卡',1);p.write_text(s)
print(json.dumps({'clean_files':clean['files'],'clean_bytes':clean['copied_bytes'],'raw_removed':storage['temporary_raw_bytes_removed'],'own_compressed':len(z),'temp_removed':not T.exists(),'github_push':False}))
