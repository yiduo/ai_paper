import json,gzip,hashlib,pathlib,sys,subprocess,xml.etree.ElementTree as ET
R=pathlib.Path('/Users/smzdm/projects/ai_paper');T=pathlib.Path('/private/tmp/ai-paper-WP098');OUT=R/'reports/reproducibility/20261023-group-guard';sys.path.insert(0,str(R/'src'))
from ai_value.graph import load,affected_nodes,theoretical_grade
from ai_value.knowledge import export
def sha(b):return hashlib.sha256(b).hexdigest()
def write(n,j):
 b=(json.dumps(j,ensure_ascii=False,indent=2)+'\n').encode();z=gzip.compress(b,mtime=0);assert gzip.decompress(z)==b;(OUT/n).write_bytes(z)
nodes,edges=load(R);cases=[];app='APP-256-01';nm='CLM-256-N-THM-MAIN';km='CLM-256-K-THM-MAIN'
def check(n,seed,yes,no):
 hit=affected_nodes(nodes,edges,set(seed));assert set(yes)<=hit,(n,'missing',set(yes)-hit);assert not(set(no)&hit),(n,'false',set(no)&hit);cases.append({'name':n,'changed':seed,'expected_review':yes,'expected_unaffected':no,'affected':sorted(hit),'pass':True})
check('GAP_map_tracing_change_reopens_admission',['LIT-256-GAP-FP-INTERFACE'],[app,'PART-256-MAP-IDENTITY-GATE','CHECK-256-CANONICAL-MAP-GAP'],[nm,km])
check('Sage_actual_caller_change_reopens_admission',['LIT-256-SAGE-FP-INTERFACE'],[app,'PART-256-RELATIVE-PRESENTATION-GATE'],[nm,km])
check('KBMAG_confluence_is_not_theorem_proof_input',['LIT-256-KBMAG-FP-INTERFACE'],[app,'CHECK-256-JUDGE-COST-GAP'],[nm,km])
check('canonical_map_is_actual_candidate_gate',['PART-256-MAP-IDENTITY-GATE'],[app],[nm,km])
check('independent_embedding_judge_is_actual_candidate_gate',['PART-256-EMBEDDING-JUDGE-GATE'],[app],[nm,km])
check('full_cost_not_free_preparation',['PART-256-GROUP-FULL-COST-GATE'],[app],[nm,km])
check('general_source_remains_candidate_dependency',[nm],[app],[km])
check('single_unimodular_formal_not_general_guard',[km],['CLM-256-K-COR-KERVAIRE'],[app,nm])
check('old_GR_scope_not_direct_newproof_premise',['LIT-256-GERSTENHABERROTHAUS1962'],[],[nm,km,app])
check('exploration_context_not_required_proof',['XPL-256-GROUP-GUARD-QUALIFICATION'],[],[nm,km,app])
check('F058_QE_scope_dependency_preserved',['LIT-058-QEPCAD-INTERFACE'],['APP-058-01'],[app,nm])
check('F058_classification_not_local_candidate_dependency',['CLM-058-U-THM-MAIN'],[],['APP-058-01',app])
assert theoretical_grade(nodes,edges,app)=='unknown'
write('impact.json.gz',{'cases':cases,'count':len(cases),'candidate_grade':'unknown','meaning':'Review routing,not theorem rejection/build/human or application validation'})
ex=export(R);j=json.loads(gzip.decompress((R/'reports/graph/knowledge.json.gz').read_bytes()));assert {n['id']:n for n in j['nodes']}==nodes and j['edges']==edges
tree=ET.fromstring(gzip.decompress((R/'reports/graph/knowledge.graphml.gz').read_bytes()));ns={'g':'http://graphml.graphdrawing.org/xmlns'}
gn={n.attrib['id']:json.loads(next(d.text for d in n if d.attrib.get('key')=='properties')) for n in tree.findall('.//g:node',ns)};ge={n.attrib['id']:json.loads(next(d.text for d in n if d.attrib.get('key')=='evidence')) for n in tree.findall('.//g:edge',ns)};assert gn==nodes and ge=={e['id']:e for e in edges}
write('exports.json.gz',{'export':ex,'json_full_nodes_edges_exact':True,'graphml_full_nodes_edges_exact':True})
archives=[];members=0
for p in sorted((R/'experiments/runs').glob('*/manifest.json')):
 m=json.loads(p.read_text())
 for name,h in m['outputs'].items():
  b=(p.parent/name).read_bytes();assert sha(b)==h
  if name.endswith('.gz'):gzip.decompress(b)
 for name,d in m.get('compressed_payloads',{}).items():assert sha(gzip.decompress((p.parent/name).read_bytes()))==d['uncompressed_sha256']
 s=json.loads(gzip.decompress((p.parent/m['source_snapshot']).read_bytes()));assert set(s)==set(m['inputs']);assert all(isinstance(t,str) and sha(t.encode())==m['inputs'][n] for n,t in s.items());members+=len(s)
 archives.append({'run_id':m['run_id'],'source_members':len(s),'all_output_and_decompressed_hashes_verified':True,'scientific_replay':False})
write('archives.json.gz',{'archives':archives,'count':len(archives),'source_members':members,'reason_no_replay':'No experimental code/spec/data/comparator changes;WP098 qualification not application validation'})
oldraw=subprocess.check_output(['git','show','6106f34:data/graph/nodes.jsonl'],cwd=R);old={json.loads(l)['id']:json.loads(l) for l in oldraw.splitlines()};new={json.loads(l)['id']:json.loads(l) for l in (R/'data/graph/nodes.jsonl').read_bytes().splitlines()}
assert all(new[k]==v for k,v in old.items() if k!=app)
v1=json.loads(gzip.decompress((R/'data/graph/history/GEN095-APP25601-before.json.gz').read_bytes()));assert v1==old[app]
v2s=json.loads(gzip.decompress((R/'data/graph/history/GEN095-before-example-locator-correction.json.gz').read_bytes()))['records'];assert len(v2s)==13
v2=next(x for x in v2s if x['id']==app);assert v2['version']==2 and new[app]['version']==3
for key in ['prediction','test_spec','run_ids','dedup_key','source_ids','part_ids','application_result','workflow','theoretical_grade','opposition','defense']:assert v1['properties'][key]==v2['properties'][key]==new[app]['properties'][key]
oe=subprocess.check_output(['git','show','6106f34:data/graph/edges.jsonl'],cwd=R);assert (R/'data/graph/edges.jsonl').read_bytes().startswith(oe)
plan='experiments/plans/APP-256-01-conditional.json';assert (R/plan).read_bytes()==subprocess.check_output(['git','show','6106f34:'+plan],cwd=R)
cov='data/graph/reading_coverage.json';assert (R/cov).read_bytes()==subprocess.check_output(['git','show','6106f34:'+cov],cwd=R)
assert not subprocess.check_output(['git','diff','--name-only','6106f34','--','src','tests','experiments'],cwd=R,text=True).strip()
write('canonical-preservation.json.gz',{'base':'6106f34','old_records_exact_other_than_versioned_candidate':len(old)-1,'candidate_v1_exact_archived':True,'candidate_v2_and12newnode_versions_before_locator_correction_preserved':True,'original_prediction_plan_runs_and_opinions_exact':True,'all_old_edges_exact':True,'coverage_bytes_exact':True,'experimental_code_specs_runs_tests_unchanged':True,'new_records':len(new)-len(old),'human_reviews':0,'second_provider_reviews':0,'new_application_experiments':0})
ledger=json.loads((R/'data/provenance/demand/F-256-group-presentation-contracts-v2.json').read_text());assert sha((R/ledger['supersedes']['path']).read_bytes())==ledger['supersedes']['sha256']
for s in ledger['selected_source_files']:assert sha((T/s['temporary_name']).read_bytes())==s['sha256']
assert ledger['manual_example_scope_audit']['source_lines']==[1359,1369]
lines=(T/'sagemath--sage--src--sage--groups--finitely_presented.py').read_text().splitlines();scope='\n'.join(lines[1358:1369]);assert all(x in scope for x in ['C5','C12','a^5, b^12, a^-1*b*a*b^-1'])
write('source-contracts.json.gz',{'selected_source_files':8,'actual_selected_lines':ledger['selected_body_lines'],'selected_source_hashes_verified':True,'versioned_correction_parent_hash_exact':True,'corrected_example_locator_text_verified':True,'primary_projects':3,'new_download_bytes':ledger['acquisition']['downloaded_bytes'],'new_guard_runtime_or_benchmark':False,'guard_input_batch_admitted':False,'same_supplier_roles_new_calls':0,'human_reviews':0,'second_provider_reviews':0})
print(json.dumps({'nodes':len(nodes),'edges':len(edges),'canonical_records':len(new),'impact_cases':len(cases),'archives':len(archives),'source_members':members,'old_record_preservation':True}))
