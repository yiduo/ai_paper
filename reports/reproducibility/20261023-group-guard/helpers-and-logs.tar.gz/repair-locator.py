"""Preserve initial records and fix an off-by-section example locator explicitly."""
from pathlib import Path
import json,gzip,hashlib,datetime,copy
R=Path('/Users/smzdm/projects/ai_paper');NOW=datetime.datetime.now(datetime.timezone.utc).isoformat();GEN='GEN-20261023-095'
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(j):return (json.dumps(j,ensure_ascii=False,indent=2)+'\n').encode()
oldp='data/provenance/demand/F-256-group-presentation-contracts.json';newp='data/provenance/demand/F-256-group-presentation-contracts-v2.json'
oldraw=(R/oldp).read_bytes();d=json.loads(oldraw);d['version']=2;d['supersedes']={'path':oldp,'sha256':sha(oldraw)};d['correction']={'at':NOW,'reason':'The published C5/C12 example was assigned lines1378-1391,which belong to following example. Numbered pinned source confirms correct scope1359-1369. No relators,rank interpretation,admission status or prediction changed. Clarify no install/invocation performed by WP098,not global absence of Sage.','old_example_lines':[1378,1391],'correct_example_lines':[1359,1369]};d['manual_example_scope_audit']['source_lines']=[1359,1369]
for s in d['selected_source_files']:
 if s['project']=='sagemath/sage':s['scope']=s['scope'].replace('No Sage/GAP installed or called.','No Sage/GAP installation or invocation performed in WP098;an existing /usr/local/bin/sage launcher was found by PATH lookup but not executed or evaluated.')
assert not (R/newp).exists();(R/newp).write_bytes(enc(d))
nodes=[json.loads(l) for l in (R/'data/graph/nodes.jsonl').read_text().splitlines()];changed=[]
for n in nodes:
 if any(s.get('path')==oldp for s in n['sources']):changed.append(copy.deepcopy(n))
arc='data/graph/history/GEN095-before-example-locator-correction.json.gz';raw=enc({'at':NOW,'reason':d['correction'],'records':changed});z=gzip.compress(raw,mtime=0);assert gzip.decompress(z)==raw;(R/arc).write_bytes(z)
for n in nodes:
 if n['id'] not in {x['id'] for x in changed}:continue
 for s in n['sources']:
  if s.get('path')==oldp:s['path']=newp;s['sha256']=sha((R/newp).read_bytes());s['locator']+=';v2 corrects C5/C12 source lines and records immutable v1'
 n['version']+=1;n['updated_at']=NOW;n['updated_by_generation_id']=GEN;n['prior_version_archive']=arc
 if n['id']=='XPL-256-GROUP-GUARD-QUALIFICATION':n['properties']['manual_example_scope_audit']['source_lines']=[1359,1369]
 if n['id']=='APP-256-01':n['properties']['demand_audit']=newp
 # Keep the software node's source-reading wording consistent with revised ledger.
 if n['id']=='LIT-256-SAGE-FP-INTERFACE':n['properties']['verified_scope']=[x['scope'] for x in d['selected_source_files'] if x['project']=='sagemath/sage']
(R/'data/graph/nodes.jsonl').write_bytes(b''.join((json.dumps(n,ensure_ascii=False,sort_keys=True)+'\n').encode() for n in nodes))
p=R/'reports/reproducibility/20261023-group-guard/curation.json';j=json.loads(p.read_text());j.update({'source_ledger':newp,'source_locator_repair':d['correction'],'prior_version_batch_archive':arc,'updated_record_versions':len(changed),'old_source_ledger_unchanged':sha((R/oldp).read_bytes())==sha(oldraw)});p.write_bytes(enc(j))
print(json.dumps({'corrected_source_lines':[1359,1369],'versions_preserved':len(changed),'old_ledger_sha':sha(oldraw),'corrected_ledger':newp}))
