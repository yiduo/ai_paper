from pathlib import Path
import json,gzip,hashlib,tarfile,io,shutil,datetime
R=Path('/Users/smzdm/projects/ai_paper');T=Path('/private/tmp/ai-paper-WP098');OUT=R/'reports/reproducibility/20261023-group-guard'
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(x):return (json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def gz(p,x):
 b=enc(x);z=gzip.compress(b,mtime=0);assert gzip.decompress(z)==b;p.write_bytes(z)
assert not (T/'no-math-clean').exists();assert json.loads(gzip.decompress((OUT/'no-math-clean-directory.json.gz').read_bytes()))['exit_code']==0
a=json.loads((T/'acquisition.json').read_text());raws=[]
for r in a['requests']:
 if r.get('status')!=200:continue
 p=T/r['name'];b=p.read_bytes();assert sha(b)==r['sha256'];raws.append({'name':r['name'],'url':r['url'],'bytes':len(b),'sha256':r['sha256'],'action':'hashverified_then_removed_not_republished'})
assert len({r['name'] for r in raws})==len(raws)
rawnames={r['name'] for r in raws};ours=[p for p in sorted(T.iterdir()) if p.is_file() and p.name not in rawnames]
assert all(p.name in {'acquisition.json'} or p.suffix in {'.py','.log'} for p in ours),[p.name for p in ours]
buf=io.BytesIO();members=[]
with tarfile.open(fileobj=buf,mode='w') as archive:
 for p in ours:
  b=p.read_bytes();m=tarfile.TarInfo(p.name);m.size=len(b);m.mtime=0;archive.addfile(m,io.BytesIO(b));members.append({'name':p.name,'bytes':len(b),'sha256':sha(b)})
tarbytes=buf.getvalue();z=gzip.compress(tarbytes,mtime=0);assert gzip.decompress(z)==tarbytes
with tarfile.open(fileobj=io.BytesIO(z),mode='r:gz') as archive:
 assert set(archive.getnames())=={m['name'] for m in members}
 for m in members:assert sha(archive.extractfile(m['name']).read())==m['sha256']
out=OUT/'helpers-and-logs.tar.gz';out.write_bytes(z);assert sha(out.read_bytes())==sha(z)
r={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'work_package':'WP-098','temporary_root':str(T),'helper_archive':str(out.relative_to(R)),'archive_sha256':sha(z),'tar_decompressed_sha256':sha(tarbytes),'gzip_roundtrip_verified':True,'tar_bytes':len(tarbytes),'helper_original_bytes':sum(m['bytes'] for m in members),'compressed_bytes':len(z),'member_hashes_verified':members,'downloaded_original_inventory':raws,'external_bytes_removed_not_republished':sum(r['bytes'] for r in raws),'acquisition_accounting_matches':sum(r['bytes'] for r in raws)==a['downloaded_bytes'],'failed_acquisitions_retained_in_metadata_and_logs':[r for r in a['requests'] if r.get('error')],'experimental_numerical_outputs_created':False,'experimental_code_changed':False,'upstream_copied_or_modified':False,'successful_clean_directory':'1725files62448468bytes validationcopy wasremovedafterexit0;no officialmathcopied','storage_scope':'No thirdparty source bodies or rawAPIcommit/directoryresponses in helperarchive;only pins/hashes and scopedownnotes remain. Ownsource/helpers/logs verified beforeplaintextremoval.','cleanup_completed':False}
assert r['acquisition_accounting_matches'];gz(OUT/'storage.json.gz',r)
shutil.rmtree(T);assert not T.exists();r['cleanup_completed']=True;gz(OUT/'storage.json.gz',r)
print(json.dumps({k:v for k,v in r.items() if k not in ['member_hashes_verified','downloaded_original_inventory','failed_acquisitions_retained_in_metadata_and_logs']},ensure_ascii=False))
