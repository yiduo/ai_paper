"""Bounded read-only public-primary-source acquisition;never run downloaded code."""
import urllib.request,json,pathlib,hashlib,datetime,sys
T=pathlib.Path('/private/tmp/ai-paper-WP098');LIMIT=8388608
P=T/'acquisition.json';state=json.loads(P.read_text()) if P.exists() else {'budget_bytes':LIMIT,'downloaded_bytes':0,'requests':[],'repos':{}}
def fetch(name,url):
 if any(r.get('name')==name and r.get('status')==200 for r in state['requests']):
  r=next(r for r in state['requests'] if r.get('name')==name and r.get('status')==200);b=(T/name).read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256'];return b
 row={'name':name,'url':url,'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  request=urllib.request.Request(url,headers={'User-Agent':'ai-paper-research-readonly','Accept':'application/vnd.github+json' if 'api.github.com/' in url else '*/*'})
  with urllib.request.urlopen(request,timeout=35) as r:
   remaining=LIMIT-state['downloaded_bytes'];b=r.read(remaining+1);assert len(b)<=remaining,'Acquisition budget exceeded';state['downloaded_bytes']+=len(b);row.update(status=r.status,final_url=r.geturl(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),content_type=r.headers.get('Content-Type'));(T/name).write_bytes(b)
 except Exception as e:row['error']=type(e).__name__+': '+str(e);raise
 finally:state['requests'].append(row);P.write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n')
 return b
if sys.argv[1]=='pins':
 for repo,branch in [('gap-system/gap','master'),('sagemath/sage','develop'),('gap-packages/kbmag','master')]:
  key=repo.replace('/','--');j=json.loads(fetch(key+'-commit.json',f'https://api.github.com/repos/{repo}/commits/{branch}'));state['repos'][repo]={'branch_observed':branch,'commit':j['sha'],'commit_date':j['commit']['committer']['date'],'commit_url':j['html_url']};P.write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n')
 for repo,path in [('gap-system/gap','lib'),('gap-packages/kbmag','doc'),('gap-packages/kbmag','gap')]:
  key=repo.replace('/','--');ref=state['repos'][repo]['commit'];j=json.loads(fetch(key+'-'+path+'-listing.json',f'https://api.github.com/repos/{repo}/contents/{path}?ref={ref}'));print(repo,path,[x['name'] for x in j if path!='lib' or any(s in x['name'] for s in ['tietz','fpiso','ghomfp','gprd'])])
 print(json.dumps(state['repos'],indent=2))
elif sys.argv[1]=='raw':
 for repo,path in [tuple(x.split(':',1)) for x in sys.argv[2:]]:
  ref=state['repos'][repo]['commit'];name=repo.replace('/','--')+'--'+path.replace('/','--');b=fetch(name,f'https://raw.githubusercontent.com/{repo}/{ref}/{path}');print(json.dumps({'name':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}))
