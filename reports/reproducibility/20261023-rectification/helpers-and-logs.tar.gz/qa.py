import json,gzip,hashlib,pathlib,sys,subprocess,xml.etree.ElementTree as ET
R=pathlib.Path('/Users/smzdm/projects/ai_paper');T=pathlib.Path('/private/tmp/ai-paper-WP102');OUT=R/'reports/reproducibility/20261023-rectification';sys.path.insert(0,str(R/'src'))
from ai_value.graph import load,affected_nodes,theoretical_grade
from ai_value.knowledge import export
def sha(b):return hashlib.sha256(b).hexdigest()
def write(n,j):
 b=(json.dumps(j,ensure_ascii=False,indent=2)+'\n').encode();z=gzip.compress(b,mtime=0);assert gzip.decompress(z)==b;(OUT/n).write_bytes(z)
nodes,edges=load(R);cases=[];main='CLM-198-THM-MAIN';asym='CLM-198-COR-LEFT-RIGHT-ASYMMETRY';gate='PART-198-CONCRETE-FIXTURE-GATE'
def check(n,seed,yes,no):
 hit=affected_nodes(nodes,edges,set(seed));assert set(yes)<=hit,(n,'missing',set(yes)-hit);assert not(set(no)&hit),(n,'false',set(no)&hit);cases.append({'name':n,'changed':seed,'expected_review':yes,'expected_unaffected':no,'affected':sorted(hit),'pass':True})
check('finite_quotient_selection_actual_main',['CLM-198-LEM-FINITE-CENTRAL-QUOTIENTS'],[main,asym,gate],['CLM-196-THM-MAIN'])
check('generic_realization_required',['CLM-198-THM-REALIZATION'],[main,asym,'CLM-198-UNLABELLED-ITERATION'],['OLD-198-MY-DERIVED-PD'])
check('nonflat_bar_required',['CLM-198-PROP-BAR-SPLITTING'],['CLM-198-COR-PD-DETECTION',main],['CLM-198-LEM-GROUP-FINITE-PRESENTATION'])
check('ordinary_simulation_required',['CLM-198-PROP-ORDINARY-SIMULATION'],[main],['CLM-198-PROP-LIFTED-DIAGRAM'])
check('Cummings_only_auxiliary',['LIT-198-CUMMINGS2024'],[asym,'CHECK-198-AUXILIARY-SIDES'],[main,gate])
check('recursive_FGR_gap_explicit',['LIT-198-FGR1975'],[asym],[main])
check('Rickard_side_transport',['OLD-198-RICKARD-GENERATION'],[asym],[main])
check('old_MY_stronger_formula_context',['OLD-198-MY-DERIVED-PD'],['CHECK-198-OLD-TRANSFER-SUFFICIENT'],[main,asym])
check('old_NRS_context_not_blackbox',['OLD-198-NRS-FINITE-ENCODING'],[],[main,asym])
check('internal_characteristic_two_companion_context',['P-ba058fe207bc26ec'],[],[main,asym])
check('originalA_side_not_auxiliaryLambda',['PART-198-LEFT-RIGHT-TRANSPORT'],[asym],[main])
check('unlabelled_corollary_not_faked_main_premise',['CLM-198-UNLABELLED-ITERATION'],[],[main])
check('F196_old_required_history_preserved',['OLD-196-HATCHER-HUREWICZ-MAP'],['CLM-196-THM-MAIN'],[main])
check('F256_actual_map_gate_preserved',['LIT-256-GAP-FP-INTERFACE'],['APP-256-01'],[main])
check('new_rectification_contract_required',['CLM-198-LEM-RECTIFICATION'],['PART-198-QUADRATIC-BASIS-INPUT','XPL-198-RECTIFICATION-CALLERS',main],['LIT-198-SAGE-CONTRACTION'])
check('QPA_actual_interface_context',['LIT-198-QPA-COMPLEX'],['CHECK-198-QPA-CALLER','XPL-198-RECTIFICATION-CALLERS'],[main,asym])
check('Sage_actual_interface_context',['LIT-198-SAGE-CONTRACTION'],['CHECK-198-SAGE-CALLER','XPL-198-RECTIFICATION-CALLERS'],[main,asym])
check('Kenzo_actual_interface_context',['LIT-198-KENZO-REDUCTION'],['CHECK-198-KENZO-CALLER','XPL-198-RECTIFICATION-CALLERS'],[main,asym])
check('old_Keller_conditions_context',['LIT-198-KELLER2000'],['OLD-198-KELLER-STRONG-ACTION','CHECK-198-KELLER-BASELINE','XPL-198-RECTIFICATION-CALLERS'],[main,asym])
assert theoretical_grade(nodes,edges,main)=='unknown' and theoretical_grade(nodes,edges,asym)=='unknown'
write('impact.json.gz',{'cases':cases,'count':len(cases),'full_main_and_auxiliary_grades':'unknown','meaning':'Review routing,not mathematical approval'})
ex=export(R);j=json.loads(gzip.decompress((R/'reports/graph/knowledge.json.gz').read_bytes()));assert {n['id']:n for n in j['nodes']}==nodes and j['edges']==edges
tree=ET.fromstring(gzip.decompress((R/'reports/graph/knowledge.graphml.gz').read_bytes()));ns={'g':'http://graphml.graphdrawing.org/xmlns'}
gn={n.attrib['id']:json.loads(next(d.text for d in n if d.attrib.get('key')=='properties')) for n in tree.findall('.//g:node',ns)};ge={n.attrib['id']:json.loads(next(d.text for d in n if d.attrib.get('key')=='evidence')) for n in tree.findall('.//g:edge',ns)};assert gn==nodes and ge=={e['id']:e for e in edges}
write('exports.json.gz',{'export':ex,'json_full_nodes_edges_exact':True,'graphml_full_nodes_edges_exact':True})
archives=[];members=0
for p in sorted((R/'experiments/runs').glob('*/manifest.json')):
 m=json.loads(p.read_text())
 for name,h in m['outputs'].items():
  b=(p.parent/name).read_bytes();assert sha(b)==h
  if name.endswith('.gz'):gzip.decompress(b)
 for name,d in m.get('compressed_payloads',{}).items():assert sha(gzip.decompress((p.parent/name).read_bytes()))==d['uncompressed_sha256']
 s=json.loads(gzip.decompress((p.parent/m['source_snapshot']).read_bytes()));assert set(s)==set(m['inputs']);assert all(isinstance(t,str) and sha(t.encode())==m['inputs'][n] for n,t in s.items());members+=len(s)
 archives.append({'run_id':m['run_id'],'source_members':len(s),'all_output_and_decompressed_hashes_verified':True,'scientific_replay':False})
write('archives.json.gz',{'archives':archives,'count':len(archives),'source_members':members,'reason_no_replay':'No experimental code/spec/data/comparator changes;WP102 actual-caller qualification not application validation'})
oldraw=subprocess.check_output(['git','show','b259dc9:data/graph/nodes.jsonl'],cwd=R);olded=subprocess.check_output(['git','show','b259dc9:data/graph/edges.jsonl'],cwd=R)
oldlines={json.loads(l)['id']:l for l in oldraw.splitlines()};newlines={json.loads(l)['id']:l for l in (R/'data/graph/nodes.jsonl').read_bytes().splitlines()};old={i:json.loads(l) for i,l in oldlines.items()};new={i:json.loads(l) for i,l in newlines.items()};kid='LIT-198-KELLER2000'
prior=json.loads(gzip.decompress((R/'data/graph/history/GEN099-Keller-before.json.gz').read_bytes()));assert prior==old[kid] and new[kid]['version']==old[kid]['version']+1
assert len(old)==4271 and len(new)-len(old)==15;assert all(newlines[i]==l for i,l in oldlines.items() if i!=kid);assert (R/'data/graph/edges.jsonl').read_bytes().startswith(olded)
assert all(new[i]==n for i,n in old.items() if n['kind']=='connection')
for path in ['experiments','src','tests','data/graph/reading_coverage.json','data/provenance/readings/F-198.json','reports/families']:
 assert not subprocess.check_output(['git','diff','--name-only','b259dc9','--',path],cwd=R,text=True).strip(),path
write('canonical-preservation.json.gz',{'base':'b259dc9','old_records':4271,'other_old_records_byte_exact':4270,'exact_Keller_prior_archived':True,'all_old_edge_bytes_exact':True,'all_old_candidates_and_experiments_and_source_code_and_tests_exact':True,'WP101_reading_ledger_and_coverage_and_all_old_family_reports_exact':True,'new_records':15,'new_edges':38,'new_application_runs':0})
ledger=json.loads((R/'data/provenance/demand/F-198-rectification-contracts.json').read_text());A=ledger['acquisition']
for f in ledger['selected_source_files']:
 b=(T/f['temporary_name']).read_bytes();assert sha(b)==f['sha256'];assert all(1<=a<=z<=len(b.decode().splitlines()) for a,z in f['actual_body_read_ranges'])
k=ledger['old_original'];assert sha((T/k['name']).read_bytes())==k['sha256'];assert len(k['actual_pdf_pixels'])==4
for p in k['actual_pdf_pixels']:assert sha((T/p['image_name']).read_bytes())==p['image_sha256'] and p['pixels_actually_viewed']
assert len(ledger['projects'])==3 and A['downloaded_bytes']<=8388608 and not any(x['admitted_rectification_batch'] for x in ledger['operation_contracts'])
assert not ledger['numeric_or_symbolic_run'] and ledger['new_candidates']==ledger['new_initial_checks']==0
from ai_value.reporting import render
v=render(R);ss=[s for n in new.values() for s in n['sources']]
write('source-contracts.json.gz',{'projects':3,'selected_source_files':len(ledger['selected_source_files']),'actual_selected_lines':ledger['selected_source_lines'],'old_original':1,'actual_pixels':4,'source_and_image_hashes_verified':True,'complete_caller_admitted':False,'all_canonical_annotations':len(ss),'local_annotations':sum('path'in s for s in ss),'external_annotations':sum('url'in s for s in ss),'external_without_byte_hash':sum('url'in s and not s.get('sha256') for s in ss),'download_bytes':A['downloaded_bytes'],'metrics':v,'full_history_unknown':True})
print(json.dumps({'nodes':len(nodes),'edges':len(edges),'canonical_records':len(new),'impact_cases':len(cases),'archives':len(archives),'source_members':members,'new_canonical':15,'new_edges':38,'canonical_citations':len(ss)}))
