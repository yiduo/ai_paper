from acquire import fetch
for n,u in [
 ('sagemath--sage--src--sage--homology--chain_homotopy.py','https://raw.githubusercontent.com/sagemath/sage/981d7d71a2738778c9e3fb4fdf67a0fd3ce0c19c/src/sage/homology/chain_homotopy.py'),
 ('sagemath--sage--src--sage--homology--algebraic_topological_model.py','https://raw.githubusercontent.com/sagemath/sage/981d7d71a2738778c9e3fb4fdf67a0fd3ce0c19c/src/sage/homology/algebraic_topological_model.py'),
 ('gheber--kenzo--kenzo.asd','https://raw.githubusercontent.com/gheber/kenzo/f68ee7a809b4846f508cb19ee70bba5c92a0f7b2/kenzo.asd'),
 ('gap-packages--qpa--lib--derivedcat.gi','https://raw.githubusercontent.com/gap-packages/qpa/f24fe86545ecbf2ebf2d66ed5c7474b558596084/lib/derivedcat.gi'),
 ('Keller1999v1.pdf','https://arxiv.org/pdf/math/9910178v1')]:fetch(n,u)
