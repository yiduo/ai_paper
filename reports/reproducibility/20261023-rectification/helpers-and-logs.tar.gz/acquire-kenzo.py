from acquire import fetch
for p in ['src/kenzo-9/effective-homology.lisp','src/kenzo-9/lp-space-efhm.lisp']:
 fetch('gheber--kenzo--'+p.replace('/','--'),'https://raw.githubusercontent.com/gheber/kenzo/f68ee7a809b4846f508cb19ee70bba5c92a0f7b2/'+p)
