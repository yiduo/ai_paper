from pathlib import Path
import json,gzip,hashlib,tarfile,io,datetime,subprocess
R=Path('/Users/smzdm/projects/ai_paper');T=Path('/private/tmp/ai-paper-WP102');O=R/'reports/reproducibility/20261023-rectification';now=datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda b:hashlib.sha256(b).hexdigest()
def write(p,j):(R/p).write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
clean=json.loads(gzip.decompress((O/'no-math-clean-directory.json.gz').read_bytes()));assert clean['exit_code']==0 and not clean['upstream_math_present'] and not (T/'no-math-clean').exists()
assert 'Ran 69 tests' in (T/'core.log').read_text() and '\nOK\n' in (T/'core.log').read_text()
assert not subprocess.check_output(['git','-C','math','status','--porcelain'],cwd=R,text=True).strip();assert subprocess.check_output(['git','-C','math','rev-parse','HEAD'],cwd=R,text=True).strip()=='1581d4cbdd69a0faf34b2089614fe2a814316a6a'
assert sha((R/'722篇AI数学论文应用价值挖掘纲领.md').read_bytes())=='96fad398177fc3a54a87c07867456c5d84e66a7d538500b00ca4797d0a749c6e'
ledger=json.loads((R/'data/provenance/demand/F-198-rectification-contracts.json').read_text());A=ledger['acquisition'];acq=[f for f in A['requests'] if f.get('status')==200];assert len(acq)==9 and sum(f['bytes'] for f in acq)==389827
for f in acq:assert sha((T/f['name']).read_bytes())==f['sha256']
for p in ledger['old_original']['actual_pdf_pixels']:assert sha((T/p['image_name']).read_bytes())==p['image_sha256'] and p['pixels_actually_viewed']
oldraw=subprocess.check_output(['git','show','b259dc9:data/graph/nodes.jsonl'],cwd=R);oldline=next(l for l in oldraw.splitlines(keepends=True) if json.loads(l)['id']=='LIT-198-KELLER2000');assert gzip.decompress((R/'data/graph/history/GEN099-Keller-original-line.jsonl.gz').read_bytes())==oldline
raw_names={f['name'] for f in acq}|{'Keller1999v1.txt'}|{p['image_name'] for p in ledger['old_original']['actual_pdf_pixels']};raw=[T/n for n in sorted(raw_names)];assert all(p.is_file() for p in raw)
meta=[{'name':p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'retention':'Removed after actual version/source/line/page/image provenance saved;not redistributed'} for p in raw]
helpers=[p for p in T.iterdir() if p.is_file() and p.name not in raw_names];assert all(p.suffix in {'.py','.log','.json'} for p in helpers);mem={p.name:p.read_bytes() for p in helpers};buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as tar:
 for n,b in sorted(mem.items()):
  x=tarfile.TarInfo(n);x.size=len(b);x.mtime=0;x.mode=0o644;tar.addfile(x,io.BytesIO(b))
b=buf.getvalue();z=gzip.compress(b,mtime=0);assert gzip.decompress(z)==b
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(z)),mode='r:') as tar:
 assert set(tar.getnames())==set(mem)
 for n,v in mem.items():assert tar.extractfile(n).read()==v
out=O/'helpers-and-logs.tar.gz';out.write_bytes(z);assert gzip.decompress(out.read_bytes())==b
storage={'at':now,'temporary_root':str(T),'primary_software_projects':3,'old_original_PDFs':1,'acquired_source_files':8,'downloaded_bytes':389827,'actual_pixels':4,'temporary_raw_files':meta,'temporary_raw_bytes_removed':sum(x['bytes'] for x in meta),'own_archive':str(out.relative_to(R)),'compressed_bytes':len(z),'uncompressed_tar_bytes':len(b),'compressed_sha256':sha(z),'uncompressed_tar_sha256':sha(b),'member_bytes':sum(map(len,mem.values())),'members':{n:{'bytes':len(v),'sha256':sha(v)} for n,v in sorted(mem.items())},'all_decompressed_member_bytes_verified_before_plaintext_removal':True,'failed_retrievals_retained':True,'official_math_clean_pinned':True,'root_charter_hash_unchanged':True,'new_numerical_experiment_data':False,'software_installed_or_invoked':False,'external_fulltext_republished':False,'temporary_root_removed':False}
for p in raw:assert sha(p.read_bytes())==next(x['sha256'] for x in meta if x['name']==p.name);p.unlink()
for p in helpers:assert p.read_bytes()==mem[p.name];p.unlink()
T.rmdir();storage['temporary_root_removed']=not T.exists();write('reports/reproducibility/20261023-rectification/storage.json',storage)
(O/'quality.md').write_text(f'''# WP102 quality receipt

2026-10-23. Bounded actual-caller/input qualification for the F198 finite three-column component. No new candidate, initial check, scientific experiment, software benchmark, human review or second-provider invocation.

- Existing Python3.12.14 and bundled Node: all 69 core tests without skips, canonical validation, report generation and source audit passed. No production source or test changes, and no installs.
- Fifteen new canonical records and 38 explicit relations. Keller's old bibliography-only record was versioned with an exact archived record object and separate exact original JSONL bytes, verified against b259dc9. All other 4,270 old record lines and all old edge bytes are exact. All 43 candidates, scientific code/plans/data/comparators, WP101 reading ledger/coverage and old family reports remain exact.
- Full graph 7,011 nodes / 19,203 relations; 7,413 canonical annotations, 7,403 in core-validated types; 6,883 local hashed, 530 external without retained original bodies, 355 without byte hash. Full JSON/GraphML objects equal graph.load. Nineteen new/old propagation cases passed: actual software/Keller changes route qualification review without becoming a mandatory premise of the original F198 main theorem. Full dependency grades remain unknown.
- Three fixed original software projects, eight selected files, 2,164 actually read lines. Actual QPA comparison/resolution/cone and Sage contraction/model callers plus Kenzo loop-space perturbation callers inspected. General complex/homotopy data are partial matches, not complete right-B/projective/three-vertex/independent-relation/homotopy inputs or a strict-action judge. No whole-project feature absence, installed runtime or measured performance is asserted.
- One original Keller v1 PDF hash and four actually inspected image hashes verified. Two-term finite construction, general lifting vanishing, strong-action bar/unit conditions and bounded truncation are separate. Selected sections/proofs do not close all coalgebra/morphism/recursive historical dependencies, and no equivalence to every F198 input is inferred.
- All 15 scientific archives / 267 source members passed compressed, uncompressed and source-input hashes. No scientific replay because experimental code/spec/data/judge did not change. Archive integrity is not a new application test; prior environment-specific replay limitations remain.
- Independent clean directory contains no math: {clean['files']:,} files / {clean['copied_bytes']:,} bytes; every copied file byte hash checked; the core/validation/report/provenance workflow exit 0. Source audit without upstream uses the pinned inventory, not fresh upstream bytes. Clean directory removed; later receipt-only writes do not imply another scientific run.
- New downloads 389,827 bytes below 8MiB and within three project scopes, plus one required old baseline original. API403, normal TLS timeouts and corrected root-path404 evidence retained. Sage tag object a4ca0fe6 is distinct from peeled commit981d7d71. Kenzo live ASDF web metadata is not pinned byte evidence. No clones, cache, large dependencies or software installation.
- Temporary external PDF/source/text/image bytes {storage['temporary_raw_bytes_removed']:,} hash-verified and removed after provenance recorded. Own helpers/logs {storage['member_bytes']:,} bytes compressed to {len(z):,} bytes; all decompressed member bytes verified before plaintext removal. No third-party source or original PDF redistribution. Failed retrievals remain in the compressed acquisition record.
- Upstream math remains pinned and clean, root Chinese charter hash unchanged. No GitHub push/write; daily local commits only, meaningful milestone publication batches. Current local evidence is separate from the last verified public f0c3ddc and its scoped CI.

54 read families / 49 current-source drafts, 43 candidates / 13 checks / 13 distinct hypotheses / five narrowly supported / eight adverse remain unchanged. Complete families/history, human grades/spec reviews, second provider and pilots remain zero. WP103 F304 has only README and source inventory read, not source-body coverage. Retrospective counter 1 after036; after WP104 do037 or earlier major evidence. Overall active_incomplete.
''')
c=json.loads((R/'state/checkpoint.json').read_text());c['saved_at']=now;c['storage_receipt']='reports/reproducibility/20261023-rectification/storage.json';c['recovery_observation'].update(checkpoint_core_check='69core19impact/fullcanonical-sourceFKgates/wholeJSONGraphML/15archives267members/no-mathclean exit0;ownhelperscompressed/decompressedverified;temporaryrootremoved',research_processes_observation='All WP102 core/QA/no-math sessions terminal;no scientific experiment/preview/software benchmark started');write('state/checkpoint.json',c)
print(json.dumps({'clean_files':clean['files'],'clean_bytes':clean['copied_bytes'],'raw_removed':storage['temporary_raw_bytes_removed'],'own_compressed':len(z),'temp_removed':not T.exists(),'github_push':False}))
