from acquire import fetch,T
import json
repos={'gap-packages/qpa':{'commit':'f24fe86545ecbf2ebf2d66ed5c7474b558596084','ref':'HEAD'},'sagemath/sage':{'commit':'a4ca0fe6e7b556609bed7395ffd7f5cd262c9ba2','ref':'refs/tags/10.8','tag_object_not_yet_peeled':True},'gheber/kenzo':{'commit':'f68ee7a809b4846f508cb19ee70bba5c92a0f7b2','ref':'HEAD'}}
(T/'repositories.json').write_text(json.dumps(repos,indent=2)+'\n')
files={'gap-packages/qpa':['lib/complex.gi','lib/complex.gd','read.g','PackageInfo.g'],'sagemath/sage':['src/sage/homology/chain_homotopy.py','src/sage/homology/algebraic_topological_model.py','src/sage/homology/homology_vector_space_with_basis.py'],'gheber/kenzo':['kenzo.asd','src/effective-homology.lisp','README.md']}
for repo,paths in files.items():
 for path in paths:fetch(repo.replace('/','--')+'--'+path.replace('/','--'),'https://raw.githubusercontent.com/'+repo+'/'+repos[repo]['commit']+'/'+path)
