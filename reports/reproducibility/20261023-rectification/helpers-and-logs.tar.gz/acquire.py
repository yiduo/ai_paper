from pathlib import Path
import urllib.request,json,hashlib,datetime
T=Path('/private/tmp/ai-paper-WP102');LOG=T/'acquisition.json';cap=8388608
state=json.loads(LOG.read_text()) if LOG.exists() else {'cap_bytes':cap,'downloaded_bytes':0,'requests':[]}
def fetch(name,url):
 if any(x.get('name')==name and x.get('status')==200 for x in state['requests']):return
 row={'name':name,'url':url,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'ai-paper-research/0.1','Accept':'application/vnd.github+json' if 'api.github.com' in url else '*/*'})
  with urllib.request.urlopen(req,timeout=25) as f:
   b=f.read(cap-state['downloaded_bytes']+1);assert len(b)<=cap-state['downloaded_bytes'];row.update(status=f.status,final_url=f.url,bytes=len(b),sha256=hashlib.sha256(b).hexdigest());(T/name).write_bytes(b);state['downloaded_bytes']+=len(b)
 except Exception as e:row['error']=repr(e)
 state['requests'].append(row);LOG.write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n');print(json.dumps(row),flush=True)
if __name__=='__main__':
 for n,u in [('qpa-head.json','https://api.github.com/repos/gap-packages/qpa/commits/master'),('sage-head.json','https://api.github.com/repos/sagemath/sage/commits/10.8'),('kenzo-head.json','https://api.github.com/repos/gheber/kenzo/commits/master')]:fetch(n,u)
