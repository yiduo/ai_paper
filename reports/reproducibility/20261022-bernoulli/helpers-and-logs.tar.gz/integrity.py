from pathlib import Path
import subprocess,json,gzip,hashlib,sys,datetime
r=Path('/Users/smzdm/projects/ai_paper');sys.path.insert(0,str(r/'src'))
from ai_value.graph import load,impact_report,theoretical_grade
o=r/'reports/reproducibility/20261022-bernoulli';sha=lambda x:hashlib.sha256(x).hexdigest()
before=subprocess.check_output(['git','show','HEAD:data/graph/nodes.jsonl'],cwd=r);after=(r/'data/graph/nodes.jsonl').read_bytes();assert after.startswith(before)
assert (r/'data/graph/edges.jsonl').read_bytes().startswith(subprocess.check_output(['git','show','HEAD:data/graph/edges.jsonl'],cwd=r))
assert gzip.decompress((r/'data/graph/history/GEN083-reading-coverage-before.json.gz').read_bytes())==subprocess.check_output(['git','show','HEAD:data/graph/reading_coverage.json'],cwd=r)
old={json.loads(l)['id']:json.loads(l) for l in before.decode().splitlines()};canon=[json.loads(l) for l in after.decode().splitlines()];assert len(old)==3452 and len(canon)==3530
nodes,edges=load(r);local_count=0;external_count=0
for n in canon:
 for s in n['sources']:
  if 'path' in s:assert sha((r/s['path']).read_bytes())==s['sha256'],(n['id'],s['path']);local_count+=1
  else:external_count+=1
claims=[n for n in canon if n['kind']=='claim' and n['id'].startswith('CLM-153-')];assert len(claims)==24;assert all(n['properties']['credibility']=='C' and theoretical_grade(nodes,edges,n['id'])=='unknown' for n in claims)
analysis=nodes['ANALYSIS-F-153']['properties'];assert len(analysis['result_ids_by_label'])==24 and sum(len(n['properties'].get('natural_label_aliases',[])) for n in claims)==2
unchanged=[]
for p in (r/'experiments/runs').glob('*/*'):
 if p.is_file():assert p.read_bytes()==subprocess.check_output(['git','show','HEAD:'+str(p.relative_to(r))],cwd=r);unchanged.append(str(p.relative_to(r)))
assert len([n for n in canon if n['kind']=='connection'])==40
cases=[]
for seed,yes,no in [
 ('HIST-153-GK-RH',['CLM-153-CLS-PRESCRIBED-PRIME','CLM-153-CLS-REALIZATION','CLM-153-CLS-CLASSIFICATION'],['CLM-153-SAL-MAIN','CLM-153-NP-MAIN','APP-094-02','APP-332-01']),
 ('CLM-153-CLS-CLASSIFICATION',['CLM-153-CLS-GARSIA','CLM-153-CLS-PISOT','PART-153-QUANTIFIER-ORDER'],['CLM-153-SAL-MAIN','CLM-153-NP-MAIN','PART-153-AR1-AFFINE']),
 ('CLM-153-SAL-CONSTRUCTION',['CLM-153-SAL-LOSS','CLM-153-SAL-MAIN','CLM-153-SAL-EXAMPLES'],['CLM-153-NP-MAIN','CLM-153-CLS-CLASSIFICATION']),
 ('CLM-153-SAL-MAIN',['CLM-153-SAL-EXAMPLES','PART-153-WINDOW-SEPARATION'],['CLM-153-NP-MAIN','CLM-153-CLS-CLASSIFICATION']),
 ('PART-153-WEAK-TAIL',['CLM-153-NP-MOMENTS','CLM-153-NP-TYPICAL-GAIN','CLM-153-NP-MAIN'],['CLM-153-NP-ROOTS','CLM-153-SAL-MAIN','CLM-153-CLS-CLASSIFICATION']),
 ('PART-153-ROOT-DISK-CERTIFICATE',['CLM-153-NP-ROOTS','CLM-153-NP-LATTICE','CLM-153-NP-MAIN'],['CLM-153-SAL-MAIN','CLM-153-CLS-CLASSIFICATION','APP-094-02']),
 ('CHECK-153-VERIFIER-SCOPE',[],['CLM-153-NP-ROOTS','CLM-153-NP-MOMENTS','CLM-153-NP-MAIN']),
 ('LIT-153-GARSIA1962',[],['CLM-153-CLS-GARSIA','CLM-153-CLS-CLASSIFICATION','CLM-153-NP-MAIN']),
 ('HIST-153-KERN-AR1',['PART-153-AR1-AFFINE','PART-153-AR1-CONSUMER-GAP','XPL-153-TEN-DOMAINS'],['CLM-153-CLS-CLASSIFICATION','CLM-153-SAL-MAIN','CLM-153-NP-MAIN','APP-119-01']),
 ('PART-153-FINITE-CLASSIFIER-GAP',[],['CLM-153-CLS-CLASSIFICATION','CLM-153-SAL-MAIN','CLM-153-NP-MAIN','APP-094-02']),
 ('HIST-153-BAKER-RANDOM',[],['CLM-153-SAL-MAIN','CLM-153-NP-MAIN','XPL-153-TEN-DOMAINS']),
]:
 q=impact_report(nodes,edges,{seed});a=set(q['affected']);assert set(yes)<=a,(seed,yes,a);assert not set(no)&a,(seed,no,a);cases.append(dict(seed=seed,required=yes,excluded=no,affected=sorted(a)))
out=dict(recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),old_canonical_unchanged=3452,new_canonical=78,canonical_total=3530,all_old_edges_exact=True,coverage_prior_exact=True,source_claims=24,source_claim_aliases=2,source_grades='24C',complete_dependency_grade='unknown',local_source_hashes_verified=local_count,external_annotations=external_count,canonical_citations=local_count+external_count,impact_cases=cases,experiment_files_unchanged=len(unchanged),new_numerical_run=False,new_candidate=0,new_initial_check=0,original_source_verifier_executed=False)
(o/'integrity.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:out[k] for k in ['canonical_total','local_source_hashes_verified','external_annotations','canonical_citations','experiment_files_unchanged']})+';11 scoped impact cases passed')
