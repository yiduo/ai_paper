from pathlib import Path
import ast,re,json,hashlib
root=Path('/Users/smzdm/projects/ai_paper/math/preprints/Arithmetic-classification-and-non-Pisot-singularity-for-Bernoulli-convolutions-October-3-2026');text=(root/'verification/verify_degree31.py').read_text();tree=ast.parse(text);values={}
for n in tree.body:
 if isinstance(n,ast.Assign):
  for target in n.targets:
   if isinstance(target,ast.Name):
    try:values[target.id]=ast.literal_eval(n.value)
    except (ValueError,TypeError):pass
tex=(root/'build/certificate.tex').read_text();centers=[(int(a),int(b)) for a,b in re.findall(r'^(-?\d+)\s*&\s*(-?\d+)',tex,re.M)];assert centers==values['ROOT_CENTERS'] and len(centers)==16
for k in ['EXPECTED_CORRELATION','EXPECTED_VARIANCE','EXPECTED_BIG_GRAM']:assert str(values[k]) in tex
assert all(str(x) in tex for x in values['EXPECTED_FACTORS'])
imports=[ast.unparse(n) for n in ast.walk(tree) if isinstance(n,(ast.Import,ast.ImportFrom))];assert imports==['from fractions import Fraction'];assert not any(isinstance(n,ast.Constant) and isinstance(n.value,float) for n in ast.walk(tree))
r={'source_sha256':hashlib.sha256(text.encode()).hexdigest(),'AST_parsed_not_imported_or_executed':True,'imports':imports,'float_literals':0,'root_center_representatives_match_TeX':16,'named_output_integers_match_TeX':6,'script_executed':False,'arithmetic_certificate_verified':False,'analytic_infinite_product_bounds_verified':False,'scope':'Static data/order contract review only;does not recompute integer equalities or prove analytic tail bounds.','helper_initial_failure':'First regex required trailing TeX row separator and omitted the final row;fixed to parse two numeric columns. Source table/code were not changed.'};Path('/private/tmp/ai-paper-F153/static-verifier-review.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
