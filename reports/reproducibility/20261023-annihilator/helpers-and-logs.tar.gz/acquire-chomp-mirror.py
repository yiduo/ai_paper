from pathlib import Path
import urllib.request,json,hashlib,datetime
T=Path('/private/tmp/ai-paper-WP104');a=json.load(open(T/'acquisition.json'));u='https://chomp.rutgers.edu/Projects/Computational_Homology/OriginalCHomP/libdoc/chomp_2homology_2homology_8h_source.html';x={'name':'chomp-homology-source.html','url':u,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'One official OriginalCHomP mirror fallback after originalhost TLS failures;not another softwareproject'};a['requests'].append(x)
try:
 with urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'ai-paper-research/1.0'}),timeout=25) as r:
  b=r.read(min(3*1024*1024,8388608-a['downloaded_bytes'])+1);assert len(b)<=min(3*1024*1024,8388608-a['downloaded_bytes']);x.update(status=r.status,final_url=r.geturl(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest());(T/x['name']).write_bytes(b);a['downloaded_bytes']+=len(b)
except Exception as e:x['error']=repr(e)
(T/'acquisition.json').write_text(json.dumps(a,indent=2)+'\n');print(json.dumps(x))
