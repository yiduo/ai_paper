from pathlib import Path
T=Path('/private/tmp/ai-paper-WP104');s=(T/'prior/qa.py').read_text();a=s.index('ex=export(R)');z=s.index("oldraw=subprocess.check_output",a);middle=s[a:z].replace('one new conditional unrun plan is not executable scientific code','new actual-consumer qualification only;no scientific code or spec changes')
header=s[:a].replace('ai-paper-WP103','ai-paper-WP104').replace('20261023-hilbert-smith','20261023-annihilator').replace("BASE='46923f1'","BASE='4c33ac0'")
needle="assert all(theoretical_grade(nodes,edges,i)=='unknown'"
pos=header.index(needle)
more="""check('new_Sage_actualconsumer_qualification',['LIT-304-SAGE-INTEGRAL-HOMOLOGY'],['XPL-304-ANNIHILATOR-CALLERS',app],[main,lie,chase])
check('new_Kenzo_constructiveoutput_qualification',['LIT-304-KENZO-SMITH-CALLERS'],['XPL-304-ANNIHILATOR-CALLERS',app],[main,lie,chase])
check('CHomP_docs_not_sourceproof',['LIT-304-CHOMP-ORIGINAL-INTERFACE'],['XPL-304-ANNIHILATOR-CALLERS',app],[main,lie,chase])
check('rationalrank_not_integerq_certificate',['CHECK-304-RATIONAL-RANK-NOT-INTEGRAL-COKERNEL'],['XPL-304-ANNIHILATOR-CALLERS',app],[main,lie,chase])
"""
header=header[:pos]+more+header[pos:]
(T/'qa.py').write_text(header+middle+'''
oldraw=subprocess.check_output(['git','show',BASE+':data/graph/nodes.jsonl'],cwd=R);olded=subprocess.check_output(['git','show',BASE+':data/graph/edges.jsonl'],cwd=R);raw=(R/'data/graph/nodes.jsonl').read_bytes();eraw=(R/'data/graph/edges.jsonl').read_bytes();assert eraw.startswith(olded)
oldlines={json.loads(l)['id']:l for l in oldraw.splitlines()};newlines={json.loads(l)['id']:l for l in raw.splitlines()};old={i:json.loads(l) for i,l in oldlines.items()};cur={i:json.loads(l) for i,l in newlines.items()};assert len(old)==4399 and len(cur)==4412;assert all(newlines[i]==l for i,l in oldlines.items() if i!='APP-304-01')
prior=json.loads(gzip.decompress((R/'data/graph/history/GEN101-APP30401-before.json.gz').read_bytes()));assert prior==old['APP-304-01'];exact=gzip.decompress((R/'data/graph/history/GEN101-APP30401-original-line.jsonl.gz').read_bytes());assert exact.rstrip(b'\\n')==oldlines['APP-304-01'];assert cur['APP-304-01']['version']==2
for k,v in old['APP-304-01']['properties'].items():
 if k!='priority_reason':assert cur['APP-304-01']['properties'][k]==v,k
assert cur['APP-304-01']['sources'][:-1]==old['APP-304-01']['sources']
for prefix in ['experiments','src','tests','data/provenance/readings','reports/families','data/graph/reading_coverage.json']:
 paths=subprocess.check_output(['git','ls-tree','-r','--name-only',BASE,'--',prefix],cwd=R,text=True).splitlines()
 for p in paths:assert (R/p).read_bytes()==subprocess.check_output(['git','show',BASE+':'+p],cwd=R),p
write('canonical-preservation.json.gz',{'base':BASE,'old_records':4399,'other_old_record_lines_exact':4398,'old_edges_exact':True,'APP30401_exact_prior_object_and_line_retained':True,'APP30401_original_prediction_plan_roles_summary_source_unchanged':True,'all_other_candidates_and_oldexperiments_sources_tests_readingledgers_familyreports_coverage_exact':True,'new_records':13,'new_explicit_edges':31,'new_candidates':0,'new_initial_checks':0})
l=json.loads((R/'data/provenance/demand/F-304-annihilator-contracts.json').read_text());assert len(l['projects'])==3 and len(l['selected_source_files'])==6 and l['selected_source_lines']==1597 and l['acquisition']['downloaded_bytes']==195414
for f in l['selected_source_files']:assert sha((T/f['temporary_name']).read_bytes())==f['sha256']
assert not any(c['admitted_complete_batch'] for c in l['projects']);assert l['new_candidates']==l['new_initial_checks']==0 and not l['numeric_or_symbolic_run']
for n in ['replay221.json','replay325.json']:
 j=json.loads((OUT/n).read_text());assert all(j['deterministic_outputs_match'].values()) and j['comparison_scope']=='Exact complete JSON payloads; no fields excluded';assert j['replay_resource_envelope_met'] is not False
m=render(R);ss=[s for n in cur.values() for s in n['sources']];assert m['candidate_connections']==44 and m['externally_checked_cards']==13 and m['partial_reading_families']==55 and m['source_decomposition_drafts']==50
write('source-contracts.json.gz',{'project_scopes':3,'actualbodyprojects':2,'officialdocsonlyprojects':1,'selected_files':6,'actualreadlines':1597,'all_source_hashes_verified':True,'new_candidates':0,'new_initial_checks':0,'full_history_unknown':True,'all_canonical_annotations':len(ss),'local_annotations':sum('path'in s for s in ss),'external_annotations':sum('url'in s for s in ss),'external_without_byte_hash':sum('url'in s and not s.get('sha256') for s in ss),'metrics':m,'two_replays':'ExactcompleteJSONmatches;existinghypotheses,notnewexperiments'})
print(json.dumps({'nodes':len(nodes),'edges':len(edges),'canonical_records':len(cur),'impact_cases':len(cases),'archives':len(archives),'source_members':members,'canonical_citations':len(ss),'core_citations':m['citations_checked'],'local_annotations':sum('path'in s for s in ss),'external_annotations':sum('url'in s for s in ss),'external_without_byte_hash':sum('url'in s and not s.get('sha256') for s in ss)}))
''')
