from pathlib import Path
R=Path('/Users/smzdm/projects/ai_paper')
(R/'reports/F304-annihilator-interface-audit.md').write_text('''# F304：有限湮灭证书的实际调用资格

WP104，2026-10-23。规范依据 `data/provenance/demand/F-304-annihilator-contracts.json`。本包至多三个原始软件项目，正常TLS下载195414字节；六个固定源码文件实际选读1597行。没有安装、执行Sage／Kenzo／CHomP，也没有新的数值或符号实验。

## 资格结论

原引理需要两条五项正合阿贝尔群行、全部交换映射，以及四个外层映射核与余核的共同正整数湮灭证书q，才推出中间q³充分界。q³没有提供不变因子、最小指数、生成元、逆映射或构造性提升。本包未找到同时提供完整输入并只接受松界的真实批次。APP30401版本2仍近类比／待定，降低数值实现优先级；不是正式否定，也不证明软件中不存在其他调用。原预测、计划、空run、局部C／完整链未知和旧隔离角色意见保持，精确前版对象及原JSONL均压缩留存。

## Sage10.8：群、链映射与域上的诱导映射

固定剥离commit981d7d71a2738778c9e3fb4fdf67a0fd3ce0c19c，不把标签对象或滚动手册当作相同字节证据。实际ChainComplexMorphism构造器核尺寸和dF=Fd，这只是链映射交换条件，不给五项行的im=ker、关系格饱和或外层湮灭数。

ChainComplex.homology在ZZ上计算elementary divisors，有按规模选择的PARI／DHSW路径；带生成元时还计算出射核、HNF、SNF及逆变换。HomologyGroup的输出含实际不变因子与自由部分。标量q³不能替代这些请求。

InducedHomologyMorphism实际构造器拒绝非域系数，to_matrix使用pi*F*iota；实际求值与等同性都消费矩阵。它不能直接作为整数扭群的对比负载。另一个链级对象的is_surjective采用rank==nrows：整数满有理秩不证明整数余核为零，不能拿它免费认证q=1。这里是静态范围／契约观察，没有运行、作者确认的错误报告或对整个Sage的结论。

## Kenzo：构造性输出仍需要变换

固定f68ee7a809b4846f508cb19ee70bba5c92a0f7b2。CHCM-MAT拒绝locally-effective基，实际有限基才形成矩阵；homologie同步约化相邻边界并保留扭系数与代表元。chcm-homology/gen打印整数分量或返回循环。

LIST-SMITH／SMITH保留五矩阵变换；ECHCM-KILL-EPI检查单位对角并构造f/g/h，CHML-CLSS-INTR使用逆基系数。这些调用需要q³没有返回的数据。源码旧随机例注释和后续safe算术警告保留为原文观察，未执行，不推断整个Kenzo失败或完整整数位复杂度已知。

## OriginalCHomP：实际文档，正文访问缺口

检查的是Paweł Pilarczyk原版本官方页面，未将不同能力的Rutgers新版GitHub工程混为同版本。官方程序文档描述homchain在ZZ或素域上的群与诱导同态、homcubes相对群／映射及homcub2l指数映射；库参考描述整数链复形／链映射、简单形约化与生成元／矩阵输出。

主机HTML及源zip两次正常TLS超时，一次Rutgers官方源码镜像回退也超时；网页工具对zip不支持、源页cachemiss均记录。没有取得源包散列或调用体。2024日期只是网页标签，不能当作固定包版本。此项目仅有官方接口文档核对，不计源码阅读或全项目缺功能证明；达到三项目范围后停止扩搜。

## 强旧基线与后续

现有调用要求更强构造性对象，保守界不能无损替换；假使以后找到真正只需充分界的任务，也须比较同输出的缓存SNF、HNF／格成员判断，以及已有定量五引理追踪，允许分别使用外层更小湮灭数。计入q发现、正合／交换／良定义证书、提升、整数位长、验证、缓存、回退和松界下游成本，不能只比较q³公式时间。

13新规范记录、31显式边；除版本化候选外4398旧规范行及全部旧边保持原字节。候选44、初检13、不同假设13、限定支持5／不利8不变。原F304阅读台账和50份族报告保持，完整族／历史／人审／第二供应商0。质量以 `reports/reproducibility/20261023-annihilator/quality.md` 的实际收据为准。

本包完成后强制复盘037，停止继续扩搜未准入输入。真实消费者和有效有限接口仍可使候选重启；不为初检配额制造q³示例。原始软件字节不再分发，保留URL、固定版本、散列与自撰范围；自有助手／失败日志压缩回解核验。GitHub本包不更新，官方math只读不部署，总目标active_incomplete。
''')
