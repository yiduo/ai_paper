from pathlib import Path
import urllib.request,urllib.parse,json,hashlib,datetime,re
T=Path('/private/tmp/ai-paper-WP104');cap=8388608;out={'cap_bytes':cap,'downloaded_bytes':0,'requests':[]}
def save(): (T/'acquisition.json').write_text(json.dumps(out,indent=2)+'\n')
def get(name,url):
 row={'name':name,'url':url,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()};out['requests'].append(row);save()
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'ai-paper-research/1.0'})
  with urllib.request.urlopen(req,timeout=25) as r:
   b=r.read(min(3*1024*1024,cap-out['downloaded_bytes'])+1);assert len(b)<=min(3*1024*1024,cap-out['downloaded_bytes']);row.update(status=r.status,final_url=r.geturl(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest());(T/name).write_bytes(b);out['downloaded_bytes']+=len(b)
 except Exception as e:row['error']=repr(e)
 save();print(json.dumps(row),flush=True)
sage='981d7d71a2738778c9e3fb4fdf67a0fd3ce0c19c';kenzo='f68ee7a809b4846f508cb19ee70bba5c92a0f7b2'
for f in ['chain_complex_morphism.py','chain_complex.py','homology_group.py']:get('sage--'+f,'https://raw.githubusercontent.com/sagemath/sage/'+sage+'/src/sage/homology/'+f)
for f in ['homology-groups.lisp','new-smith.lisp']:get('kenzo--'+f,'https://raw.githubusercontent.com/gheber/kenzo/'+kenzo+'/src/kenzo-9/'+f)
url='https://www.pawelpilarczyk.com/chomp/download/';get('chomp-download.html',url)
p=T/'chomp-download.html'
if p.exists():
 links=re.findall(r'href=[\"\x27]([^\"\x27]*chomp-full\.zip)[\"\x27]',p.read_text(errors='replace'),flags=re.I);assert len(set(links))==1;get('chomp-full.zip',urllib.parse.urljoin(url,links[0]))
