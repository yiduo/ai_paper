from pathlib import Path
import json,gzip,hashlib,sys,subprocess,xml.etree.ElementTree as ET
R=Path('/Users/smzdm/projects/ai_paper');T=Path('/private/tmp/ai-paper-WP104');OUT=R/'reports/reproducibility/20261023-annihilator';BASE='4c33ac0';sys.path.insert(0,str(R/'src'))
from ai_value.graph import load,affected_nodes,theoretical_grade
from ai_value.knowledge import export
from ai_value.reporting import render
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(n,j):
 b=(json.dumps(j,ensure_ascii=False,indent=2)+'\n').encode();z=gzip.compress(b,mtime=0);assert gzip.decompress(z)==b;(OUT/n).write_bytes(z)
nodes,edges=load(R);cases=[];lie='CLM-304-COR-LIE';main='CLM-304-THM-MAIN';flow='CLM-304-UNLABELLED-FLOW-ITERATE';app='APP-304-01';chase='CLM-304-LAT-FINITE-CHASES'
def check(name,seed,yes,no):
 h=affected_nodes(nodes,edges,set(seed));assert set(yes)<=h,(name,'missing',set(yes)-h);assert not(set(no)&h),(name,'false',set(no)&h);cases.append({'name':name,'changed':seed,'expected_review':yes,'expected_unaffected':no,'affected':sorted(h),'pass':True})
check('finite_chase_routes_source_and_component',[chase],['CLM-304-THM-BOUNDED-COMPARISON',main,lie,app],['LIT-304-SERRE1951'])
check('full_Lie_not_needed_for_finite_component',[lie],[flow,'PART-304-COMPACT-CLOSURE-FLOW'],[app,chase])
check('unlabelled_flow_not_forged_premise',[flow],['PART-304-COMPACT-CLOSURE-FLOW'],[main,lie,app])
check('classical_group_reduction_required',['LIT-304-PARDON2013'],[lie,flow],[main,app])
check('Newman_required_local_chart',['LIT-304-NEWMAN1931'],[main,lie],[chase,app])
check('Serre_finiteness_required',['LIT-304-SERRE1951'],['CLM-304-LEM-ODD-SPHERE-NULL',main,lie],[app])
check('Serre_degree_killing_required',['LIT-304-SERRE1953'],[main],[chase,app])
check('old_cofinality_context_not_current_blackbox',['LIT-304-HORNBOSTELSCHLICHTING2004'],['OLD-304-COFINAL-TATE-TWO'],[main,'CLM-304-THM-DENSE-DOUBLING',app])
check('BW_integral_localization_required',['LIT-304-BALMERWALTER2002'],['CLM-304-THM-WITT-LOCALIZATION',main],[chase,app])
check('Woolf_cone_input_vs_nonidentical_category',['LIT-304-WOOLF2008'],['CLM-304-CAT-SYMMETRIC-CONE','OLD-304-PERFECT-SHEAF-HOMOTOPY',main],[chase,app])
check('uniform_denominator_not_elementwise',['CLM-304-THM-BOUNDED-COMPARISON'],['CLM-304-THM-SPHERE-LATTICE',main],[app])
check('generic_signature_old_Hardt_required',['LIT-304-HARDT1980'],[main],['CLM-304-LEM-ODD-SPHERE-NULL',app])
check('quotient_germs_required_projectors',['CLM-304-THM-GERMS'],['CLM-304-PROP-SUM-CLASSES','CLM-304-PROP-CLASS-COVARIANCE',main],[app])
check('p2_sign_appendix_actual_support',['CLM-304-CAT-PRODUCT-SHIFT-SIGN'],['CLM-304-CAT-ENDPOINT-FORMS',main],[app])
check('algebraic_characters_not_completion',['CLM-304-LEM-CHARACTER-COPRODUCT'],['CLM-304-LEM-ORTHOGONALITY',main],[app])
check('finite_local_sheets_not_freefullaction',['CLM-304-LEM-FINITE-SHEETS'],['CLM-304-PROP-EQUAL-PARTS',main],[app])
check('F198_support_route_preserved',['CLM-198-LEM-RECTIFICATION'],['CLM-198-THM-MAIN','XPL-198-RECTIFICATION-CALLERS'],[main,app])
check('F198_real_QPA_context_preserved',['LIT-198-QPA-COMPLEX'],['CHECK-198-QPA-CALLER','XPL-198-RECTIFICATION-CALLERS'],['CLM-198-THM-MAIN',main,app])
check('F196_Hatcher_old_input_preserved',['OLD-196-HATCHER-HUREWICZ-MAP'],['CLM-196-THM-MAIN'],[main,app])
check('F256_actual_map_gate_preserved',['LIT-256-GAP-FP-INTERFACE'],['APP-256-01'],[main,app])
check('new_Sage_actualconsumer_qualification',['LIT-304-SAGE-INTEGRAL-HOMOLOGY'],['XPL-304-ANNIHILATOR-CALLERS',app],[main,lie,chase])
check('new_Kenzo_constructiveoutput_qualification',['LIT-304-KENZO-SMITH-CALLERS'],['XPL-304-ANNIHILATOR-CALLERS',app],[main,lie,chase])
check('CHomP_docs_not_sourceproof',['LIT-304-CHOMP-ORIGINAL-INTERFACE'],['XPL-304-ANNIHILATOR-CALLERS',app],[main,lie,chase])
check('rationalrank_not_integerq_certificate',['CHECK-304-RATIONAL-RANK-NOT-INTEGRAL-COKERNEL'],['XPL-304-ANNIHILATOR-CALLERS',app],[main,lie,chase])
assert all(theoretical_grade(nodes,edges,i)=='unknown' for i in [lie,main,flow,app]);write('impact.json.gz',{'count':len(cases),'cases':cases,'full_grades':'unknown','meaning':'Review routing,not mathematical approval'})
ex=export(R);j=json.loads(gzip.decompress((R/'reports/graph/knowledge.json.gz').read_bytes()));assert {n['id']:n for n in j['nodes']}==nodes and j['edges']==edges
ns={'g':'http://graphml.graphdrawing.org/xmlns'};tree=ET.fromstring(gzip.decompress((R/'reports/graph/knowledge.graphml.gz').read_bytes()));gn={n.attrib['id']:json.loads(next(d.text for d in n if d.attrib.get('key')=='properties')) for n in tree.findall('.//g:node',ns)};ge={n.attrib['id']:json.loads(next(d.text for d in n if d.attrib.get('key')=='evidence')) for n in tree.findall('.//g:edge',ns)};assert gn==nodes and ge=={e['id']:e for e in edges};write('exports.json.gz',{'export':ex,'json_full_nodes_edges_exact':True,'graphml_full_nodes_edges_exact':True})
archives=[];members=0
for p in sorted((R/'experiments/runs').glob('*/manifest.json')):
 m=json.loads(p.read_text())
 for name,h in m['outputs'].items():
  b=(p.parent/name).read_bytes();assert sha(b)==h
  if name.endswith('.gz'):gzip.decompress(b)
 for name,d in m.get('compressed_payloads',{}).items():assert sha(gzip.decompress((p.parent/name).read_bytes()))==d['uncompressed_sha256']
 s=json.loads(gzip.decompress((p.parent/m['source_snapshot']).read_bytes()));assert set(s)==set(m['inputs']);assert all(isinstance(t,str) and sha(t.encode())==m['inputs'][n] for n,t in s.items());members+=len(s);archives.append({'run_id':m['run_id'],'source_members':len(s),'all_output_and_decompressed_hashes_verified':True,'scientific_replay':False})
write('archives.json.gz',{'archives':archives,'count':len(archives),'source_members':members,'reason_no_replay':'No experimental algorithm/spec/data/comparator changed;new actual-consumer qualification only;no scientific code or spec changes'})

oldraw=subprocess.check_output(['git','show',BASE+':data/graph/nodes.jsonl'],cwd=R);olded=subprocess.check_output(['git','show',BASE+':data/graph/edges.jsonl'],cwd=R);raw=(R/'data/graph/nodes.jsonl').read_bytes();eraw=(R/'data/graph/edges.jsonl').read_bytes();assert eraw.startswith(olded)
oldlines={json.loads(l)['id']:l for l in oldraw.splitlines()};newlines={json.loads(l)['id']:l for l in raw.splitlines()};old={i:json.loads(l) for i,l in oldlines.items()};cur={i:json.loads(l) for i,l in newlines.items()};assert len(old)==4399 and len(cur)==4412;assert all(newlines[i]==l for i,l in oldlines.items() if i!='APP-304-01')
prior=json.loads(gzip.decompress((R/'data/graph/history/GEN101-APP30401-before.json.gz').read_bytes()));assert prior==old['APP-304-01'];exact=gzip.decompress((R/'data/graph/history/GEN101-APP30401-original-line.jsonl.gz').read_bytes());assert exact.rstrip(b'\n')==oldlines['APP-304-01'];assert cur['APP-304-01']['version']==2
for k,v in old['APP-304-01']['properties'].items():
 if k!='priority_reason':assert cur['APP-304-01']['properties'][k]==v,k
assert cur['APP-304-01']['sources'][:-1]==old['APP-304-01']['sources']
for prefix in ['experiments','src','tests','data/provenance/readings','reports/families','data/graph/reading_coverage.json']:
 paths=subprocess.check_output(['git','ls-tree','-r','--name-only',BASE,'--',prefix],cwd=R,text=True).splitlines()
 for p in paths:assert (R/p).read_bytes()==subprocess.check_output(['git','show',BASE+':'+p],cwd=R),p
write('canonical-preservation.json.gz',{'base':BASE,'old_records':4399,'other_old_record_lines_exact':4398,'old_edges_exact':True,'APP30401_exact_prior_object_and_line_retained':True,'APP30401_original_prediction_plan_roles_summary_source_unchanged':True,'all_other_candidates_and_oldexperiments_sources_tests_readingledgers_familyreports_coverage_exact':True,'new_records':13,'new_explicit_edges':31,'new_candidates':0,'new_initial_checks':0})
l=json.loads((R/'data/provenance/demand/F-304-annihilator-contracts.json').read_text());assert len(l['projects'])==3 and len(l['selected_source_files'])==6 and l['selected_source_lines']==1597 and l['acquisition']['downloaded_bytes']==195414
for f in l['selected_source_files']:assert sha((T/f['temporary_name']).read_bytes())==f['sha256']
assert not any(c['admitted_complete_batch'] for c in l['projects']);assert l['new_candidates']==l['new_initial_checks']==0 and not l['numeric_or_symbolic_run']
for n in ['replay221.json','replay325.json']:
 j=json.loads((OUT/n).read_text());assert all(j['deterministic_outputs_match'].values()) and j['comparison_scope']=='Exact complete JSON payloads; no fields excluded';assert j['replay_resource_envelope_met'] is not False
m=render(R);ss=[s for n in cur.values() for s in n['sources']];assert m['candidate_connections']==44 and m['externally_checked_cards']==13 and m['partial_reading_families']==55 and m['source_decomposition_drafts']==50
write('source-contracts.json.gz',{'project_scopes':3,'actualbodyprojects':2,'officialdocsonlyprojects':1,'selected_files':6,'actualreadlines':1597,'all_source_hashes_verified':True,'new_candidates':0,'new_initial_checks':0,'full_history_unknown':True,'all_canonical_annotations':len(ss),'local_annotations':sum('path'in s for s in ss),'external_annotations':sum('url'in s for s in ss),'external_without_byte_hash':sum('url'in s and not s.get('sha256') for s in ss),'metrics':m,'two_replays':'ExactcompleteJSONmatches;existinghypotheses,notnewexperiments'})
print(json.dumps({'nodes':len(nodes),'edges':len(edges),'canonical_records':len(cur),'impact_cases':len(cases),'archives':len(archives),'source_members':members,'canonical_citations':len(ss),'core_citations':m['citations_checked'],'local_annotations':sum('path'in s for s in ss),'external_annotations':sum('url'in s for s in ss),'external_without_byte_hash':sum('url'in s and not s.get('sha256') for s in ss)}))
