from pathlib import Path
import json,urllib.request,hashlib,datetime
T=Path('/private/tmp/ai-paper-WP104');out=json.load(open(T/'acquisition.json'))
def get(n,u):
 x={'name':n,'url':u,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()};out['requests'].append(x)
 try:
  with urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'ai-paper-research/1.0'}),timeout=30) as r:
   b=r.read(min(3*1024*1024,8388608-out['downloaded_bytes'])+1);assert len(b)<=min(3*1024*1024,8388608-out['downloaded_bytes']);x.update(status=r.status,final_url=r.geturl(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest());(T/n).write_bytes(b);out['downloaded_bytes']+=len(b)
 except Exception as e:x['error']=repr(e)
 (T/'acquisition.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(x),flush=True)
get('chomp-full.zip','https://www.pawelpilarczyk.com/chomp/download/chomp-full.zip')
get('sage--homology_morphism.py','https://raw.githubusercontent.com/sagemath/sage/981d7d71a2738778c9e3fb4fdf67a0fd3ce0c19c/src/sage/homology/homology_morphism.py')
