from pathlib import Path
import json,gzip,hashlib,subprocess,datetime
r=Path('/Users/smzdm/projects/ai_paper');h=Path('/private/tmp/ai-paper-WP054');out=r/'reports/reproducibility/20261021-hodge-interfaces';l=json.loads((r/'data/provenance/demand/F-094-hodge-contracts.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest();p=r/l['source_archive'];assert sha(p.read_bytes())==l['source_archive_sha256'];raw=gzip.decompress(p.read_bytes());assert sha(raw)==l['source_archive_decompressed_sha256'];a=json.loads(raw);expected={}
for name,s in l['sources'].items():assert sha(a['files'][name].encode())==s['sha256'];expected[name]=s['sha256']
for i,o in enumerate(l['selected_primary_versions']):
 stem='hodgerank'if i==0 else'hodgerank-v1';expected[stem+'.pdf']=o['pdf_sha256'];expected[stem+'.txt']=o['text_sha256'];expected[o['actual_pixel']['name']]=o['actual_pixel']['sha256']
assert set(expected)=={p.name for p in h.iterdir()};removed=[]
for p in h.iterdir():
 b=p.read_bytes();assert sha(b)==expected[p.name];removed.append(dict(name=p.name,bytes=len(b),sha256=sha(b)))
head={json.loads(x)['id']:x for x in subprocess.check_output(['git','show','HEAD:data/graph/nodes.jsonl'],cwd=r).splitlines()};cur={json.loads(x)['id']:x for x in(r/'data/graph/nodes.jsonl').read_bytes().splitlines()};history=json.loads(gzip.decompress((r/'data/graph/history/GEN-20261021-051-before.json.gz').read_bytes()));changed={n['id']for n in history['records']};assert changed=={'APP-094-01','ANALYSIS-F-094'}
for n in history['records']:assert n==json.loads(head[n['id']])
assert all(cur[k]==v for k,v in head.items()if k not in changed)
assert json.loads((out/'clean-directory.json').read_text())['exit_code']==0
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r/'math').decode().strip()==l['upstream_math_commit'];assert not subprocess.check_output(['git','status','--porcelain'],cwd=r/'math').strip()
for p in h.iterdir():p.unlink()
h.rmdir();receipt=dict(recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_archive_members=6,source_archive_gzip_sha256=l['source_archive_sha256'],source_archive_decompressed_sha256=l['source_archive_decompressed_sha256'],member_hashes_and_roundtrip_verified=True,prior2nodes_match_HEAD=True,other_prior_nodes_unchanged=len(head)-2,upstream_unchanged_and_clean=True,temporary_files=removed,temporary_bytes_removed=sum(x['bytes']for x in removed),temporary_directory_removed=True,new_application_run=False,software_executed=False,external_paper_fulltext_redistributed=False,old_replays='Not repeated: numerical sources unchanged since WP05213archive andactual314076receipts.');(out/'source-and-cleanup-integrity.json').write_text(json.dumps(receipt,indent=2)+'\n');print({k:receipt[k]for k in ['source_archive_members','other_prior_nodes_unchanged','temporary_bytes_removed','new_application_run']})
