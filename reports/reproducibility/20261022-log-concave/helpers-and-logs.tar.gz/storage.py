"""Verify compressed helper/member bytes before removing this package's temp files."""
import datetime,gzip,hashlib,io,json,tarfile
from pathlib import Path
R=Path('/Users/smzdm/projects/ai_paper');T=Path(__file__).parent;O=R/'reports/reproducibility/20261022-log-concave'
def sha(b):return hashlib.sha256(b).hexdigest()
def packed(name,j):
 raw=(json.dumps(j,ensure_ascii=False,indent=2)+'\n').encode();z=gzip.compress(raw,mtime=0);assert gzip.decompress(z)==raw;(O/name).write_bytes(z)
helpernames=['curate.py','qa.py','save.py','storage.py','acquisitions.json','core-check.log','curation.log','qa.log','clean-core-check.log','export-graph.log','organize-graph.log','execution-notes.json','HELPERS.txt']
(T/'HELPERS.txt').write_text('WP093 one-shot curation/save at recorded882345d base;not a replay chain.\nDo not rerun curate/save on promoted canonical graph. qa.py is a bounded validation helper,no numerical experiment.\ncore-check.log and clean-core-check.log retain actual68-test workflow output. Initial cross-family lookup failure is recorded in execution-notes.json;fixed before canonical writes.\nOnly own helper code/logs/metadata retained. External fulltexts/renders and upstream-derived text are removed after hashed storage receipt.\nPublication cadence:local milestone work,no GitHub push,no officialmath redeployment.\n')
assert all((T/n).is_file() for n in helpernames)
rawfiles={n:(T/n).read_bytes() for n in helpernames};b=io.BytesIO()
with tarfile.open(fileobj=b,mode='w') as a:
 for n,raw in rawfiles.items():
  info=tarfile.TarInfo(n);info.size=len(raw);info.mtime=0;info.mode=0o644;a.addfile(info,io.BytesIO(raw))
rawtar=b.getvalue();z=gzip.compress(rawtar,mtime=0);assert sha(gzip.decompress(z))==sha(rawtar)
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(z))) as a:
 assert set(a.getnames())==set(rawfiles)
 for n,raw in rawfiles.items():assert a.extractfile(n).read()==raw
(O/'helpers-and-logs.tar.gz').write_bytes(z)
prior={}
with tarfile.open(R/'reports/reproducibility/20261022-lieb-thirring/helpers-and-logs.tar.gz','r:gz') as a:
 for local,member in [('prior-curate.py','curate.py'),('prior-qa.py','qa.py')]:
  p=T/local;assert p.read_bytes()==a.extractfile(member).read();prior[local]={'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'verified_archive_member':member}
acq=json.loads((T/'acquisitions.json').read_text())
for a in acq:assert sha((T/(a['id']+'.pdf')).read_bytes())==a['sha256']
third=[]
for p in sorted(T.iterdir()):
 if p.name in helpernames or p.name in prior:continue
 assert p.is_file(),p
 third.append({'name':p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'retained':False})
sourcepdf='math/preprints/Subpolynomial-query-complexity-for-well-conditioned-log-concave-sampling-September-26-2026/article.pdf'
assert sha((R/sourcepdf).read_bytes())=='9e9a41553023f95e18b673f130c2086def56ba2b7a4cd851337a39eb114bf679'
receipt={'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'helper_archive':'helpers-and-logs.tar.gz','helper_gzip_bytes':len(z),'helper_gzip_sha256':sha(z),'tar_uncompressed_sha256':sha(rawtar),'all_members_exact_roundtrip':True,'members':[{'name':n,'bytes':len(raw),'sha256':sha(raw)} for n,raw in rawfiles.items()],'prior_helpers_verified_against_existing_compressed_archive':prior,'temporary_thirdparty_artifacts_removed':third,'temporary_thirdparty_bytes_removed':sum(f['bytes'] for f in third),'own_plaintext_bytes_removed':sum(map(len,rawfiles.values()))+sum(v['bytes'] for v in prior.values()),'upstream_pdf':{'path':sourcepdf,'sha256':sha((R/sourcepdf).read_bytes()),'read_only':True,'copied_or_redeployed':False},'new_dependency_install':False,'new_numerical_experiment':False,'temporary_root_removed':str(T)}
packed('storage.json.gz',receipt)
assert json.loads(gzip.decompress((O/'storage.json.gz').read_bytes()))==receipt
for p in list(T.iterdir()):p.unlink()
T.rmdir();assert not T.exists()
p=R/'state/checkpoint.json';c=json.loads(p.read_text());c['last_quality_evidence'].update(helper_gzip_bytes=len(z),temporary_thirdparty_bytes_removed=receipt['temporary_thirdparty_bytes_removed'],own_plaintext_bytes_removed=receipt['own_plaintext_bytes_removed'],temporary_root_removed=True)
c['saved_at']=receipt['recorded_at'];p.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'helper_gzip_bytes':len(z),'thirdparty_removed':receipt['temporary_thirdparty_bytes_removed'],'own_plaintext_removed':receipt['own_plaintext_bytes_removed'],'tmp_exists':T.exists(),'all_raw_member_hashes_verified':True}))
