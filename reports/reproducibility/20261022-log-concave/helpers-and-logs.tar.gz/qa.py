"""WP093 bounded graph/source/archive/export/no-math audit; no research run."""
import gzip,hashlib,json,os,shutil,subprocess,sys,tempfile,xml.etree.ElementTree as ET
from pathlib import Path
R=Path('/Users/smzdm/projects/ai_paper');T=Path(__file__).parent;sys.path.insert(0,str(R/'src'))
from ai_value.graph import load,impact_report,validate
O=R/'reports/reproducibility/20261022-log-concave';O.mkdir(parents=True,exist_ok=True)
def pack(name,j):
 b=(json.dumps(j,ensure_ascii=False,indent=2)+'\n').encode();z=gzip.compress(b,mtime=0);assert gzip.decompress(z)==b;(O/(name+'.json.gz')).write_bytes(z)
nodes,edges=load(R);checked=[]
cases=[
('CLM-139-LEM-APPELL-CUMULANTS',['CLM-139-THM-MAIN','CLM-139-THM-UPPER'],['CLM-139-THM-LOWER']),
('CLM-139-LEM-COMPILER-ABSORPTION',['CLM-139-PROP-COMPILER-ACCURACY','CLM-139-THM-UPPER'],['CLM-139-THM-LOWER']),
('CLM-139-LEM-DESCENT-MOMENTS',['CLM-139-THM-UPPER','CLM-139-THM-MAIN'],['CLM-139-THM-PRIMITIVE','CLM-139-THM-LOWER']),
('CLM-139-LEM-DEFERRED-HAAR',['CLM-139-THM-LOWER','CLM-139-THM-MAIN'],['CLM-139-THM-UPPER']),
('CLM-139-LEM-LOWER-TARGET-STATISTIC',['CLM-139-THM-LOWER'],['CLM-139-THM-UPPER']),
('CHECK-139-QUERY-COST',['ANALYSIS-F-139','XPL-139-TEN-DOMAINS'],['CLM-139-THM-MAIN','APP-113-01']),
('LIT-139-CHEN2026PICARD',[],['CLM-139-THM-MAIN']),
('P-e54200c0718980f7',['CLM-139-THM-MAIN','CLM-139-THM-UPPER','CLM-139-THM-LOWER'],['CLM-262-SCALAR'])]
for change,yes,no in cases:
 result=impact_report(nodes,edges,{change});assert set(yes)<=set(result['affected']),(change,yes);assert not set(no)&set(result['affected']),(change,no);checked.append({'changed':change,'expected_affected':yes,'expected_unaffected':no,'actual':result})
pack('impact',{'cases':checked,'meaning':'Routing only,not theorem refutation;upper/lower branch distinction and metadata historical_context preserved.'})
archives=[]
for p in sorted((R/'experiments/runs').glob('*/manifest.json')):
 j=json.loads(p.read_text());folder=p.parent
 for name,want in j['outputs'].items():assert hashlib.sha256((folder/name).read_bytes()).hexdigest()==want
 for name,meta in j.get('compressed_payloads',{}).items():assert hashlib.sha256(gzip.decompress((folder/name).read_bytes())).hexdigest()==meta['uncompressed_sha256']
 snap=json.loads(gzip.decompress((folder/j['source_snapshot']).read_bytes()))
 for name,text in snap.items():assert hashlib.sha256(text.encode()).hexdigest()==j['inputs'][name]
 archives.append({'run_id':j['run_id'],'compressed_and_raw_hashes':True,'source_members':len(snap),'actual_replayed':False})
pack('archives',{'archives':archives,'count':len(archives),'new_replays':[],'reason':'Only F139 source/graph/document records changed;no experimental code/spec/data/comparator changes,so no repetitive numerical run. Prior actual replays retained.'})
canon=[json.loads(l) for l in (R/'data/graph/nodes.jsonl').read_text().splitlines()];local=external=0
for n in canon:
 for s in n['sources']:
  if 'path' in s:assert hashlib.sha256((R/s['path']).read_bytes()).hexdigest()==s['sha256'];local+=1
  else:external+=1
old=[json.loads(l) for l in subprocess.check_output(['git','show','882345d:data/graph/nodes.jsonl'],cwd=R,text=True).splitlines()]
oldedges=[json.loads(l) for l in subprocess.check_output(['git','show','882345d:data/graph/edges.jsonl'],cwd=R,text=True).splitlines()]
nowedges=[json.loads(l) for l in (R/'data/graph/edges.jsonl').read_text().splitlines()]
assert canon[:len(old)]==old and nowedges[:len(oldedges)]==oldedges
pack('canonical-and-sources',{'canonical_nodes':len(canon),'new_canonical_nodes':len(canon)-len(old),'old_nodes_exact':len(old),'old_edges_exact':True,'new_edges':len(nowedges)-len(oldedges),'local_source_hashes':local,'external_annotations_without_retained_bytes':external,'all_canonical_annotations':local+external,'validation':validate(R)})
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(R/'src'))
for command in ['export-graph','organize-graph']:
 p=subprocess.run([sys.executable,'-m','ai_value.cli',command],cwd=R,env=env,text=True,capture_output=True);(T/(command+'.log')).write_text(p.stdout+p.stderr);assert p.returncode==0,p.stderr
payload=json.loads(gzip.decompress((R/'reports/graph/knowledge.json.gz').read_bytes()))
assert {n['id']:n for n in payload['nodes']}==nodes and payload['edges']==edges
g=ET.fromstring(gzip.decompress((R/'reports/graph/knowledge.graphml.gz').read_bytes()));ns={'g':'http://graphml.graphdrawing.org/xmlns'}
assert {e.attrib['id'] for e in g.findall('.//g:node',ns)}==set(nodes)
assert {(e.attrib['id'],e.attrib['source'],e.attrib['target']) for e in g.findall('.//g:edge',ns)}=={(e['id'],e['source'],e['target']) for e in edges}
assert '__GRAPH_DATA__' not in (R/'reports/graph/index.html').read_text()
pack('exports',{'nodes':len(nodes),'edges':len(edges),'json_exact':True,'graphml_ids_endpoints_exact':True,'html_payload_resolved':True,'mathematical_validation':False})
paths=subprocess.check_output(['git','ls-files','-c','-o','--exclude-standard','-z'],cwd=R).split(b'\0');paths=sorted(set(x.decode() for x in paths if x));paths=[x for x in paths if x.split('/')[0] not in {'math','.git','.venv','.cache'} and '__pycache__' not in x.split('/')]
with tempfile.TemporaryDirectory(prefix='ai-paper-no-math-') as tmp:
 c=Path(tmp);total=count=0
 for name in paths:
  p=R/name
  if not p.is_file():continue
  assert not p.is_symlink(),name;q=c/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q);total+=p.stat().st_size;count+=1
 assert not (c/'math').exists();e=dict(env,PYTHONPATH=str(c/'src'));p=subprocess.run([sys.executable,'scripts/check.py'],cwd=c,env=e,text=True,capture_output=True,timeout=240)
 (T/'clean-core-check.log').write_text(p.stdout+p.stderr)
 pack('no-math-clean-directory',{'files':count,'bytes_copied':total,'math_present':False,'exit_code':p.returncode,'new_install':False,'cleaned_on_exit':True,'scope':'Existing68core/validate/report/provenance;not scientific replay or Lean build'});assert p.returncode==0,p.stderr[-1500:]
print(json.dumps({'canonical_nodes':len(canon),'impact_cases':len(cases),'archives':len(archives),'new_replays':0,'no_math_clean_exit':0,'all_canonical_annotations':local+external,'graph_nodes':len(nodes),'graph_edges':len(edges)},indent=2))
