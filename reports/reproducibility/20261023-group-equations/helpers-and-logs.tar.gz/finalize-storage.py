from pathlib import Path
import json,hashlib,gzip,tarfile,io,shutil,datetime,subprocess
R=Path('/Users/smzdm/projects/ai_paper');T=Path('/private/tmp/ai-paper-WP097');OUT=R/'reports/reproducibility/20261023-group-equations'
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(x):return (json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def gz(p,x):
 b=enc(x);z=gzip.compress(b,mtime=0);assert gzip.decompress(z)==b;p.write_bytes(z)
assert not (T/'no-math-clean').exists(),'Successful clean directory should already be removed'
assert json.loads(gzip.decompress((OUT/'no-math-clean-directory.json.gz').read_bytes()))['exit_code']==0
# PDFs, extracted original texts and page images are reproducible third-party material.
# Retain only byte inventory and scoped own observations;never republish whole originals.
raws=[]
for p in sorted(T.iterdir()):
 if p.suffix in {'.pdf','.txt','.png'}:
  b=p.read_bytes();raws.append({'name':p.name,'bytes':len(b),'sha256':sha(b),'action':'hash_verified_then_removed','third_party_payload_retained':False})
ours=[p for p in sorted(T.iterdir()) if p.is_file() and p.suffix not in {'.pdf','.txt','.png'}]
buf=io.BytesIO();memberhash=[]
with tarfile.open(fileobj=buf,mode='w') as archive:
 for p in ours:
  b=p.read_bytes();h=sha(b);m=tarfile.TarInfo(p.name);m.size=len(b);m.mtime=0;archive.addfile(m,io.BytesIO(b));memberhash.append({'name':p.name,'bytes':len(b),'sha256':h})
rawtar=buf.getvalue();packed=gzip.compress(rawtar,mtime=0);assert gzip.decompress(packed)==rawtar
with tarfile.open(fileobj=io.BytesIO(packed),mode='r:gz') as archive:
 assert set(archive.getnames())=={m['name'] for m in memberhash}
 for m in memberhash:assert sha(archive.extractfile(m['name']).read())==m['sha256']
out=OUT/'helpers-and-logs.tar.gz';out.write_bytes(packed)
assert sha(out.read_bytes())==sha(packed)
for row in raws:assert sha((T/row['name']).read_bytes())==row['sha256']
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'work_package':'WP-097','temporary_root':str(T),'helper_archive':str(out.relative_to(R)),'archive_sha256':sha(packed),'tar_decompressed_sha256':sha(rawtar),'gzip_roundtrip_verified':True,'tar_bytes':len(rawtar),'helper_original_bytes':sum(m['bytes'] for m in memberhash),'compressed_bytes':len(packed),'member_hashes_verified':memberhash,'external_and_render_inventory':raws,'temporary_original_text_pixel_bytes_removed':sum(r['bytes'] for r in raws),'new_original_pdf_download_bytes':4894426,'numerical_outputs_created':False,'upstream_copied':False,'upstream_mutated':False,'cleanup':'All recorded members roundtrip/memberSHA verified before deleting temporary root;no failed evidence discarded','clean_directory':'Successful temporary no-math copy already removed by clean checker;1705files61993772bytes were validation copies,not unique research data','scope':'Original source code paths/hashes remain upstream;do not archive wholemath or externalPDF/fulltext/png','cleanup_completed':False}
gz(OUT/'storage.json.gz',receipt)
shutil.rmtree(T);assert not T.exists()
receipt['cleanup_completed']=True;gz(OUT/'storage.json.gz',receipt)
print(json.dumps({k:v for k,v in receipt.items() if k not in ['member_hashes_verified','external_and_render_inventory']},ensure_ascii=False))
