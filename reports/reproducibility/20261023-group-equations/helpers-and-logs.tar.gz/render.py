import pathlib,subprocess,json,hashlib
R=pathlib.Path('/Users/smzdm/projects/ai_paper');T=pathlib.Path('/private/tmp/ai-paper-WP097')
N=R/'math/preprints/Nonsingular-systems-of-equations-over-arbitrary-groups-October-5-2026/nonsingular-systems-over-arbitrary-groups.pdf'
K=R/'math/preprints/The-Kervaire-Theorem-for-Groups-September-24-2026/The-Kervaire-Theorem-for-Groups-September-24-2026.pdf'
jobs=[('N-main',N,1),('N-boundary',N,11),('K-main',K,1),('K-boundary',K,8),('NT-theorems',T/'NT2021v2.pdf',2),('ALV-th44',T/'ALV2011v1.pdf',11),('Kervaire-th11',T/'Kervaire1965.pdf',5)]
rows=[]
with (T/'render.log').open('w') as log:
 for tag,p,page in jobs:
  prefix=T/tag
  subprocess.run(['/opt/homebrew/bin/pdftoppm','-f',str(page),'-l',str(page),'-singlefile','-scale-to','1600','-png',str(p),str(prefix)],check=True,stdout=log,stderr=log)
  q=prefix.with_suffix('.png');rows.append({'source':str(p),'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'page_one_based':page,'image':str(q),'image_bytes':q.stat().st_size,'image_sha256':hashlib.sha256(q.read_bytes()).hexdigest(),'pixels_actually_viewed':False})
(T/'render-inventory.json').write_text(json.dumps(rows,indent=2)+'\n');print('rendered',len(rows),'pages')
