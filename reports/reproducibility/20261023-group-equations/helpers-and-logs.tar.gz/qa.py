import gzip,hashlib,json,pathlib,subprocess,sys,xml.etree.ElementTree as ET
R=pathlib.Path('/Users/smzdm/projects/ai_paper');T=pathlib.Path('/private/tmp/ai-paper-WP097');OUT=R/'reports/reproducibility/20261023-group-equations'
sys.path.insert(0,str(R/'src'))
from ai_value.graph import load,affected_nodes,theoretical_grade
from ai_value.knowledge import export
from ai_value.source_results import named_results
def sha(b):return hashlib.sha256(b).hexdigest()
def write(name,j):
 b=(json.dumps(j,ensure_ascii=False,indent=2)+'\n').encode();z=gzip.compress(b,mtime=0);assert gzip.decompress(z)==b;(OUT/name).write_bytes(z)
nodes,edges=load(R);app='APP-256-01';nm='CLM-256-N-THM-MAIN';km='CLM-256-K-THM-MAIN'
cases=[]
def check(name,seed,yes,no):
 hit=affected_nodes(nodes,edges,set(seed));assert set(yes)<=hit,(name,'missing',set(yes)-hit);assert not(set(no)&hit),(name,'false',set(no)&hit)
 cases.append({'name':name,'changed':seed,'expected_review':yes,'expected_unaffected':no,'affected':sorted(hit),'pass':True})
check('general_full_rank_main_is_real_candidate_input',[nm],[app,'PART-256-EXPONENT-RANK-INJECTION'],[km])
check('multi_fixedspace_change_reaches_general_candidate',['CLM-256-N-THM-FIXED-SPACE'],[nm,app],[km])
check('single_unimodular_formal_endpoint_does_not_cover_multi',[km],['CLM-256-K-COR-KERVAIRE'],[app,nm])
check('single_degree_route_does_not_impair_multi_intersection',['CLM-256-K-LEM-FIXED'],[km],[app,nm])
check('multi_phase_not_false_companion_dependency',['CLM-256-N-LEM-PHASE-SUBADDITIVITY'],[nm,app],[km])
check('unread_borel_input_keeps_multi_proof_chain_unknown',['LIT-256-BOREL1953'],[nm,app],[km])
check('shared_regular_trace_is_required_both_proofs',['PART-256-FAITHFUL-REGULAR-TRACE'],[nm,km,app],[])
check('GR_old_comparison_is_not_newproof_premise',['LIT-256-GERSTENHABERROTHAUS1962'],[],[nm,km,app])
check('embeddable_factor_antecedent_not_direct_arbitrary_group_premise',['LIT-256-ANTEZANALAROTONDAVARELA2012'],[],[nm,km,app])
check('ten_domain_exploration_not_all_candidate_dependencies',['XPL-256-TEN-DOMAINS'],[],[nm,km,app])
check('F058_local_not_whole_classification',['CLM-058-U-THM-MAIN'],[],['APP-058-01',app])
check('F058_real_QE_qualification_remains_dependency',['LIT-058-QEPCAD-INTERFACE'],['APP-058-01'],[app])
for id in [app,nm,km]:assert theoretical_grade(nodes,edges,id)=='unknown'
write('impact.json.gz',{'cases':cases,'count':len(cases),'candidate_grade':'unknown','meaning':'Review routing only;not theorem refutation,proof certification or human review'})
ex=export(R)
jn=json.loads(gzip.decompress((R/'reports/graph/knowledge.json.gz').read_bytes()))
assert {n['id']:n for n in jn['nodes']}==nodes;assert jn['edges']==edges
tree=ET.fromstring(gzip.decompress((R/'reports/graph/knowledge.graphml.gz').read_bytes()));ns={'g':'http://graphml.graphdrawing.org/xmlns'}
gn={n.attrib['id']:json.loads(next(d.text for d in n if d.attrib.get('key')=='properties')) for n in tree.findall('.//g:node',ns)}
ge={e.attrib['id']:json.loads(next(d.text for d in e if d.attrib.get('key')=='evidence')) for e in tree.findall('.//g:edge',ns)}
assert gn==nodes;assert ge=={e['id']:e for e in edges}
write('exports.json.gz',{'export':ex,'json_full_node_edge_exact':True,'graphml_full_node_edge_exact':True,'nodes':len(nodes),'edges':len(edges)})
archives=[];source_members=0
for p in sorted((R/'experiments/runs').glob('*/manifest.json')):
 m=json.loads(p.read_text());folder=p.parent;checked=[]
 for name,expected in m['outputs'].items():
  raw=(folder/name).read_bytes();assert sha(raw)==expected,(p,name)
  if name.endswith('.gz'):gzip.decompress(raw)
  checked.append(name)
 for name,desc in m.get('compressed_payloads',{}).items():
  raw=gzip.decompress((folder/name).read_bytes());assert sha(raw)==desc['uncompressed_sha256'],(p,name)
 j=json.loads(gzip.decompress((folder/m['source_snapshot']).read_bytes()));assert set(m['inputs'])==set(j)
 for name,text in j.items():assert isinstance(text,str) and sha(text.encode())==m['inputs'][name],(p,name)
 source_members+=len(j)
 archives.append({'run_id':m['run_id'],'outputs_checked':checked,'compressed_payload_roundtrip':True,'source_members':len(j),'scientific_replay':False})
write('archives.json.gz',{'count':len(archives),'source_members':source_members,'archives':archives,'reason_no_replay':'No experimental source/specification/data/comparator change in WP097;new conditional plan is not a run. Archive integrity is not application validation.'})
oldraw=subprocess.check_output(['git','show','a7b6abf:data/graph/nodes.jsonl'],cwd=R)
oldedges=subprocess.check_output(['git','show','a7b6abf:data/graph/edges.jsonl'],cwd=R)
assert (R/'data/graph/nodes.jsonl').read_bytes().startswith(oldraw)
assert (R/'data/graph/edges.jsonl').read_bytes().startswith(oldedges)
before={json.loads(l)['id']:json.loads(l) for l in oldraw.splitlines()}
after={json.loads(l)['id']:json.loads(l) for l in (R/'data/graph/nodes.jsonl').read_bytes().splitlines()}
assert all(after[k]==n for k,n in before.items())
diff=subprocess.check_output(['git','diff','--name-only','a7b6abf','--','src','tests','experiments/runs','experiments/specs'],cwd=R,text=True).strip();assert not diff,diff
oldcov=json.loads(subprocess.check_output(['git','show','a7b6abf:data/graph/reading_coverage.json'],cwd=R));cov=json.loads((R/'data/graph/reading_coverage.json').read_text())
assert all(cov['partially_read_families'][k]==v for k,v in oldcov['partially_read_families'].items())
assert cov['source_decomposition_drafts']==oldcov['source_decomposition_drafts']+['F-256'];assert cov['full_family_decompositions_complete']==[]
write('canonical-preservation.json.gz',{'base':'a7b6abf','old_records_exact':len(before),'new_canonical_records':len(after)-len(before),'all_old_node_bytes_exact_prefix':True,'all_old_edge_bytes_exact_prefix':True,'old_coverage_entries_exact':True,'experimental_code_tests_specs_runs_unchanged':True,'human_reviews':0,'cross_provider_reviews':0,'new_application_experiments':0})
ledger=json.loads((R/'data/provenance/readings/F-256.json').read_text())
for path,row in ledger['read_files'].items():assert sha((R/path).read_bytes())==row['sha256']
for row in ledger['formal_actual_files']:assert sha((R/row['path']).read_bytes())==row['sha256']
a=nodes['ANALYSIS-F-256']['properties']
for path,mapping in a['result_ids_by_source'].items():assert set(mapping)=={x['label'] for x in named_results((R/path).read_text())}
assert len(a['source_sections'])==14 and len(a['result_ids_by_label'])==10 and len(a['method_ids'])==20
assert sum(x['total_lines'] for p,x in ledger['read_files'].items() if p.endswith('.tex'))==2157
assert len(ledger['bibliography_bindings'])==31 and len({x['target_id'] for x in ledger['bibliography_bindings']})==24
assert len(ledger['historical_works'])==4
for px in ledger['pdf_pixels']:
 assert sha(pathlib.Path(px['image']).read_bytes())==px['image_sha256']
 assert sha(pathlib.Path(px['source']).read_bytes())==px['source_sha256']
r=json.loads(gzip.decompress((R/ledger['role_receipt']['path']).read_bytes()))
for m in r['members']:assert sha(m['utf8_exact'].encode())==m['sha256']
write('source-and-role-contracts.json.gz',{'all_17_natural_read_files_hashed':len(ledger['read_files'])==17,'formal_files_hashed':10,'all14source_result_bindings_exact':True,'named_results':10,'method_contracts':20,'bibliography_occurrences':31,'unique_external_works':23,'internal_companion':1,'historical_scopes':4,'actual_pixels_hashed':8,'role_exact_member_hashes':True,'role_count':2,'independent_suppliers':0,'human_reviews':0})
print(json.dumps({'nodes':len(nodes),'edges':len(edges),'canonical_records':len(after),'impact_cases':len(cases),'archives':len(archives),'source_members':source_members,'preservation':True},indent=2))
