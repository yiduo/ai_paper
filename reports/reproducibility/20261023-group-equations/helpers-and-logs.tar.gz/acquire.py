import pathlib,urllib.request,hashlib,json,datetime
T=pathlib.Path('/private/tmp/ai-paper-WP097');cap=8*1024*1024;total=0;rows=[]
sources=[('GR1962.pdf','https://www.pnas.org/doi/pdf/10.1073/pnas.48.9.1531'),('NT2021v2.pdf','https://arxiv.org/pdf/1811.07737v2'),('ALV2011v1.pdf','https://arxiv.org/pdf/1107.0348v1'),('Kervaire1965.pdf','https://www.numdam.org/item/10.24033/bsmf.1624.pdf')]
for name,url in sources:
 row={'name':name,'url':url,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'ai-paper-source-qualification/1.0'}),timeout=25) as r:
   length=int(r.headers.get('Content-Length','0'))
   if length>cap-total:raise ValueError('Content-Length exceeds remaining source budget')
   b=r.read(cap-total);total+=len(b)
   row.update(final_url=r.url,status=r.status,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),content_type=r.headers.get('Content-Type'))
   if not b.startswith(b'%PDF-'):raise ValueError('Not PDF content;no body reading claimed')
   (T/name).write_bytes(b);row['pdf_signature_valid']=True
 except Exception as e:row.update(error=type(e).__name__+': '+str(e))
 rows.append(row);(T/'acquisition.json').write_text(json.dumps({'download_limit_bytes':cap,'download_total_bytes':total,'sources':rows},indent=2)+'\n')
print(json.dumps({'total_bytes':total,'sources':rows},indent=2))
