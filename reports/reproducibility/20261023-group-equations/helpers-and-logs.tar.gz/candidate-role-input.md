# Proposed conditional application, before any experiment

Source: F256 at read-only math commit 1581d4cbdd69a0faf34b2089614fe2a814316a6a.
All current natural source bodies have been read by the parent; no mathematical or human acceptance follows.

Primary local sources to inspect:
- /Users/smzdm/projects/ai_paper/math/preprints/Nonsingular-systems-of-equations-over-arbitrary-groups-October-5-2026/build/sections/introduction.tex
- /Users/smzdm/projects/ai_paper/math/preprints/Nonsingular-systems-of-equations-over-arbitrary-groups-October-5-2026/build/sections/history.tex
- /Users/smzdm/projects/ai_paper/math/preprints/Nonsingular-systems-of-equations-over-arbitrary-groups-October-5-2026/build/sections/kernel.tex
- /Users/smzdm/projects/ai_paper/math/preprints/Nonsingular-systems-of-equations-over-arbitrary-groups-October-5-2026/build/sections/fixed-space.tex
- /Users/smzdm/projects/ai_paper/math/lean/docs/256.md
- /Users/smzdm/projects/ai_paper/math/lean/ComparatorChallenges/Kervaire.json

Conditional candidate: a non-collapse guard for incremental symbolic group presentations/specifications. A caller supplies a coefficient group G via a declared group presentation/interface, n fresh group generators, and m finite relator words over G*F_n. The parser must distinguish coefficient letters from fresh variables and compute the full integer exponent matrix A. A verifiable full-row-rank witness over Q licenses, conditional on the source theorem C and complete dependencies, the assertion that the canonical map G -> (G*F_n)/normalClosure(relators) is injective. It does not construct elements of G, decide its word problem, prove original G nontrivial, prove the quotient is isomorphic to G, or preserve finite/amenable/solvable/linear structure. Rank failure means unsupported, not collapse. Alpha-renaming and group notation changes must not change the contract.

The desired operational use is to flag coefficient identification risk before downstream presentation manipulation; no actual consumer or representative batch has been admitted. No implemented guard, certificate format, theorem-prover integration or numerical/symbolic run exists. General multi-relator main is natural-language C, not covered by the selected unimodular one-relator Lean endpoint. Whole dependency grade unknown; no pilot or human/provider approval.

Possible falsifiable check, only after a separately frozen actual workload and independent judge: every pre-admitted request with a valid full-rank witness receives a correctly parsed source-conditional conservative-extension assertion, agrees with independently known embedding/non-collapse evidence, and does not claim unsupported semantics. Any false coefficient embedding assertion, invalid witness accepted, mismatched group/variables, or in-pack resource failure defeats functional coverage. Gain versus existing Tietze/adjoin-defined-generator transformations, old Gerstenhaber-Rothaus/Nitsche-Thom criteria and genuine supplied embedding certificates remains open. These old methods may already suffice. Do not count testing rank arithmetic or manufactured theorem examples as application validation.

Alternative exploration only: source simultaneous fixed-space theorem supplies shared X_i in U(k_i) for full signed multiplicity row rank and arbitrary fixed P_j, with sum of fixed dimensions >= sum k_i. Nested minors select which output channels carry l_j. No finite algorithm, continuous selector, per-channel demand chosen independently of that allocation, hardware-realizable control restriction or efficiency follows. A lossless-network/quantum-control analogy requires an actual matching control interface; it is not a second candidate or benchmark yet.

Review the proposal in your assigned role. Do not read another role's output. Do not add external works/downloads or launch experiments. Identify exact source locators, old-method null, failure modes, required caller/judge, and whether the concrete mapping should be retained/refined. You are a fresh same-OpenAI auxiliary role, not human review or a second model provider. Do not approve scientific validity.
