from pathlib import Path
import json,re
R=Path('/Users/smzdm/projects/ai_paper')
p=R/'PROGRESS.en.md';s=p.read_text()
s=s.replace('Snapshot: October 23, 2026, local closeout of WP-095 and retrospective 034 after an interrupted session.','Snapshot: October 23, 2026, WP-097 source curation and local quality checks; retrospective 034 remains the latest global review.')
for a,b in [('51/372 families, about 13.7%','52/372 families, about 14.0%'),('46/372, about 12.4%','47/372, about 12.6%'),('1,272 labelled results','1,282 labelled results'),('42/500','43/500'),('6,614 nodes; 17,848 relations; 6,835 canonical citation annotations (6,825 in core-validated research types)','6,740 nodes; 18,274 relations; 7,021 canonical citation annotations (7,011 in core-validated research types)'),('WP-093–WP-096 research/graph/quality work','WP-093–WP-097 research/graph/quality work')]:s=s.replace(a,b)
insert='''WP-097 completed both current F256 group-equation source bodies: 14 TeX files / 2,157 lines, a separate 109-line bibliography and two READMEs. Ten qualified results and 20 method contracts distinguish coefficient injectivity in an overgroup from solving in the original group, and fixed-space existence from an algorithm. Four historical works were checked in selected scopes and eight PDF pages visually inspected. The actual selected Lean endpoint covers a single unimodular relation; it does not cover the general multirelator main. Five mapped natural bindings have local source B, five remain C, and every complete dependency grade is unknown. One source-conditional coefficient-injectivity guard is retained without an actual caller, implementation, independent embedding judge or run. The 59 new canonical records and 207 explicit relations preserve all 4,062 prior records and old edges. Existing 68 core checks, 12 impact cases, full exports and 15 archives / 267 source members passed; the clean-directory receipt separately records its outcome. See [F256 evidence and limits](reports/group-equations-F256-reading.md). No GitHub push was made. Routine work remains local until a meaningful publication batch.

'''
s=s.replace('## Latest source-reading package\n\n','## Latest source-reading package\n\n'+insert)
p.write_text(s)
p=R/'README.en.md';s=p.read_text().replace('41 candidate connections','43 candidate connections');p.write_text(s)
p=R/'README.md';s=p.read_text()
for a,b in [('已保存41条候选连接','已保存43条候选连接'),('50族有实际阅读','52族有实际阅读'),('其中45族为全文拆解草稿','其中47族为全文拆解草稿'),('共1199个带原文标签','共1282个带原文标签'),('知识图谱已有6175节点、16201关系、6134条规范来源注释（其中6124条属于核心研究类型校验）','知识图谱已有6740节点、18274关系、7021条规范来源注释（其中7011条属于核心研究类型校验）')]:s=s.replace(a,b)
anchor='公开需求与待定候选的适用条件对照见'
s=s.replace(anchor,'最新 [F256源文与条件守卫](reports/group-equations-F256-reading.md)连接两稿10项结果、20个方法契约及一条待定近类比；原群内求解、一般多关系结论和单关系Lean范围分别记录，无新初检。日常工作仅本地保存／提交，GitHub按实质里程碑合并更新，官方math不部署。\n\n'+anchor)
p.write_text(s)
p=R/'docs/roadmap.md';s=p.read_text().replace('51族实际阅读','52族实际阅读').replace('46族当前全文草稿、1272个','47族当前全文草稿、1282个').replace('四十二候选','四十三候选');p.write_text(s)
p=R/'docs/publication.md';s=p.read_text().replace('Subsequent local packages and retrospective 034 await a future batch.','Subsequent local packages through WP-097 and retrospective 034 await a future batch.');p.write_text(s)
print('Local bilingual progress and top-level counts refreshed;publication unchanged')
