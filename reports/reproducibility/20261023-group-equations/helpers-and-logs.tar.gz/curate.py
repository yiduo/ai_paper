"""WP097 manually curated research records. No proof or application experiment."""
from pathlib import Path
import json,gzip,hashlib,re,datetime,subprocess,sys
R=Path('/Users/smzdm/projects/ai_paper');T=Path('/private/tmp/ai-paper-WP097')
sys.path.insert(0,str(R/'src'))
from ai_value.graph import load,validate
UP='1581d4cbdd69a0faf34b2089614fe2a814316a6a'; GEN='GEN-20261023-094'
NOW=datetime.datetime.now(datetime.timezone.utc).isoformat()
OUT=R/'reports/reproducibility/20261023-group-equations';OUT.mkdir(parents=True,exist_ok=True)
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(x):return (json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def write(p,x):
 p=R/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(enc(x))
def gz(p,x):
 b=enc(x);z=gzip.compress(b,mtime=0);assert gzip.decompress(z)==b;(R/p).parent.mkdir(parents=True,exist_ok=True);(R/p).write_bytes(z)
 return {'path':p,'sha256':sha(z),'decompressed_sha256':sha(b),'raw_bytes':len(b),'compressed_bytes':len(z)}
def source(p,loc,commit=None):return {'path':p,'sha256':sha((R/p).read_bytes()),'locator':loc,'commit':commit}
D=json.loads(gzip.decompress((T/'source-contract-draft.json.gz').read_bytes()))
J=json.loads((R/'state/reading-progress/F-256.json').read_text())
N='math/preprints/Nonsingular-systems-of-equations-over-arbitrary-groups-October-5-2026/build/'
K='math/preprints/The-Kervaire-Theorem-for-Groups-September-24-2026/build/'
BASE=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
oldraw=(R/'data/graph/nodes.jsonl').read_bytes();oldedges=(R/'data/graph/edges.jsonl').read_bytes()
old=[json.loads(l) for l in oldraw.splitlines()];oldids={x['id'] for x in old};assert len(old)==4062 and GEN not in oldids
roles={r:json.loads((T/(r+'-output.json')).read_text()) for r in ['defender','skeptic']}
dispatch={
 'skeptic':"You are the skeptical auxiliary reviewer explicitly requested by the project's goal workflow. Read /private/tmp/ai-paper-WP097/candidate-role-input.md and the listed primary local source scopes. Challenge the proposed conditional group-presentation non-collapse guard and its old-method/independent-judge boundary. No external downloads, experiments, other reviewer outputs, canonical edits, or messaging other chats. Do not claim independent-provider/human review; current user-selected OpenAI backend exact ID unknown. Save your substantive review as JSON at /private/tmp/ai-paper-WP097/skeptic-output.json including observed UTC time, role, actual sources read, strongest objections, required repairs, and a concise keep/refine decision. Return the same substantive review in your final response.",
 'defender':"You are the defending auxiliary reviewer explicitly requested by the project's goal workflow. Read /private/tmp/ai-paper-WP097/candidate-role-input.md and the listed primary local source scopes. Give the strongest scoped case for retaining/refining the proposed conditional group-presentation non-collapse guard while respecting exact premises, old-method null and independent-judge requirements. No external downloads, experiments, other reviewer outputs, canonical edits, or messaging other chats. Do not claim independent-provider/human review; current user-selected OpenAI backend exact ID unknown. Save your substantive review as JSON at /private/tmp/ai-paper-WP097/defender-output.json including observed UTC time, role, actual sources read, strongest defense, required qualifications, and a concise keep/refine decision. Return the same substantive review in your final response."
}
members=[]
for name in ['candidate-role-input.md','defender-output.json','skeptic-output.json']:
 b=(T/name).read_bytes();members.append({'name':name,'bytes':len(b),'sha256':sha(b),'utf8_exact':b.decode()})
rolepath='data/provenance/reviews/F-256-same-provider-roles.json.gz'
role_receipt=gz(rolepath,{'recorded_at':NOW,'provider':'OpenAI','exact_backend_model_id':'unknown','dispatch_observed_window_utc':['2026-10-23 03:06:55 UTC','2026-10-23 03:07:33 UTC'],'window_meaning':'Parent clock immediately before dispatching both tasks and after both dispatch calls;not exact backend start timestamps','dispatch_messages':dispatch,'tasks':{'defender':'/root/f256_defender','skeptic':'/root/f256_skeptic'},'members':members,'isolation':'Each role instructed to read initial proposal and six source scopes without the other output;both substantive outputs received before final refinement. No claim of rerun on final card.','independent_provider_review':False,'human_review':False,'application_validation':False})
for m in json.loads(gzip.decompress((R/rolepath).read_bytes()))['members']:assert sha(m['utf8_exact'].encode())==m['sha256']

# Two bibliographies have shared keys; one internal companion is not a new external work.
rawN=(R/(N+'references.tex')).read_text();rawK=(R/(K+'references.bib')).read_text()
bn={}
for m in re.finditer(r'\\bibitem\{([^}]+)\}',rawN):
 start=m.start();end=rawN.find('\\bibitem',m.end());end=len(rawN) if end<0 else end
 bn[m.group(1)]={'path':N+'references.tex','line':rawN[:start].count('\n')+1,'entry':rawN[start:end]}
bk={}
starts=list(re.finditer(r'@\w+\{([^,]+),',rawK))
for i,m in enumerate(starts):bk[m.group(1)]={'path':K+'references.bib','line':rawK[:m.start()].count('\n')+1,'entry':rawK[m.start():starts[i+1].start() if i+1<len(starts) else len(rawK)]}
keys=sorted(set(bn)|set(bk));assert len(bn)==16 and len(bk)==15 and len(keys)==24
titles={
 'AntezanaLarotondaVarela2012':'Thompson-type formulae','Borel1953':'Sur la cohomologie des espaces fibres principaux et des espaces homogenes de groupes de Lie compacts',
 'Chen2026':'The Kervaire conjecture and the minimal complexity of surfaces','GerstenhaberRothaus1962':'The solution of sets of equations in groups','Hatcher2002':'Algebraic Topology',
 'Howie1981':'On pairs of 2-complexes and systems of equations over groups','Howie1983':'The solution of length three equations over groups','Jones2009':'Von Neumann Algebras',
 'Klyachko1993':'A funny property of sphere and equations over groups','KlyachkoMikheenkoRomankov2024':'Equations over solvable groups','McCleary2001':"A User's Guide to Spectral Sequences, second edition",
 'Nicolaescu2010':'Schubert calculus on the Grassmannian of hermitian lagrangian spaces','NitscheThom2022':'Universal solvability of group equations','Pestov2008':'Hyperlinear and sofic groups: a brief guide',
 'RamirezCoteWise2025':'The Kervaire conjecture via Banach fixed points in power series groups','Thompson1986':'Proof of a conjectured exponential formula','Kervaire1965':'Les noeuds de dimensions superieures',
 'KlyachkoLurye2012':'Relative hyperbolicity and similar properties of one-generator one-relator relative presentations with powered unimodular relator','KlyachkoThom2017':'New topological methods to solve equations over groups',
 'Milnor1965':'Topology from the Differentiable Viewpoint','Klyachko2004':'The Kervaire-Laudenbach conjecture and presentations of simple groups','Kawauchi2024':'Kervaire conjecture on weight of group via fundamental group of ribbon sphere-link',
 'KlyachkoMikheenkoOlshanskii2026':'Solvability of unimodular equations in groups and Lie algebras'}
lit={k:('P-63f4b2af9a574825' if k=='OpenAIKervaire2026' else 'LIT-200-00F68475E7' if k=='Hatcher2002' else 'LIT-256-'+k.upper()) for k in keys}
acq=json.loads((T/'acquisition.json').read_text());pixels=json.loads((T/'render-inventory.json').read_text());assert len(pixels)==8 and all(x['pixels_actually_viewed'] for x in pixels)
hist={
 'GerstenhaberRothaus1962':{'url':'https://www.pnas.org/doi/pdf/10.1073/pnas.48.9.1531','version':'1962 original article pp1531-1533','read_scope':'Complete article cached primary PDF text from title through references pp1531-1533,excluding adjacent articles;no successful pixels or locally retained original bytes','verified_statement':'Theorem1 compact connected Lie group,square exponent determinant nonzero gives solution inside it. Theorem2 finite coefficient group gives a finite overgroup solution. Theorem3 finitely generated coefficient group faithfully embedded in a compact connected Lie group remains injective under nonsingular extension.','boundary':'No algorithm supplied;1962 no-satisfactory-algorithm remark is historical. Degree exponent OCR not adjudicated without pixels. Direct403/PMCchallenge/cookieAbsent screenshot are failed acquisition,not local hash evidence.','body_checked':True},
 'NitscheThom2022':{'url':'https://arxiv.org/pdf/1811.07737v2','version':'arXiv1811.07737v2,2021-09-23;not asserted byte-identical to journal2022','read_scope':'PDF1-3 locally,Introduction Th1.2/Th1.3,Lemma2.1 proof andRemark2.2;additional selected primary cached fragments PDF4-6 cocycleLemma2.3,Th1.3 proof andRemark2.5;not complete9pages;PDF2 pixels','verified_statement':'Connes-embeddable coefficientG and H2=0 of presentation2-complex gives overgroup solution,finiteG finite overgroup. Th1.3 uses an H2-zero cover and still Connes-embeddableG. Lemma2.1 extends arbitrary possibly infinite systems by compactness in U(m).','boundary':'Presentation-complexH2 is not groupH2. GeneralTh1.3 semidirect/wreath construction does not assure Connes-embeddable resultingH. Historical absence of known counterexamples is not current evidence.','body_checked':True,'local_name':'NT2021v2.pdf'},
 'AntezanaLarotondaVarela2012':{'url':'https://arxiv.org/pdf/1107.0348v1','version':'arXiv1107.0348v1,2011-07-02;not asserted identical to journal2012','read_scope':'PDF2-3 and10-12,Section2finite formula/II1 conventions andSection4 selected argument throughTh4.4;PDF11 pixels;not fullpaper','verified_statement':'Finite matrix Thompson formula is already an older route. Section4 works throughout with embeddable II1 factor M contained in R^omega;Th4.4 obtains a sequence of unitary-conjugate sums converging in operator norm.','boundary':'Not arbitrary finite factors or exact one-shot conjugation;finite-dimensional phase inequality is not new application gain. Versioned notation inconsistencies in finite formula/proof retained as unresolved,not silently corrected or used to refute new paper.','body_checked':True,'local_name':'ALV2011v1.pdf'},
 'Kervaire1965':{'url':'https://www.numdam.org/item/10.24033/bsmf.1624.pdf','version':'Original1965 volume93 pp225-271,PDF48pages','read_scope':'PDF2 and4-6 (printed225,227-229),Introduction,necessary conditions,Th1.1,normalweight definition,Lemma1.2 proof andstartofsufficiency;PDF5pixels;not completepaper/proof','verified_statement':'For smooth n-knots with n>=3,the four conditions finite presentation,H1(group)=Z,H2(group)=0,normal weight1 characterize complement groups.','boundary':'Normal weight1 is not ordinary cyclic generation. Not a blanket n=1 or n=2 classification;historical motivation,not mandatory input to new embedding proof.','body_checked':True,'local_name':'Kervaire1965.pdf'}
}
for h in hist.values():
 if h.get('local_name'):
  a=next(x for x in acq['sources'] if x['name']==h['local_name'] and x.get('status')==200);h.update({k:a[k] for k in ['sha256','bytes']});assert sha((T/h['local_name']).read_bytes())==h['sha256']
bindings=[]
for tag,b in [('N',bn),('K',bk)]:
 for key,row in b.items():bindings.append({'qualified_key':tag+':'+key,'key':key,'target_id':lit[key],'path':row['path'],'line':row['line'],'reading_scope_this_package':'Internal companion fully read' if key=='OpenAIKervaire2026' else hist[key]['read_scope'] if key in hist else 'Bibliographic metadata only;body not read in this package','existing_record_reused':key=='Hatcher2002','no_proof_scope_inherited_from_identity':True})
gaps=[
 'All2currentmanuscripts/14TeX2157lines+109Bib+2READMEs36lines actuallyread;10manualresultbindings/20methods form a current-source draft,not complete family proof acceptance.',
 '31bibliographyoccurrences/24unique keys resolve23externalworks and1internal companion. Four originals checked only in declared scopes;19externalbodies and recursive lineage remain unread. Hatcher identity reused without importing proof scope.',
 'Selected one-variable/unimodular Lean endpoint andfour additional mapped natural bindings give5localB/5C only. General multirelator theorem remainsC. Entire dependency grades unknown;47files/743lexical declarations is not full proof reading,build,Comparator or axiom assurance.',
 'GR1962 primary cached article text read;direct403 and screenshot failure mean no local original SHA or pixels. Other arXiv versions not presumed journal-identical. External originals not republished.',
 'Existence of an overgroup is not a solution in originalG,a word-problem algorithm,finite/amenable/solvable/linear overgroup,or an isomorphic/conservative specification extension.',
 'No actual symbolic caller,inputbatch,guard implementation,certificateformat,independent embedding judge or cost evidence. Tietze/old embedding criteria may already cover all useful requests;application value may be zero.',
 'Both isolated auxiliary tasks used current selected OpenAI with exactbackend unknown,reviewed initial concept only,not independent suppliers/humans or a second review of final refinement. Allhuman/provider gates pending.'
]
ledger={'family_id':'F-256','work_package':'WP-097','generation_id':GEN,'recorded_at':NOW,'upstream_commit':UP,'project_base_commit':BASE,'manuscript_ids':J['current_manuscripts'],'read_files':{x['path']:{'sha256':x['sha256'],'total_lines':x['lines'],'read_ranges':[[1,x['lines']]],'fully_read':True} for x in J['files']},'include_closure':{'verified':True,'N_history_included_via':'sections/introduction.tex','K_external_runtime_inputs':['glyphtounicode','glyphtounicode-cmex'],'runtime_inputs_not_installed':True},'source_tex_files':14,'source_tex_lines':2157,'separate_bib_lines':109,'readme_lines':36,'results':D['results'],'methods':D['methods'],'bibliography_bindings':bindings,'historical_works':hist,'acquisition':acq,'pdf_pixels':pixels,'formal_statement_comparison':D['formal_statement_comparison'],'formal_actual_files':D['formal_actual_files'],'formal_index':'data/provenance/formal/F-256-import-index.json.gz','formal_index_files':47,'formal_index_declarations':743,'formal_definition_and_selected_statement_match_ignoring_whitespace':True,'domain_attempts':D['domain_attempts'],'cross_family_attempts':D['cross_family_attempts'],'role_receipt':role_receipt,'gaps':gaps,'full_family_complete':False,'historical_lineage_complete':False,'no_numerical_or_symbolic_benchmark':True,'publication':'Local research;no GitHub update,upstreammath excluded'}
lp='data/provenance/readings/F-256.json';assert not (R/lp).exists();write(lp,ledger)
cfg='data/provenance/research-at-generation-094.json';(R/cfg).write_bytes((R/'configs/research.json').read_bytes())
common=[source(lp,'WP097 full read inventory,manual contracts,selected history/formal scope and explicit limits')]
added=[];edges=[];edgeids={x['id'] for x in [json.loads(l) for l in oldedges.splitlines()]}
def node(id,kind,props,ss=None,evidence='source_content_checked'):
 assert id not in oldids and id not in {x['id'] for x in added},id
 props={'family_ids':['F-256'],'model_generation_id':GEN,'credibility':'unknown','dependency_closure_complete':False,**props}
 added.append({'id':id,'kind':kind,'version':1,'created_at':NOW,'evidence_status':evidence,'properties':props,'sources':ss or common.copy()})
def edge(a,rel,b,loc='WP097 manually curated dependency or contextual scope;not proof acceptance',ev='source_content_checked'):
 id='E-'+sha(f'{a}|{rel}|{b}'.encode())[:16].upper()
 assert id not in edgeids,(a,rel,b);edgeids.add(id);edges.append({'id':id,'source':a,'relation':rel,'target':b,'version':1,'created_at':NOW,'evidence_status':ev,'source_locator':loc,'source_commit':UP})
node(GEN,'generation',{'title':'F256 arbitrary group equations:source contracts,old scope and conditional coefficient-injectivity guard','provider':'OpenAI','model':'Current user-selected session;exact backend unknown','project_base_commit':BASE,'independent_second_provider':None,'human_review':None,'task':'Actual source curation and initial concept same-provider reviews,not proof or application validation'},common+[source(cfg,'Frozen research/storage/publication policy')])
resultids={x['qualified_label']:x['id'] for x in D['results']}
for x in D['results']:
 p={'title':x['qualified_label'],'statement':x['statement'],'conditions':[x['conditions']],'constants_and_constructions':[x['conditions']],'credibility':x['source_claim_grade'],'source_claim_grade':x['source_claim_grade'],'manuscript_id':x['manuscript_id'],'source_label':x['natural_label'],'statement_lines':x['statement_lines'],'formal_scope':'Selected local endpoint comparison only;not full imported proof/build/human' if x['source_claim_grade']=='B' else 'No separately compared formal endpoint for this full statement','human_specification_review':False}
 node(x['id'],'claim',p,[source(x['path'],f"{x['natural_label']} statement lines{x['statement_lines']};full file actuallyread",UP)]+common,evidence='source_claim')
 edge(x['id'],'derived_from',x['manuscript_id']);edge(x['id'],'member_of','F-256')
for m in D['methods']:
 ss=[source(next(x['path'] for x in D['results'] if x['qualified_label']==k),k+' full proof/method scope actually read',UP) for k in m['source_qualified_labels']]
 # Retain every distinct locator rather than deduplicating annotations by path.
 node(m['id'],'method',{'title':m['id'].removeprefix('PART-256-'),'input':m['input'],'output':m['output'],'conditions':m['conditions_and_nontransferability'],'cannot_transfer':m['conditions_and_nontransferability'],'source_result_ids':[resultids[k] for k in m['source_qualified_labels']],'application_gain_tested':False},ss+common)
for k in keys:
 if k in ['OpenAIKervaire2026','Hatcher2002']:continue
 ss=[]
 for tag,b in [('N',bn),('K',bk)]:
  if k in b:ss.append(source(b[k]['path'],f"Bibliographic key{k},entry begins line{b[k]['line']};metadata only except declared original scope",UP))
 rows=[b[k]['entry'] for b in [bn,bk] if k in b];doi=re.search(r'10\.\d{4,9}/[^\s{}]+',' '.join(rows));urls=re.findall(r'https://[^\s{}]+',' '.join(rows))
 p={'title':titles[k],'bibliography_keys':[b['qualified_key'] for b in bindings if b['key']==k],'retrieval_status':'selected_original_scope_checked' if k in hist else 'upstream_bibliography_only','verified_scope':hist[k]['read_scope'] if k in hist else 'Bibliographic metadata only;original body unread','no_full_work_or_recursive_proof_claim':True}
 if doi:p['doi']=doi.group(0).rstrip('.,')
 if k in hist:
  h=hist[k];p.update({'verified_statement':h['verified_statement'],'scope_boundary':h['boundary'],'original_version':h['version'],'original_link':h['url']});s={'url':h['url'],'locator':h['version']+';'+h['read_scope']+';'+h['boundary'],'content_checked':True,'checked_at':NOW}
  if 'sha256' in h:s['sha256']=h['sha256']
  ss.append(s)
 elif urls:
  p['original_link']=urls[0];ss.append({'url':urls[0],'locator':'URL printed in upstream bibliography;external body not fetched/read in WP097','content_checked':False})
 node(lit[k],'literature',p,ss+common,evidence='source_content_checked' if k in hist else 'source_claim')

# Actual logical skeleton: multi theorem does not depend on companion K main.
def dep(a,*bs):
 for b in bs:edge(a,'depends_on',b)
dep(resultids['N:thm:main'],resultids['N:prop:planar'],'PART-256-COEFFICIENT-BANDS','PART-256-INNERMOST-FILLING')
dep(resultids['N:prop:planar'],resultids['N:thm:fixed-space'],resultids['N:lem:phase-subadditivity'],resultids['N:lem:cycle-phase'],'PART-256-BALANCED-DISKS','PART-256-BOUNDARY-PERMUTATION','PART-256-BOUNDARY-PHASE-FLOW','PART-256-REVERSAL-MIXING','PART-256-PLANAR-PHASE-SANDWICH')
dep(resultids['N:thm:fixed-space'],'PART-256-NESTED-MINOR-ALLOCATION','PART-256-FIXEDPLANE-INCIDENCE','PART-256-EXTERIOR-INTERSECTION',lit['Borel1953'],lit['McCleary2001'],lit['Hatcher2002'])
dep(resultids['N:lem:phase-subadditivity'],'PART-256-FAITHFUL-REGULAR-TRACE','PART-256-PHASE-CUT','PART-256-PHASE-SUBADDITIVITY',lit['Jones2009'])
dep(resultids['N:lem:cycle-phase'],'PART-256-FAITHFUL-REGULAR-TRACE','PART-256-PHASE-CUT','PART-256-WEIGHTED-CYCLE')
dep(resultids['K:thm:main'],resultids['K:thm:planar'],'PART-256-COEFFICIENT-BANDS','PART-256-INNERMOST-FILLING')
dep(resultids['K:thm:planar'],resultids['K:lem:fixed'],resultids['K:lem:phase'],'PART-256-WEIGHTED-CYCLE','PART-256-BALANCED-DISKS','PART-256-BOUNDARY-PERMUTATION','PART-256-BOUNDARY-PHASE-FLOW','PART-256-REVERSAL-MIXING','PART-256-PLANAR-PHASE-SANDWICH')
dep(resultids['K:lem:fixed'],'PART-256-ONEBLOCK-DEGREE','PART-256-FIXEDPLANE-INCIDENCE',lit['Milnor1965'],lit['Hatcher2002'])
dep(resultids['K:lem:phase'],'PART-256-FAITHFUL-REGULAR-TRACE','PART-256-PHASE-CUT','PART-256-PHASE-SUBADDITIVITY',lit['Jones2009'])
dep(resultids['K:cor:kervaire'],resultids['K:thm:main'],'PART-256-NONTRIVIAL-CYCLIC-QUOTIENT')
# Standalone transferable conclusion must not escape its own source dependencies.
dep('PART-256-EXPONENT-RANK-INJECTION',resultids['N:thm:main'])
dep('PART-256-MULTI-FIXEDSPACE',resultids['N:thm:fixed-space'])
dep('PART-256-FINITE-SUPPORT-CLOSURE',resultids['N:thm:main'])
for k,id in lit.items():
 if k=='OpenAIKervaire2026':edge(resultids['N:thm:main'],'companion_context',id,'Companion proof strategy reproduced in N,not a mandatory theorem input')
 else:
  for tag,b in [('N',bn),('K',bk)]:
   if k in b:edge(resultids[tag+':thm:main'],'historical_context',id,'Bibliographic/history routing only;checked original scope and unread bodies distinguished in F256 ledger')
edge(resultids['N:thm:fixed-space'],'compared_with',lit['Nicolaescu2010'],'Related incidence/Schubert geometry,not unverified mandatory use')
for tag in ['N','K']:
 for k in ['AntezanaLarotondaVarela2012','Thompson1986']:
  edge(resultids['N:lem:phase-subadditivity'] if tag=='N' else resultids['K:lem:phase'],'compared_with',lit[k],'Old finite/embeddable-factor route comparison,not a premise of direct arbitrary-group phase proof')

problem='PROB-256-COEFFICIENT-INJECTIVITY-GUARD';app='APP-256-01';xp='XPL-256-TEN-DOMAINS'
prediction='For EVERY request in a separately frozen real admitted finite group-presentation pack with declared coefficient semantics,complete typed relators,exact full-row-rank witness bound to the full input,and independently supported canonical embedding evidence,the guard returns the correctly scoped source-conditional coefficient-injectivity assertion within all frozen caps. Any false embedding assertion,accepted invalid witness,input/map mismatch,excess semantic promise,timeout or in-pack resource failure falsifies functional coverage. Invalid inputs and unsupported rank cases must be distinguished and cannot count as successful embeddings. Measure useful decision coverage,abstentions and total cost against strongest applicable old methods;benefit may be zero. No speed or new-coverage gain is predicted before an actual caller and baseline are frozen.'
baseline=['Tietze/defined-new-generator isomorphism and supplied explicit embedding certificates,when their premises hold','Gerstenhaber-Rothaus finite/compact-Lie/faithful-residual routes;finite groups already have finite overgroup solutions','Howie locally indicable,Klyachko torsion-free unimodular,Nitsche-Thom Connes-embeddable presentation-complex/cover criteria where independently established;some originals remain unread','Unknown group class is not evidence outside old-method coverage;measure best applicable certified comparator at equal coverage and complete cost']
judge='Freeze actual consumer/version,group interpretation,all relator ASTs and canonical map,old-method applicability,admitted batch and held-out invalid/mismatch cases,CPU/memory/output caps before any outputs. A separately applicable older embedding theorem or explicit independently verified embedding certificate can judge supported subcases. Rechecking the same rank matrix,reusing the same generalC theorem,model agreement or guard-unit tests are not independent application validation. Labels covered by old methods test correctness but do not demonstrate new coverage. Count all premise/certificate discovery,verification,serialization,retries and abstentions.'
plan='experiments/plans/APP-256-01-conditional.json'
write(plan,{'id':app,'version':1,'status':'conditional_not_preregistered_not_run','model_generation_id':GEN,'analogy':'near','input':'Proposed real finite relatorbatch over declared coefficientG;no actualcaller or admittedpack yet','output':'Source-conditional injectivity of the canonical coefficient map only;not arbitrary specification conservativity','hypothesis':prediction,'judge':judge,'baseline':baseline,'limits':gaps,'source_labels':['N:thm:main'],'part_keys':['EXPONENT-RANK-INJECTION','FINITE-SUPPORT-CLOSURE'],'revisit':'Actual caller and precise coefficient equality semantics,admitted batch,independent embedding evidence and strongest applicable old baseline;then separately preregister before running','incremental_boundary':'Later relations can identify old coefficients. Each new batch must be validated against actual currentG and canonical map;old coefficient generators must not be relabelled fresh variables. Bind complete whole-batch matrix;never drop failing rows.','rank_certificate':'Exact nonzero maximal minor or verified rational right inverse bound to all typed relator ASTs,namespace,group/map identity and row/column ordering;format and checker not implemented','negative_semantics':'Rank failure unsupported,not coefficient collapse or danger. Malformed input,invalid witness,unsupported rank and resource failure must remain distinct.'})
node(problem,'problem',{'title':'向符号群表示添加新变量与关系时，保留原系数群及其等式语义','input':'Actual consumer not yet observed;requires supplied coefficient identity/semantics,typed fresh variables,complete relator AST and exact quotient map','output':'Conditional coefficient injectivity only','unestablished':'No actual caller,batch,independent judge or old-method coverage comparison'},evidence='hypothesis')
opinions={
 'opposition':{'text':'隔离怀疑者要求把non-collapse收窄为系数单射；精确秩证书必须绑定完整AST／命名空间／系数群和实际映射。后续关系可破坏旧系数，原文C定理与通用Lean覆盖不能偷换；Tietze和旧嵌入判据可能已足够。没有调用方／独立嵌入裁判／应用收益，保留待定。','task':'/root/f256_skeptic'},
 'defense':{'text':'隔离辩护者认为任意群的有限满行秩关系与符号输入有精确接口，值得保留条件后备守卫；需每次输出显式附原文及依赖条件，并绑定整批证书／增量语义。一般多关系C范围不能从单一unimodular的Lean端点借B；尚无实现、外检或旧方法增益。','task':'/root/f256_defender'}}
for p in opinions.values():p.update({'independent':False,'isolated_same_provider_agent':True,'receipt':rolepath,'timing':'pre-experiment;isolated OpenAI task on initial concept;not re-review of refined card','type':'same-provider isolated-agent auxiliary opinion;not cross-provider or human'})
node(app,'connection',{'title':'增量符号群表示的条件系数单射守卫','source_ids':[resultids['N:thm:main']],'history_ids':[lit[k] for k in ['GerstenhaberRothaus1962','NitscheThom2022','Howie1981','Klyachko1993']],'part_ids':['PART-256-EXPONENT-RANK-INJECTION','PART-256-FINITE-SUPPORT-CLOSURE'],'problem_id':problem,'mechanism':'从全部关系的整数指数矩阵精确满行秩，调用一般群系数单射原文结论；输出对原系数群等式／不等式的条件保留。证书可核对与完整定理可信度、实际应用价值分别记录。','prediction':prediction,'test_spec':plan,'run_ids':[],'opposition':opinions['opposition'],'defense':opinions['defense'],'theoretical_grade':'unknown','source_claim_grade':'C general multirelator main;K single-unimodular Lean endpoint does not cover it','sensitive':False,'resources':'No solver/large dependency/benchmark;first qualify real symbolic caller,independent embedding evidence and strong old baseline;compress any future numerical payloads after verified roundtrip','owner':'Current selected OpenAI session;human owner unassigned','workflow':'候选','application_result':'待定','limitations':gaps+['Not a solution insideG,word-problem decider,proofGnontrivial,quotient isomorphism or arbitrary first-order/existential specification conservativity. No finite/amenable/solvable/linear overgroup promised.','Rank failure means unsupported;later unchecked relations may collapse coefficients. Check actual current coefficient group/map for each whole batch.'],'revisit_when':'Actual caller/declared coefficient semantics,complete batch,independent embedding judge and old-method applicability;then separate frozen specification before outputs','analogy':'near','dedup_key':'F-256|incremental symbolic group presentations|source-conditional coefficient injectivity from complete exact full-row-rank relators','priority_reason':'Specific near mapping retained with exact premises;next bounded caller/old-method admission before implementation,no effectiveness or coverage advantage presumed','summary':{'status':'conditional_concept_not_admitted_not_run','initial_check_eligible':False,'supported':None},'external_check_type':'conditional_plan_not_run','baseline':baseline,'publication_scope':'Public proposed mathematical interface only,no external commitment'},common+[source(plan,'Conditional functional hypothesis and independent-judge/old-method admission;not preregistration or run'),source(rolepath,'Exact initial prompt,dispatch observation and raw isolated same-provider outputs')],evidence='hypothesis')
edge(app,'depends_on',resultids['N:thm:main']);edge(app,'uses','PART-256-EXPONENT-RANK-INJECTION');edge(app,'uses','PART-256-FINITE-SUPPORT-CLOSURE');edge(app,'addresses',problem)
for k in ['GerstenhaberRothaus1962','NitscheThom2022','Howie1981','Klyachko1993']:edge(app,'compared_with',lit[k],'Strong old-method null;not new-theorem proof prerequisite')
node(xp,'exploration',{'title':'F256 ten-domain and cross-family conditional interface exploration','domain_attempts':D['domain_attempts'],'cross_family_attempts':D['cross_family_attempts'],'candidate_connection_ids':[app],'fixedspace_route':'Shared unrestricted unitary block choices with total fixedspace bound and nested-minor allocation only;no real hardware caller,constructor,individual targets or robustness. Exploration only,not second candidate.','not_application_count':True},evidence='hypothesis')
edge(app,'explored_in',xp,'Ten-domain contextual record,not all mappings are proof prerequisites')
for c in D['cross_family_attempts']:edge(xp,'compared_with',c['target_id'],c['mapping']+';'+c['boundary'],ev='hypothesis')
for role in ['defender','skeptic']:
 rid='REV-256-'+role.upper()
 node(rid,'review',{'title':'F256 '+role+' isolated same-provider auxiliary opinion','subject_id':app,'actor_type':'model','decision':'retain_refine_conditional_concept','role':role,'provider':'OpenAI','exact_backend_model_id':'unknown','observed_utc':roles[role]['observed_utc'],'independent_supplier':False,'human':False,'external_evidence':None,'scope':'Initial proposal reviewed independently of other role output;not a fresh review of final card or application validation','receipt':rolepath},[source(rolepath,'Exact initial input and substantive raw '+role+' output with observed time/memberSHA')])
 edge(rid,'reviews',app,'Model auxiliary role,no human/provider approval')
node('ANALYSIS-F-256','family_analysis',{'title':'F256 current two-source decomposition draft','family_id':'F-256','manuscript_ids':J['current_manuscripts'],'manuscript_source_drafts_complete_ids':J['current_manuscripts'],'source_decomposition_draft_complete':True,'full_family_complete':False,'historical_lineage_complete':False,'source_sections':D['source_sections'],'source_line_count':2157,'source_result_count':10,'result_ids_by_label':resultids,'result_ids_by_source':D['by_source'],'method_ids':[m['id'] for m in D['methods']],'historical_references_by_key':{b['qualified_key']:b['target_id'] for b in bindings},'historical_verified_keys':sorted(hist),'bibliography_key_occurrences':31,'external_work_count':23,'internal_companion_references':1,'existing_literature_reused_without_body_evidence':['LIT-200-00F68475E7'],'formal_statement_comparison':D['formal_statement_comparison'],'formal_status':{'selected_registered_theorem':'OAI.Kervaire.coefficient_injective','selected_registered_scope':'K single variable/one unimodular relator only','mapped_local_B_bindings':5,'natural_C_bindings':5,'selected_actual_read_files':D['formal_actual_files'],'static_import_files':47,'static_declarations':743,'index':'data/provenance/formal/F-256-import-index.json.gz','challenge_definitions_and_selected_statement_match_ignoring_whitespace':True,'not_all_import_files_read':True,'local_build':'not_run','Comparator':'not_run','human_spec_review':'missing','complete_dependency_chain':'unknown'},'gaps':gaps,'source_scope':'All current natural source bodies;selected original history and formal scope only','reading_ledger':lp},common+[source('data/provenance/formal/F-256-import-index.json.gz','47localfiles743lexicaldeclarations;staticonly')]+[source(x['path'],f"Actually read ranges{x['body_read_ranges']},not fullimportclosure",UP) for x in D['formal_actual_files']])
edge('ANALYSIS-F-256','member_of','F-256')
for id in list(resultids.values())+[m['id'] for m in D['methods']]:edge('ANALYSIS-F-256','decomposes',id)
for n in added:
 if n['id']!=GEN:edge(n['id'],'generated_by',GEN)
allnodes=old+added;allids={n['id'] for n in allnodes}|set(load(R)[0]);assert all(e['source'] in allids and e['target'] in allids for e in edges)
# Nothing is changed on disk until all manual records and foreign keys have been assembled.
(R/'data/graph/nodes.jsonl').write_bytes(oldraw+b''.join((json.dumps(n,ensure_ascii=False,sort_keys=True)+'\n').encode() for n in added))
(R/'data/graph/edges.jsonl').write_bytes(oldedges+b''.join((json.dumps(e,ensure_ascii=False,sort_keys=True)+'\n').encode() for e in edges))
coverage=json.loads((R/'data/graph/reading_coverage.json').read_text());assert 'F-256' not in coverage['partially_read_families']
coverage['partially_read_families']['F-256']={'scope':'Bothcurrent14TeX2157lines+109Bib+2READMEs36lines;10results20methods,4originalselectedscopes8pixels and10selectedformalfiles;fullfamily/history/proof/humangates incomplete','evidence':lp,'manuscript_ids':J['current_manuscripts'],'full_family_complete':False}
coverage['source_decomposition_drafts'].append('F-256');coverage['updated_at']=NOW;write('data/graph/reading_coverage.json',coverage)
validation=validate(R)
receipt={'at':NOW,'project_base_commit':BASE,'new_records':len(added),'new_record_ids':[n['id'] for n in added],'new_explicit_edges':len(edges),'old_records_exact':len(old),'old_edges_exact':len(oldedges.splitlines()),'canonical_records':len(allnodes),'old_node_bytes_prefix_exact':(R/'data/graph/nodes.jsonl').read_bytes().startswith(oldraw),'old_edge_bytes_prefix_exact':(R/'data/graph/edges.jsonl').read_bytes().startswith(oldedges),'validation':validation,'results':10,'method_contracts':20,'bibliography_occurrences':31,'external_works':23,'new_literature_nodes':22,'existing_Hatcher_record_reused':True,'historical_originals_selected':4,'pixels':8,'new_candidates':1,'new_initial_checks':0,'no_experiments':True,'no_github_push':True,'role_receipt':role_receipt}
write('reports/reproducibility/20261023-group-equations/curation.json',receipt)
print(json.dumps(receipt,ensure_ascii=False))
