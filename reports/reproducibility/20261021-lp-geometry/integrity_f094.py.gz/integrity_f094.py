from pathlib import Path
import json,hashlib,datetime,subprocess,gzip
r=Path('/Users/smzdm/projects/ai_paper');out=r/'reports/reproducibility/20261021-lp-geometry';h=Path('/private/tmp/ai-paper-F094-history');sha=lambda b:hashlib.sha256(b).hexdigest();l=json.loads((r/'data/provenance/readings/F-094.json').read_text());now=datetime.datetime.now(datetime.timezone.utc).isoformat()
head_raw=subprocess.check_output(['git','show','HEAD:data/graph/nodes.jsonl'],cwd=r);old={json.loads(x)['id']:x for x in head_raw.splitlines()};new={json.loads(x)['id']:x for x in(r/'data/graph/nodes.jsonl').read_bytes().splitlines()};assert all(new[k]==v for k,v in old.items())
for f in l['read_files']+l['formal_files_actually_read']:assert sha((r/f['path']).read_bytes())==f['sha256']
idx=l['formal_status']['index_only'];p=r/idx['path'];assert sha(p.read_bytes())==idx['sha256'];j=json.loads(gzip.decompress(p.read_bytes()));assert j
stems={'GGNS':'ggns','SRS18':'srs','NaorRen2026Threshold':'naor-ren','Eskenazis2024':'eskenazis','Lamperti1958':'lamperti','JohnsonLindenstrauss1984':'jl1984'}
expected={}
for k,stem in stems.items():
 o=l['selected_original_scopes'][k];expected[stem+'.pdf']=o['pdf_sha256'];expected[stem+'.txt']=o['text_sha256']
 for f in o.get('actually_viewed_pixels',[]):expected[f['name']]=f['sha256']
assert set(expected)=={p.name for p in h.iterdir()};removed=[]
for p in h.iterdir():
 raw=p.read_bytes();assert sha(raw)==expected[p.name];removed.append(dict(name=p.name,bytes=len(raw),sha256=sha(raw)))
assert len(removed)==16
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r/'math').decode().strip()==l['upstream_commit'];assert not subprocess.check_output(['git','status','--porcelain'],cwd=r/'math').strip()
assert json.loads((out/'clean-directory.json').read_text())['exit_code']==0
for p in h.iterdir():p.unlink()
h.rmdir()
receipt=dict(recorded_at=now,old_canonical_nodes_unchanged=len(old),old_canonical_nodes_sha256=sha(head_raw),all_old_nodes_exact_bytes=True,selected_original_bodies_checked=6,whole_natural_read_files=3,formal_files_with_scoped_reads=9,formal_index_gzip_roundtrip=True,upstream_commit_unchanged=True,upstream_worktree_clean=True,temporary_files=removed,temporary_bytes_removed=sum(f['bytes']for f in removed),temporary_directory_removed=True,third_party_papers_redistributed=False,new_application_run=False,dependencies_installed=False,old_experiment_replays='Not repeated: WP052 receipts already13archives and actual314/076 unchanged experiments. No numerical-source change this package.')
(out/'source-and-cleanup-integrity.json').write_text(json.dumps(receipt,indent=2)+'\n');print({k:receipt[k]for k in['old_canonical_nodes_unchanged','temporary_bytes_removed','temporary_directory_removed','new_application_run']})
