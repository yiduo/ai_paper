from pathlib import Path
import json,gzip,hashlib,sys,datetime,xml.etree.ElementTree as ET,tempfile,shutil,subprocess,os
r=Path('/Users/smzdm/projects/ai_paper');sys.path.insert(0,str(r/'src'))
from ai_value.graph import load,validate
out=r/'reports/reproducibility/20261021-lp-geometry';now=datetime.datetime.now(datetime.timezone.utc).isoformat();nodes,edges=load(r);v=json.loads(gzip.decompress((r/'reports/graph/knowledge.json.gz').read_bytes()));tree=ET.fromstring(gzip.decompress((r/'reports/graph/knowledge.graphml.gz').read_bytes()));ns={'g':'http://graphml.graphdrawing.org/xmlns'}
assert {n['id'] for n in v['nodes']}==set(nodes)=={n.attrib['id'] for n in tree.findall('.//g:node',ns)}
assert {e['id'] for e in v['edges']}=={e['id'] for e in edges}=={e.attrib['id'] for e in tree.findall('.//g:edge',ns)}
assert len({e['id'] for e in edges})==len(edges)
assert all(e['source'] in nodes and e['target'] in nodes for e in edges)
assert all(e.attrib['source'] in nodes and e.attrib['target'] in nodes for e in tree.findall('.//g:edge',ns))
files={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in (r/'reports/graph').iterdir() if p.is_file()}
q={'recorded_at':now,'core_tests_passed':47,'validation':validate(r),'full_graph_and_gzip_exports_consistent':True,'edge_ids_unique':True,'endpoints_valid':True,'files':files,'browser_visual_check':'not repeated;viewer logic unchanged','local_Lean_or_Comparator':False,'remote_CI':False}
(out/'graph-export.json').write_text(json.dumps(q,indent=2)+'\n')
with tempfile.TemporaryDirectory(prefix='ai-paper-cleanlp-') as td:
 dest=Path(td)
 for directory in ['src','tests','scripts','configs','schemas','data','experiments']:
  if (r/directory).exists():shutil.copytree(r/directory,dest/directory,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
 for n in nodes.values():
  for s in n.get('sources',[]):
   path=s.get('path','')
   if path and not path.startswith('math/'):
    target=dest/path;target.parent.mkdir(parents=True,exist_ok=True)
    if not target.exists():shutil.copy2(r/path,target)
 for d in ['reports/cards','reports/families','reports/failures','state']:(dest/d).mkdir(parents=True,exist_ok=True)
 assert not (dest/'math').exists()
 env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1');result=subprocess.run([sys.executable,'scripts/check.py'],cwd=dest,env=env,capture_output=True,text=True)
 clean={'recorded_at':now,'upstream_clone_present':False,'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr,'cleanup':'TemporaryDirectory removed;minimal referenced files and sources,no upstream clone','remote_CI':False}
(out/'clean-directory.json').write_text(json.dumps(clean,indent=2)+'\n');assert result.returncode==0,result.stderr[-1000:]
print(json.dumps({'nodes':len(nodes),'edges':len(edges),'clean_checks':clean['exit_code'],'temporary_copy_removed':True}))
