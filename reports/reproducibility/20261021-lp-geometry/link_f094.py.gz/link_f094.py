from pathlib import Path
import json,hashlib,datetime
r=Path('/Users/smzdm/projects/ai_paper');p=r/'data/graph/edges.jsonl';es=[json.loads(x)for x in p.read_text().splitlines()];ids={e['id']for e in es};now=datetime.datetime.now(datetime.timezone.utc).isoformat();C='1581d4cbdd69a0faf34b2089614fe2a814316a6a'
links=[('ANALYSIS-F-094','member_of','F-094','Whole-natural draft; full family/history incomplete'),('ANALYSIS-F-094','derived_from','P-7ed3cd025e4304a8','Single actual manuscript2TeX1505lines'),('CHECK-094-FORMAL-SCOPE','reviews','CLM-094-THM-MAIN','Selected static main only'),('CHECK-094-FORMAL-SCOPE','reviews','CLM-094-LEM-LOCALIZATION','General connected natural versus complete-pair formal'),('CHECK-094-FORMAL-SCOPE','reviews','CLM-094-LEM-PROJECTION','Brouwer sigma orthogonality versus simultaneous retraction witness')]
for a,b in [('WEIGHTED-TO-UNIFORM','SCALED-GRADIENT'),('MOMENT-SAMPLING','WEIGHTED-TO-UNIFORM'),('FIXED-POINT-WEIGHTS','SYMMETRIC-LOCALIZATION'),('FIXED-POINT-WEIGHTS','SCALED-GRADIENT'),('ENERGY-CONTRACTION','FIXED-POINT-WEIGHTS'),('CLIP-THEN-PROJECT','SMALL-JUMP-LIMIT'),('CLIP-THEN-PROJECT','FIXED-POINT-WEIGHTS'),('OVERLAPPING-RAMPS','NEAR-ADDITIVE'),('WHOLE-VECTOR-TRUNCATION','OVERLAPPING-RAMPS'),('SYMMETRIC-LOCALIZATION','HEAT-ENTROPY'),('EXACT-DISJOINTNESS','DISTANCE-CONE'),('SMALL-N-PATCH','DISTANCE-CONE')]:
 if a=='EXACT-DISJOINTNESS':continue # distinct lower and upper proofs, no false dependency
 links.append(('PART-094-'+a,'depends_on','PART-094-'+b,'Selected natural construction dependency, not complete proof closure'))
for a,rel,b,loc in links:
 eid='E-'+hashlib.sha256(f'{a}|{rel}|{b}'.encode()).hexdigest()[:16].upper();assert eid not in ids;es.append(dict(id=eid,source=a,relation=rel,target=b,source_locator=loc,source_commit=C,created_at=now,version=1,evidence_status='source_claim'));ids.add(eid)
p.write_text(''.join(json.dumps(e,ensure_ascii=False,sort_keys=True)+'\n'for e in es));print({'additional_explicit_edges':len(links)})
