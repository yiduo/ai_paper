from pathlib import Path
import gzip,json,hashlib,subprocess,datetime,shutil
r=Path('/Users/smzdm/projects/ai_paper');out=r/'reports/reproducibility/20261021-factor-interfaces';t=Path('/private/tmp/ai-paper-F120-interfaces');sha=lambda b:hashlib.sha256(b).hexdigest();now=datetime.datetime.now(datetime.timezone.utc).isoformat();l=json.loads((r/'data/provenance/demand/F-120-factor-contracts.json').read_text());assert json.loads((out/'clean-directory.json').read_text())['exit_code']==0
p=r/l['source_archive'];raw=gzip.decompress(p.read_bytes());assert sha(p.read_bytes())==l['source_archive_sha256'] and sha(raw)==l['source_archive_decompressed_sha256'];d=json.loads(raw)
for s in l['sources'].values():
 for name,h in s['archive_members'].items():assert sha(d['files'][name].encode())==h
head={n['id']:n for n in map(json.loads,subprocess.check_output(['git','show','HEAD:data/graph/nodes.jsonl'],cwd=r,text=True).splitlines())};cur={n['id']:n for n in map(json.loads,(r/'data/graph/nodes.jsonl').read_text().splitlines())};changed={'APP-120-01','ANALYSIS-F-120'};old=json.loads(gzip.decompress((r/'data/graph/history/GEN-20261021-049-before.json.gz').read_bytes()))['records'];assert{n['id']for n in old}==changed;assert all(n==head[n['id']]for n in old);assert all(cur[k]==n for k,n in head.items()if k not in changed)
archives=[]
for folder in sorted((r/'experiments/runs').iterdir()):
 if not(folder/'manifest.json').exists():continue
 m=json.loads((folder/'manifest.json').read_text())
 for name,s in m['outputs'].items():assert sha((folder/name).read_bytes())==s
 for name,s in m.get('compressed_payloads',{}).items():assert sha(gzip.decompress((folder/name).read_bytes()))==s['uncompressed_sha256']
 snap=json.loads(gzip.decompress((folder/'inputs.json.gz').read_bytes()));assert set(snap)==set(m['inputs']);assert all(sha(content.encode())==m['inputs'][name]for name,content in snap.items());archives.append(dict(run_id=m['run_id'],compressed_outputs_match=True,decompressed_payloads_match=True,source_members_match=True))
assert len(archives)==13;(out/'all-thirteen-archives-integrity.json').write_text(json.dumps(dict(recorded_at=now,archives=archives),indent=2)+'\n')
for name in ['wp052-replay-314-supported.json','wp052-replay-076-adverse.json']:
 p=Path('/private/tmp')/name;v=json.loads(p.read_text());assert v['run_id']==v['replay_run_id'] and all(v['deterministic_outputs_match'].values());shutil.copy2(p,out/name.removeprefix('wp052-'))
expected={}
for key,name in [('nx-regular','networkx-regular.py'),('nx-tests','networkx-test-regular.py'),('nx-benchmark','networkx-benchmark-regular.py'),('nx-matching','networkx-matching.py'),('nx-license','networkx-LICENSE.txt'),('sage-graph','sage-graph.py'),('sage-license','sage-COPYING.txt')]:expected[name]=l['sources'][key]['sha256']
a=l['selected_primary'];expected.update({'mnr2009.pdf':a['pdf_sha256'],'mnr2009.txt':a['text_sha256'],**a['pixel_sha256']});assert set(expected)=={p.name for p in t.iterdir()};removed=[]
for name,h in expected.items():
 b=(t/name).read_bytes();assert sha(b)==h;removed.append(dict(file=name,sha256=h,bytes=len(b)))
for f in removed:(t/f['file']).unlink()
t.rmdir();(out/'source-and-cleanup-integrity.json').write_text(json.dumps(dict(recorded_at=now,archive_gzip_sha256=l['source_archive_sha256'],decompressed_sha256=l['source_archive_decompressed_sha256'],archive_member_count=l['archive_member_count'],member_hashes_and_roundtrip_verified=True,prior2nodes_match_HEAD=True,other_prior_nodes_unchanged=len(head)-2,all13archives_verified=True,actual_replays=['EXP314 limited support','EXP076 adverse'],temporary_files=removed,temporary_bytes_removed=sum(f['bytes']for f in removed),temporary_directory_removed=True,upstream_copy=False,dependencies_installed=False,new_application_run=False,third_party_papers_redistributed=False,software_interfaces_executed=False),indent=2)+'\n');print(dict(archive_members=l['archive_member_count'],selected_source_lines=l['selected_source_lines'],all13archives=True,replays=2,temporary_bytes_removed=sum(f['bytes']for f in removed),other_prior_nodes_unchanged=len(head)-2))
