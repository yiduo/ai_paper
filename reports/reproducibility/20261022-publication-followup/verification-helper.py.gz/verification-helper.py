from pathlib import Path
import base64, datetime, gzip, hashlib, json, subprocess, sys, urllib.parse, urllib.request

root = Path('/Users/smzdm/projects/ai_paper')
out = root / 'reports/reproducibility/20261022-publication-followup'
out.mkdir(parents=True, exist_ok=True)
repo = 'yiduo/ai_paper'
commit = sys.argv[2]

def get(endpoint):
    request = urllib.request.Request('https://api.github.com/repos/'+repo+endpoint,
                                     headers={'Accept':'application/vnd.github+json',
                                              'User-Agent':'ai-paper-anonymous-publication-verification'})
    with urllib.request.urlopen(request,timeout=40) as response:
        raw = response.read(5*1024*1024+1)
        assert len(raw) <= 5*1024*1024
    return json.loads(raw)

def save(name,obj):
    raw = (json.dumps(obj,ensure_ascii=False,indent=2)+'\n').encode()
    path = out/name
    path.write_bytes(gzip.compress(raw,mtime=0))
    assert gzip.decompress(path.read_bytes()) == raw

if sys.argv[1] == 'verify':
    metadata = get('')
    assert metadata['private'] is False and metadata['visibility']=='public'
    remote = get('/git/ref/heads/main')
    assert remote['object']['sha']==commit
    obj = get('/git/commits/'+commit)
    expected = subprocess.check_output(['git','rev-parse',commit+'^{tree}'],cwd=root).decode().strip()
    assert obj['tree']['sha'] == expected
    tree = get('/git/trees/'+expected+'?recursive=1')
    assert not tree['truncated']
    blobs = {x['path']:x['sha'] for x in tree['tree'] if x['type']=='blob'}
    local = {}
    for row in subprocess.check_output(['git','ls-tree','-rz',commit],cwd=root).split(b'\0'):
        if row:
            meta,path = row.split(b'\t',1)
            mode,kind,oid = meta.split()
            assert kind == b'blob' and mode != b'120000'
            local[path.decode()] = oid.decode()
    assert local == blobs
    assert not any(x=='math' or x.startswith('math/') for x in blobs)
    files=[]
    for name in ['722篇AI数学论文应用价值挖掘纲领.md','CHARTER.en.md','PROGRESS.en.md','reports/F025-demand-followup.md']:
        data=get('/contents/'+urllib.parse.quote(name)+'?ref='+commit)
        raw=base64.b64decode(data['content'])
        assert raw == subprocess.check_output(['git','show',commit+':'+name],cwd=root)
        files.append(dict(path=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
    receipt=dict(verified_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                 repository_url=metadata['html_url'],public=True,anonymous_api=True,
                 commit=commit,tree=expected,all_blob_paths_and_git_object_ids_match=True,
                 files=len(blobs),upstream_math_paths=0,selected_public_bytes=files,
                 CI_verified=False,scope='Exact scientific progress snapshot through WP089/retro032; not bulk local history or phase-one acceptance')
    save('WP087-WP089-publication-verification.json.gz',receipt)
    print(json.dumps(receipt,ensure_ascii=False))
elif sys.argv[1]=='ci':
    runs=get('/actions/runs?per_page=10')['workflow_runs']
    selected=[x for x in runs if x['head_sha']==commit and x['name']=='offline-core']
    receipt=dict(checked_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                 head_sha=commit,runs=[{k:x.get(k) for k in ['id','name','head_sha','status','conclusion','html_url','created_at','updated_at','run_attempt']} for x in selected],
                 scope='68 core checks,13 archived replays,exports and publication audit as configured; no Lean, human, biological or optional NumPy validation')
    save('WP087-WP089-CI-observation.json.gz',receipt)
    print(json.dumps(receipt))
