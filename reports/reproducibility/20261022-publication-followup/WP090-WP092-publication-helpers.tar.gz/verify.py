"""Anonymous normal-TLS verification against the exact published commit, not a changing worktree."""
import base64,datetime,hashlib,json,subprocess,urllib.request
from pathlib import Path
from urllib.parse import quote
R=Path('/Users/smzdm/projects/ai_paper');D=Path(__file__).parent;expected=json.loads((D/'candidate.json').read_text());base='https://api.github.com/repos/yiduo/ai_paper'
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
def get(path):
 req=urllib.request.Request(base+path,headers={'User-Agent':'ai-paper-scoped-publication-verifier','Accept':'application/vnd.github+json'})
 with opener.open(req,timeout=40) as response:return json.load(response)
repo=get('');ref=get('/git/ref/heads/main');assert repo['private'] is False and ref['object']['sha']==expected['public_commit']
commit=get('/git/commits/'+expected['public_commit']);assert commit['tree']['sha']==expected['public_tree'];assert [p['sha'] for p in commit['parents']]==[expected['public_parent']]
tree=get('/git/trees/'+expected['public_tree']+'?recursive=1');assert tree.get('truncated') is False
assert not any(x['path']=='math' or x['path'].startswith('math/') for x in tree['tree'])
local={}
for row in subprocess.check_output(['git','ls-tree','-rlz',expected['public_commit']],cwd=R).split(b'\0'):
 if not row:continue
 meta,name=row.split(b'\t',1);mode,typ,sha,size=meta.split();local[name.decode()]={'mode':mode.decode(),'type':typ.decode(),'sha':sha.decode(),'size':int(size)}
remote={x['path']:{k:x[k] for k in ['mode','type','sha','size']} for x in tree['tree'] if x['type']=='blob'};assert remote==local
selected={}
for name in ['CHARTER.en.md','722篇AI数学论文应用价值挖掘纲领.md','PROGRESS.en.md','README.en.md','reports/metrics.json','reports/retrospectives/033-counting-cost-and-continuum-scope.md']:
 j=get('/contents/'+quote(name)+'?ref='+expected['public_commit']);b=base64.b64decode(j['content']);assert b==subprocess.check_output(['git','show',expected['public_commit']+':'+name],cwd=R);selected[name]=hashlib.sha256(b).hexdigest()
runs=get('/actions/runs?head_sha='+expected['public_commit']+'&per_page=3')['workflow_runs'];assert runs
result={'verified_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repository_url':repo['html_url'],'public':not repo['private'],'anonymous_read_verified':True,'verified_commit':expected['public_commit'],'verified_tree':expected['public_tree'],'verified_only_public_parent':expected['public_parent'],'all_blob_paths_modes_sizes_shas_match':True,'files':len(local),'total_bytes':sum(x['size'] for x in local.values()),'official_math_paths':0,'selected_files_sha256':selected,'ci':[{k:x.get(k) for k in ['id','name','head_sha','status','conclusion','html_url','created_at','updated_at','run_attempt']} for x in runs]}
(D/'verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False))
