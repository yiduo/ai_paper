from pathlib import Path
import json,gzip,hashlib,sys,subprocess,xml.etree.ElementTree as ET
R=Path('/Users/smzdm/projects/ai_paper');T=Path('/private/tmp/ai-paper-WP106');O=R/'reports/reproducibility/20261023-rational-psd';BASE='a1c355c';sys.path.insert(0,str(R/'src'))
from ai_value.graph import load,affected_nodes,theoretical_grade
from ai_value.knowledge import export
from ai_value.reporting import render
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(n,j):
 b=(json.dumps(j,ensure_ascii=False,indent=2)+'\n').encode();z=gzip.compress(b,mtime=0);assert gzip.decompress(z)==b;(O/n).write_bytes(z)
nodes,edges=load(R);cases=[];gate='CHECK-174-RATIONAL-PSD-ADMISSION';xpl='XPL-174-RATIONAL-PSD-CALLERS';main='CLM-174-THM-MAIN';alg='CLM-174-THM-TT-ALGORITHM';psd='CLM-174-LEM-RATIONAL-PSD'
def check(name,seeds,yes,no):
 h=affected_nodes(nodes,edges,set(seeds));assert set(yes)<=h,(name,'missing',set(yes)-h);assert not(set(no)&h),(name,'false',set(no)&h);cases.append({'name':name,'changed':seeds,'expected_review':yes,'expected_unaffected':no,'affected':sorted(h),'pass':True})
for p in ['SYMPY','QISKIT','CVXPY']:
 check(p+'_caller_contract',[f'CHECK-174-{p}-PSD-CONTRACT'],[gate,xpl],[main,alg,psd])
for i in ['OLD-174-SYMPY-WEIGHTED-LDL','OLD-174-QISKIT-NUMERIC-KRAUS','OLD-174-CVXPY-NUMERIC-QUAD']:
 check(i,[i],[gate,xpl],[main,alg,psd])
check('rational_lemma_routes_future_interface',[psd],['PART-174-RATIONAL-PSD-OUTERS',gate,xpl,alg],[main,'APP-304-01'])
check('actual_Qiskit_implementation',['LIT-174-PSD-QISKIT-TRANSFORMATIONS'],['CHECK-174-QISKIT-PSD-CONTRACT',gate,xpl],[main,alg,psd])
check('actual_CVXPY_canon',['LIT-174-PSD-CVXPY-QUAD-FORM-CANON'],['CHECK-174-CVXPY-PSD-CONTRACT',gate],[main,alg,psd])
check('old_EJ_source_retained',['LIT-174-EZEUNALAJIANG2026'],['CLM-174-THM-RATIONAL-SIGNING',alg],[main,psd,gate])
check('old_AOG_context_retained',['LIT-174-ANARIOVEISGHARAN2015'],[],[main,alg,gate])
check('F304_component_retained',['CLM-304-LAT-FINITE-CHASES'],['APP-304-01'],[main,alg,gate])
check('F256_consumer_gap_retained',['LIT-256-GAP-FP-INTERFACE'],['APP-256-01'],[main,alg,gate])
assert all(theoretical_grade(nodes,edges,i)=='unknown' for i in [main,alg,psd,gate,xpl]);write('impact.json.gz',{'count':len(cases),'cases':cases,'scope':'Review routing,not proof approval or application efficacy'})
ex=export(R);j=json.loads(gzip.decompress((R/'reports/graph/knowledge.json.gz').read_bytes()));assert {n['id']:n for n in j['nodes']}==nodes and j['edges']==edges
ns={'g':'http://graphml.graphdrawing.org/xmlns'};tree=ET.fromstring(gzip.decompress((R/'reports/graph/knowledge.graphml.gz').read_bytes()));gn={n.attrib['id']:json.loads(next(d.text for d in n if d.attrib.get('key')=='properties')) for n in tree.findall('.//g:node',ns)};ge={n.attrib['id']:json.loads(next(d.text for d in n if d.attrib.get('key')=='evidence')) for n in tree.findall('.//g:edge',ns)};assert gn==nodes and ge=={e['id']:e for e in edges};write('exports.json.gz',{'export':ex,'json_full_nodes_edges_exact':True,'graphml_full_nodes_edges_exact':True})
archives=[];members=0
for p in sorted((R/'experiments/runs').glob('*/manifest.json')):
 m=json.loads(p.read_text())
 for n,h in m['outputs'].items():
  b=(p.parent/n).read_bytes();assert sha(b)==h
  if n.endswith('.gz'):gzip.decompress(b)
 for n,d in m.get('compressed_payloads',{}).items():assert sha(gzip.decompress((p.parent/n).read_bytes()))==d['uncompressed_sha256']
 s=json.loads(gzip.decompress((p.parent/m['source_snapshot']).read_bytes()));assert set(s)==set(m['inputs']);assert all(isinstance(t,str) and sha(t.encode())==m['inputs'][n] for n,t in s.items());members+=len(s);archives.append({'run_id':m['run_id'],'source_members':len(s),'all_hashes_verified':True,'scientific_replay':False})
assert len(archives)==15 and members==267;write('archives.json.gz',{'archives':archives,'count':len(archives),'source_members':members,'reason_no_replay':'No experimental source/spec/data/comparator changed;this is source-contract qualification only,not another hypothesis or replay'})
oldraw=subprocess.check_output(['git','show',BASE+':data/graph/nodes.jsonl'],cwd=R);olded=subprocess.check_output(['git','show',BASE+':data/graph/edges.jsonl'],cwd=R);raw=(R/'data/graph/nodes.jsonl').read_bytes();eraw=(R/'data/graph/edges.jsonl').read_bytes();assert raw.startswith(oldraw) and eraw.startswith(olded);assert len(oldraw.splitlines())==4514 and len(raw.splitlines())==4531;assert len(eraw.splitlines())-len(olded.splitlines())==39
protected=0
for prefix in ['experiments','src','tests','data/provenance/readings','reports/families']:
 paths=subprocess.check_output(['git','ls-tree','-r','--name-only',BASE,'--',prefix],cwd=R,text=True).splitlines()
 for p in paths:assert (R/p).read_bytes()==subprocess.check_output(['git','show',BASE+':'+p],cwd=R),p;protected+=1
assert (R/'data/graph/reading_coverage.json').read_bytes()==subprocess.check_output(['git','show',BASE+':data/graph/reading_coverage.json'],cwd=R)
write('canonical-preservation.json.gz',{'base':BASE,'old_records':4514,'alloldrecordlines_and_oldedgebytes_exact':True,'protected_files_exact':protected,'all_previous_source_reading_coverage_unchanged':True,'new_records':17,'new_edges':39,'new_candidates':0,'new_initial_checks':0,'new_application_runs':0})
l=json.load(open(R/'data/provenance/demand/F-174-rational-psd-contracts.json'));assert len(l['projects'])==3 and len(l['selected_source_files'])==7 and l['selected_source_lines']==1350
for f in l['selected_source_files']:assert sha(Path(f['path']).read_bytes())==f['sha256'] and not f['actually_executed']
for r in l['acquisition']['requests']:
 if r['status']=='acquired':assert sha(Path(r['path']).read_bytes())==r['sha256']
assert l['acquisition']['download_bytes']==162810 and not l['decision']['admitted_real_consumer'];assert all(not c['unweighted_rational_columns_required'] for c in l['contracts'])
m=render(R);assert m['candidate_connections']==44 and m['externally_checked_cards']==13 and m['source_decomposition_drafts']==51 and m['partial_reading_families']==56
cur=[json.loads(x) for x in raw.splitlines()];sources=[s for n in cur for s in n['sources']]
receipt={'selected_projects':3,'selected_source_files':7,'selected_source_lines':1350,'all_acquired_and_selected_body_hashes_verified':True,'unknown_byte_hash_nulls_not_introduced':not any('url'in s and 'sha256'in s and s['sha256'] is None for n in cur[-17:] for s in n['sources']),'all_canonical_annotations':len(sources),'local_annotations':sum('path'in s for s in sources),'external_annotations':sum('url'in s for s in sources),'external_without_byte_hash':sum('url'in s and not s.get('sha256') for s in sources),'primarybody_download_bytes':162810,'metrics':m};assert receipt['unknown_byte_hash_nulls_not_introduced'];write('source-contracts.json.gz',receipt);print(json.dumps({'full_nodes':len(nodes),'full_edges':len(edges),'canonical_records':len(cur),'impact_cases':len(cases),**receipt},ensure_ascii=False))
