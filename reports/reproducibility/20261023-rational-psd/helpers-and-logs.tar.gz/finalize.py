from pathlib import Path
import json,gzip,tarfile,io,hashlib,datetime
R=Path('/Users/smzdm/projects/ai_paper');T=Path('/private/tmp/ai-paper-WP106');O=R/'reports/reproducibility/20261023-rational-psd';Q=str(O.relative_to(R));now=datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda b:hashlib.sha256(b).hexdigest()
def load(p):return json.load(open(R/p))
def put(p,j):p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
clean=json.loads(gzip.decompress((O/'no-math-clean-directory.json.gz').read_bytes()));assert clean['exit_code']==0 and not clean['upstream_math_present'] and not (T/'no-math-clean').exists()
log=(T/'core.log').read_text();assert 'Ran 69 tests' in log and '\nOK\n' in log and '"canonical_citations": 7909' in log and 'Traceback' not in log
l=load('data/provenance/demand/F-174-rational-psd-contracts.json');third=[]
for r in l['acquisition']['requests']:
 if r['status']!='acquired':continue
 p=Path(r['path']);b=p.read_bytes();assert sha(b)==r['sha256'];third.append({'path':str(p),'bytes':len(b),'sha256':sha(b),'project':r['project'],'type':'temporary_primary_source_or_license'})
assert len(third)==10 and sum(d['bytes'] for d in third)==162810
for d in third:Path(d['path']).unlink()
assert all(not Path(d['path']).exists() for d in third)
put(T/'cleanup-source-receipt.json',{'at':now,'verified_removed':third,'bytes_removed':162810,'policy':'No third-party source or license-body republishing;hashes,versions,own scope notes retained;no installs or new numerical data.'})
b=load('state/backlog.json');task=next(x for x in b['tasks'] if x['id']=='WP-106');assert task['status']=='source_qualification_done_quality_pending';task.update(status='completed',completed_at=now,quality_scope='69core/fullsourceFKgates/13impact/fullJSONGraphML/15archives267members/no-mathclean passed;storageverified separately;no scientificreplay/newexperiment');b['updated_at']=now;put(R/'state/backlog.json',b)
c=load('state/checkpoint.json');c.update(saved_at=now,overall_status='active_incomplete',last_completed_work_package=task,active_work_package=None,work_packages_since_last_retrospective=2,retrospective_due_after='Mandatoryretro038 immediatelyafterWP107,earlier significant evidence/two no-information packages',running_research_experiments=[],storage_receipt=Q+'/storage.json');assert 'WP-106' not in c['completed_work_packages'];c['completed_work_packages'].append('WP-106')
c['recovery_observation'].update(at=now,checkpoint_core_check='69core/fullsourceFKgates/13impact/fullJSONGraphML/15archives267members/no-mathclean exit0;initial invalid-ID draft retained and repaired;storageverified byreceipt',research_processes_observation='WP106acquisition/curation/repair/QA/core/clean handles terminal;no scientific/replay/Lean/Comparator process started. Previous observed unrelatedPython76009cwdprojects/codex_token,notthisproject.',current_reading='WP106qualified source contracts complete;nextF360onlytwoREADME20each/inventory13TeX5013+389Bib,body/formal/historyunread',public_state='No GitHub write;last verified publicf0c3ddc,WP093-WP106/retro034-037 local')
c['resume_commands']=['Readgoal/AGENTS/charter/roadmap/status/checkpoint/backlog/latestretro037;verifydisk/process/finalquality/storage','WP106complete17newrecords39edges;do not rerun curator or reacquire7sourcefiles/3licenses;API403/TLSfailures+connector recovery and invalid-ID draft preserved','Read rationalPSDcontracts:3real relatedcallers,no admitted exactunweightedrational task,batch,judge orbenefit;no newcandidate/scienceoutputs. SourcelemmaF174/oldledger unchanged','BeginWP107F360all13TeX5013+389Bib2manuscripts;onlytwoREADME20each and inventoryread,notbody/formal/historycoverage','AfterWP106counter2;mandatoryretro038afterWP107 or early major evidence/two no-information packages. Routine localonly,noGitHubpush,mathreadonly/excluded,human/providerdeferrednotwaived'];c['recovery_commands']=c['resume_commands'];put(R/'state/checkpoint.json',c)
j=load('state/reading-progress/WP-106.json');j.update(at=now,status='completed_source_qualification',quality_evidence=Q,new_records=17,new_explicit_edges=39,next_action='WP107F360 complete currentbodies/formal/history,then mandatoryretro038;no extension of thisthree-project search');put(R/'state/reading-progress/WP-106.json',j)
with (R/'state/work_packages.jsonl').open('a') as f:f.write(json.dumps({'at':now,'id':'WP-106','status':'completed','evidence':'data/provenance/demand/F-174-rational-psd-contracts.json','quality':Q,'new_records':17,'new_explicit_edges':39,'new_candidates':0,'new_initial_checks':0,'retrospective_counter':2,'github_push':False,'next':'WP-107'},ensure_ascii=False,sort_keys=True)+'\n')
(O/'quality.md').write_text(f'''# WP106 quality and evidence scope

All69 core checks and complete source/FK/gate/provenance checks passed. Thirteen new and old dependency-impact cases passed;complete JSON and GraphML objects exactly match the full graph. All15 experiment archives and267 source members passed compressed/decompressed integrity. No experimental source/spec/data/comparator changed;no new scientific replay or application validation is claimed.

The independent clean directory without math or Git history passed the full check with exit0:{clean['files']} files/{clean['copied_bytes']} bytes copied and individually verified,then removed. Without upstream,the pinned checksum manifest checks source hashes;it does not freshly read the originals.

Current full graph7388nodes/20397relations,4531canonicalrecords,7909sourceannotations(7899core-validated). All4514oldrecord lines,oldedgebytes,oldcandidates,experimental sources/data/tests,readingledgers,coverage and51oldfamilyreports remain byte-exact. New17records/39explicitrelations record three projects/seven files/1350actuallyread selectedlines. Candidate44/preliminary13/distinct13 and56readfamilies/51source drafts unchanged. Fullfamily/history/human/provider/pilots remain0.

Initial curator validation rejected two filename-derived stableIDs containing underscores. Exact unaccepted nodes/edges/ledger and firstfailure log are retained compressed;only these IDs/references and their source-hash bindings were repaired. No old record or caller/theorem fact changed. The curator was not rerun against already appended state. All new external source citations have actualbodyhashes,no null unknownhashes introduced.

Three direct release API403rate limits and one rawTLS timeout are retained. Official releasepage commit links supplied fixed revisions;one missing CVXPY source recovered via read-only GitHubconnector matched recomputed reportedGitblobSHA1. No signature verification or runtime behavior is claimed. All162810 successful primary source/license bytes were hash-verified and removed,not republished. Own helpers/logs/failures are compressed with every member's decompressed SHA256 verified before plaintext removal;actual storage receipt is storage.json.

No dependency install,repository clone,new scientific experiment,Lean/Comparator build,GitHub write or officialmath deployment. Source-contract qualification does not prove no other exactconsumer exists. ExactPSD/Choi certificate possibility retained without an application claim;stop three-project search,rotate WP107toF360bodies/formal/history. Counter2afterretro037;mandatoryretro038afterWP107 or earlier significant evidence. Overallgoalactive_incomplete.
''')
own=sorted(p for p in T.iterdir() if p.is_file());assert all(p.suffix in {'.py','.json','.log'} for p in own),[p.name for p in own]
members=[];buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w') as tf:
 for p in own:
  body=p.read_bytes();info=tarfile.TarInfo(p.name);info.size=len(body);info.mtime=0;info.mode=0o644;tf.addfile(info,io.BytesIO(body));members.append({'name':p.name,'bytes':len(body),'sha256':sha(body)})
raw=buffer.getvalue();compressed=gzip.compress(raw,mtime=0);assert gzip.decompress(compressed)==raw;path=O/'helpers-and-logs.tar.gz';path.write_bytes(compressed)
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(path.read_bytes())),mode='r:') as tf:
 assert set(tf.getnames())=={m['name'] for m in members}
 for m in members:assert sha(tf.extractfile(m['name']).read())==m['sha256']
for p in own:p.unlink()
assert not list(T.iterdir());T.rmdir()
receipt={'at':now,'archive':str(path.relative_to(R)),'compressed_bytes':len(compressed),'uncompressed_tar_bytes':len(raw),'archive_sha256':sha(compressed),'decompressed_tar_sha256':sha(raw),'members':members,'all_member_roundtrip_hashes_verified':True,'own_plaintext_bytes_removed':sum(m['bytes'] for m in members),'third_party_temporary_files_verified_removed':third,'third_party_temporary_bytes_removed':162810,'temporary_root_removed':not T.exists(),'new_scientific_experiment':False,'numeric_data_policy':'No new numerical data;all15 existing scientific archives verified,no uncompressed experiment data introduced','upstream_math_written':False,'github_write':False,'all_quality_jobs_terminal':True,'overall_goal':'active_incomplete'};put(O/'storage.json',receipt);print(json.dumps({k:v for k,v in receipt.items() if k not in ['members','third_party_temporary_files_verified_removed']},ensure_ascii=False))
