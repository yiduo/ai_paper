from pathlib import Path
import json,gzip,hashlib,subprocess,datetime,sys
R=Path('/Users/smzdm/projects/ai_paper');O=R/'reports/reproducibility/20261023-rational-psd';BASE='a1c355c';sha=lambda b:hashlib.sha256(b).hexdigest()
def enc(j):return (json.dumps(j,ensure_ascii=False,indent=2)+'\n').encode()
def gz(n,b):
 z=gzip.compress(b,mtime=0);assert gzip.decompress(z)==b;(O/n).write_bytes(z)
lp=R/'data/provenance/demand/F-174-rational-psd-contracts.json';raw=(R/'data/graph/nodes.jsonl').read_bytes();eraw=(R/'data/graph/edges.jsonl').read_bytes();old=subprocess.check_output(['git','show',BASE+':data/graph/nodes.jsonl'],cwd=R);olde=subprocess.check_output(['git','show',BASE+':data/graph/edges.jsonl'],cwd=R);assert raw.startswith(old) and eraw.startswith(olde)
gz('unaccepted-draft-ledger.json.gz',lp.read_bytes());gz('unaccepted-draft-new-nodes.jsonl.gz',raw[len(old):]);gz('unaccepted-draft-new-edges.jsonl.gz',eraw[len(olde):])
mapping={'LIT-174-PSD-CVXPY-QUAD_FORM':'LIT-174-PSD-CVXPY-QUAD-FORM','LIT-174-PSD-CVXPY-QUAD_FORM_CANON':'LIT-174-PSD-CVXPY-QUAD-FORM-CANON'}
def fix(x):
 if isinstance(x,str):return mapping.get(x,x)
 if isinstance(x,list):return [fix(v) for v in x]
 if isinstance(x,dict):return {k:fix(v) for k,v in x.items()}
 return x
j=fix(json.loads(lp.read_bytes()));j.update(version=2,revision_reason='Pre-acceptance validator rejected underscores in two new generated stable IDs. Replace only these IDs/references,retain exact unaccepted draft and failure log;no mathematical/caller fact or old record changed.');lp.write_bytes(enc(j));h=sha(lp.read_bytes());new=fix([json.loads(l) for l in raw[len(old):].splitlines()]);es=fix([json.loads(l) for l in eraw[len(olde):].splitlines()])
for n in new:
 n['version']=2;n['properties']['draft_revision_reason']=j['revision_reason']
 for s in n['sources']:
  if s.get('path')=='data/provenance/demand/F-174-rational-psd-contracts.json':s['sha256']=h
for e in es:e['version']=2;e['id']='E-'+sha(f"{e['source']}|{e['relation']}|{e['target']}".encode())[:16].upper()
(R/'data/graph/nodes.jsonl').write_bytes(old+b''.join((json.dumps(n,ensure_ascii=False,sort_keys=True)+'\n').encode() for n in new));(R/'data/graph/edges.jsonl').write_bytes(olde+b''.join((json.dumps(e,ensure_ascii=False,sort_keys=True)+'\n').encode() for e in es));p=R/'state/reading-progress/WP-106.json';q=fix(json.loads(p.read_bytes()));q.update(identifier_correction='Two filename-derived new stable IDs sanitized,exact unaccepted v1 archived');p.write_bytes(enc(q))
sys.path.insert(0,str(R/'src'));from ai_value.graph import validate
v=validate(R);receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_commit':BASE,'new_records':len(new),'new_explicit_edges':len(es),'all4514oldlines_and_alloldedges_exact':True,'identifier_mapping':mapping,'reason':j['revision_reason'],'new_candidates':0,'new_initial_checks':0,'selected_source_files':7,'selected_source_lines':1350,'validation':v};gz('curation.json.gz',enc(receipt));print(json.dumps(receipt))
