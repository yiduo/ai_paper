from pathlib import Path
import urllib.request,urllib.parse,json,datetime,hashlib
T=Path('/private/tmp/ai-paper-WP106');cap=2097152;used=0;requests=[];projects=[]
def get(url,name,limit=400000):
 global used
 row={'url':url,'name':name,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tls':'normal verified TLS'}
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'ai-paper bounded public source research','Accept':'application/vnd.github+json' if 'api.github.com' in url else '*/*'})
  with urllib.request.urlopen(req,timeout=30) as resp:
   body=resp.read(min(limit,cap-used)+1);row['final_url']=resp.url
  if len(body)>min(limit,cap-used):raise ValueError('bounded source/total byte cap exceeded')
  used+=len(body);(T/name).write_bytes(body);row.update(status='acquired',bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),path=str(T/name));return body
 except Exception as e:row.update(status='failed',error=str(e));return None
 finally:
  requests.append(row);save();print(name,row['status'],row.get('bytes',row.get('error')),flush=True)
def save():
 (T/'acquisition.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'download_bytes':used,'cap':cap,'project_cap':3,'projects':projects,'requests':requests},indent=2)+'\n')
for name,repo,paths in [
 ('sympy','sympy/sympy',['sympy/matrices/decompositions.py','sympy/matrices/solvers.py','LICENSE']),
 ('qiskit','Qiskit/qiskit',['qiskit/quantum_info/operators/channel/transformations.py','qiskit/quantum_info/operators/channel/kraus.py','LICENSE.txt']),
 ('cvxpy','cvxpy/cvxpy',['cvxpy/atoms/quad_form.py','cvxpy/reductions/dcp2cone/canonicalizers/quad_form_canon.py','LICENSE'])]:
 data=get('https://api.github.com/repos/'+repo+'/releases/latest',name+'-release.json',120000)
 if data is None:continue
 release=json.loads(data);tag=release['tag_name'];ref=get('https://api.github.com/repos/'+repo+'/git/ref/tags/'+urllib.parse.quote(tag,safe=''),name+'-ref.json',10000)
 if ref is None:continue
 obj=json.loads(ref)['object']
 for level in range(3):
  if obj['type']!='tag':break
  tagged=get(obj['url'],name+'-peeled-'+str(level)+'.json',15000)
  if tagged is None:break
  obj=json.loads(tagged)['object']
 if obj['type']!='commit':continue
 commit=obj['sha'];projects.append({'project':name,'repo':repo,'release_tag':tag,'release_published_at':release.get('published_at'),'commit':commit,'release_html_url':release.get('html_url'),'selected_paths':paths});save()
 for path in paths:get('https://raw.githubusercontent.com/'+repo+'/'+commit+'/'+path,name+'-'+path.rsplit('/',1)[-1])
save()
