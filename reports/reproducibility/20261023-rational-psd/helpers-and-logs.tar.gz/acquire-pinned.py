from pathlib import Path
import urllib.request,json,datetime,hashlib
T=Path('/private/tmp/ai-paper-WP106');p=T/'acquisition.json';j=json.loads(p.read_bytes());cap=j['cap'];assert len(j['projects'])==0 and j['download_bytes']==0
items=[('sympy','sympy/sympy','1.14.0','fe935ceb303891d1f8bea4c03b19fd9ec9464b02',['sympy/matrices/decompositions.py','sympy/matrices/solvers.py','LICENSE']),('qiskit','Qiskit/qiskit','2.6.0','65094a013073e4bda53c2b341056ab9ade0eb1bd',['qiskit/quantum_info/operators/channel/transformations.py','qiskit/quantum_info/operators/channel/kraus.py','LICENSE.txt']),('cvxpy','cvxpy/cvxpy','v1.9.3','fba7e1f41ca5cf0718918d47d02ba2c3614395d2',['cvxpy/atoms/quad_form.py','cvxpy/reductions/dcp2cone/canonicalizers/quad_form_canon.py','cvxpy/utilities/linalg.py','LICENSE'])]
j['metadata_fallback']='All3directGitHubreleasesAPI403ratelimit retained;official release page commit hrefs used to fix tag/commit. Qiskitcommitpagewebcachemiss retained;fullcommit comes from releasepage actuallink. No TLS bypass.'
for name,repo,tag,commit,paths in items:
 j['projects'].append({'project':name,'repo':repo,'release_tag':tag,'commit':commit,'release_html_url':'https://github.com/'+repo+'/releases/tag/'+tag,'commit_html_url':'https://github.com/'+repo+'/commit/'+commit,'commit_identity_source':'Official release page commit hyperlink observed with web tool;not repository clone or signatureverification','selected_paths':paths})
 for path in paths:
  url='https://raw.githubusercontent.com/'+repo+'/'+commit+'/'+path;n=name+'-'+path.rsplit('/',1)[-1];row={'project':name,'repo_path':path,'name':n,'url':url,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tls':'normal verified TLS'}
  try:
   with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'ai-paper bounded source research'}),timeout=30) as response:body=response.read(min(400000,cap-j['download_bytes'])+1)
   if len(body)>min(400000,cap-j['download_bytes']):raise ValueError('byte cap')
   body.decode('utf-8');(T/n).write_bytes(body);j['download_bytes']+=len(body);row.update(status='acquired',bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),path=str(T/n))
  except Exception as e:row.update(status='failed',error=str(e))
  j['requests'].append(row);p.write_text(json.dumps(j,indent=2)+'\n');print(n,row['status'],row.get('bytes',row.get('error')),flush=True)
assert j['download_bytes']<=cap and len(j['projects'])==3
