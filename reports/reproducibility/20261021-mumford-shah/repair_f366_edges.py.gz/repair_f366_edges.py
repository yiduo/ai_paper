from pathlib import Path
import json,gzip,hashlib,datetime
r=Path('/Users/smzdm/projects/ai_paper');sha=lambda b:hashlib.sha256(b).hexdigest();now=datetime.datetime.now(datetime.timezone.utc).isoformat();G='GEN-20261021-039'
es=[json.loads(l)for l in(r/'data/graph/edges.jsonl').read_text().splitlines()];old=[]
for e in es:
 if e['relation']=='cites':
  assert e['source'].startswith('CLM-366-');old.append(dict(e));e['relation']='depends_on';e['id']='E-'+sha(f"{e['source']}|depends_on|{e['target']}".encode())[:16].upper();e['version']+=1;e['source_locator']+=';Explicit proof input dependency;canonical cites edges are generated solely from node source annotations'
assert len(old)==3
arc=r/'data/graph/history/GEN-20261021-039-explicit-citation-edges-before.json.gz';arc.write_bytes(gzip.compress((json.dumps(dict(generation_id=G,retired_edges=old,reason='Explicit theorem literature dependencies misused reserved projected-citation relation;replaced with depends_on. Source citations and validator unchanged.'),ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
ns={n['id']:n for n in map(json.loads,(r/'data/graph/nodes.jsonl').read_text().splitlines())};refs=ns['ANALYSIS-F-366']['properties']['historical_references_by_key']
def edge(a,rel,b,loc):
 id='E-'+sha(f'{a}|{rel}|{b}'.encode())[:16].upper();assert not any(e['id']==id for e in es)
 es.append(dict(id=id,source=a,relation=rel,target=b,source_locator=loc,source_commit='1581d4cbdd69a0faf34b2089614fe2a814316a6a',created_at=now,version=1,evidence_status='source_claim'))
for k,id in refs.items():edge('P-47de73ec1cf82726','historical_context',id,'Actually read bibliography '+k+';original body status is explicit on target,not complete lineage')
edge(refs['delellis_focardi_ghinassi_erratum'],'corrects',refs['delellis_focardi_ghinassi2021'],'Original correction whole3pages read;underlying full journal article not read here')
(r/'data/graph/edges.jsonl').write_text(''.join(json.dumps(e,ensure_ascii=False,sort_keys=True)+'\n'for e in es))
out=r/'reports/reproducibility/20261021-mumford-shah';(out/'core-check.log').rename(out/'core-check-second-reserved-cites.log');(out/'edge-repair.json').write_text(json.dumps(dict(retired_edges_preserved=3,explicit_dependencies=3,historical_context_edges=22,correction_edge=1,validator_changed=False,application_or_grade_promotions=0),indent=2)+'\n');print({'proof_input_dependencies_repaired':3,'history_edges_added':23})
