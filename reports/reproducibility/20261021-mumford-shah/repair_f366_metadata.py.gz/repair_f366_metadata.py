from pathlib import Path
import json,gzip,hashlib,copy,datetime,subprocess
r=Path('/Users/smzdm/projects/ai_paper');sha=lambda b:hashlib.sha256(b).hexdigest();now=datetime.datetime.now(datetime.timezone.utc).isoformat();G='GEN-20261021-039';arc='data/graph/history/GEN-20261021-039-metadata-before.json.gz';old=[]
ledger='data/provenance/readings/F-366.json';p=r/ledger;raw=p.read_bytes();a=r/'data/provenance/readings/history/F-366-before-metadata-repair.json.gz';a.parent.mkdir(parents=True,exist_ok=True);a.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(a.read_bytes())==raw
j=json.loads(raw);j['formal_files_actually_read'][0]['scope']='Whole156line model read';j['version']=2;j['prior_ledger_archive']=str(a.relative_to(r));j['metadata_repair']='ActualModelwc156,not155;source content/grades unchanged. Initial18bibliography nodes used unsupported evidence enum;normalized to existing source_claim while retaining explicit original-unread status.';p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n');newsha=sha(p.read_bytes())
ns=[json.loads(l)for l in(r/'data/graph/nodes.jsonl').read_text().splitlines()]
for n in ns:
 changed=n['evidence_status']=='source_metadata_only' or any(s.get('path')==ledger for s in n['sources'])
 if not changed:continue
 old.append(copy.deepcopy(n));n.update(version=n['version']+1,updated_at=now,prior_version_archive=arc,updated_by_generation_id=G)
 if n['evidence_status']=='source_metadata_only':n['evidence_status']='source_claim'
 for s in n['sources']:
  if s.get('path')==ledger:s['sha256']=newsha;s['locator']+=';v2 metadata-only repair,source readscope and grades unchanged'
assert len(old)==21
(r/arc).write_bytes(gzip.compress((json.dumps(dict(generation_id=G,records=old),ensure_ascii=False,indent=2)+'\n').encode(),mtime=0));(r/'data/graph/nodes.jsonl').write_text(''.join(json.dumps(n,ensure_ascii=False,sort_keys=True)+'\n'for n in ns))
coverage=subprocess.check_output(['git','show','HEAD:data/graph/reading_coverage.json'],cwd=r);a=r/'data/graph/history/GEN-20261021-039-reading-coverage-before.json.gz';a.write_bytes(gzip.compress(coverage,mtime=0));assert gzip.decompress(a.read_bytes())==coverage
out=r/'reports/reproducibility/20261021-mumford-shah';p=out/'core-check.log';p.rename(out/'core-check-initial-invalid-evidence.log');(out/'metadata-repair.json').write_text(json.dumps(dict(old_nodes_preserved=len(old),unsupported_evidence_enum_repaired=18,Model_source_lines=156,grades_promoted=0,old_ledger_preserved=True,prior_coverage_preserved=True),indent=2)+'\n');print({'metadata_repair':True,'prior_nodes':len(old)})
