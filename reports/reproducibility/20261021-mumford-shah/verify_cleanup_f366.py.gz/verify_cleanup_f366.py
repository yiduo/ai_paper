from pathlib import Path
import json,gzip,hashlib,datetime
r=Path('/Users/smzdm/projects/ai_paper');sha=lambda b:hashlib.sha256(b).hexdigest();out=r/'reports/reproducibility/20261021-mumford-shah';j=json.loads((r/'data/provenance/readings/F-366.json').read_text());t=Path('/private/tmp/ai-paper-F366')
for v in j['selected_original_scopes'].values():
 p=t/v['file'];assert sha(p.read_bytes())==v['pdf_sha256'];assert sha(p.with_suffix('.txt').read_bytes())==v['extracted_text_sha256']
assert sha((t/'book-weakL4.png').read_bytes())==j['historical_caveat']['pixel_sha256']
for v in j['read_files']:assert sha((r/v['path']).read_bytes())==v['sha256']
ip=r/j['formal_index_only']['path'];ix=json.loads(gzip.decompress(ip.read_bytes()))
for v in ix['local_files']:assert sha((r/v['path']).read_bytes())==v['sha256']
removed=[]
for p in t.iterdir():
 assert p.is_file() and p.suffix in ['.pdf','.txt','.png'];removed.append(dict(path=str(p),sha256=sha(p.read_bytes()),bytes=p.stat().st_size));p.unlink()
t.rmdir()
receipt=dict(recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),natural_file_hashes=len(j['read_files']),formal_index_source_hashes=len(ix['local_files']),formal_index_gzip_sha256=sha(ip.read_bytes()),formal_index_decompressed_sha256=sha(gzip.decompress(ip.read_bytes())),temporary_files_removed=removed,removed_bytes=sum(v['bytes']for v in removed),new_numerical_application_run=False,book_not_redistributed=True,local_Lean_or_Comparator=False)
(out/'source-and-cleanup-integrity.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');print({'natural_files':len(j['read_files']),'index_files':len(ix['local_files']),'removed_bytes':receipt['removed_bytes']})
