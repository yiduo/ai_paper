"""Preserve and qualify one pre-existing intro-only dependency after whole proof reading."""
import datetime,gzip,json
from pathlib import Path
R=Path('/Users/smzdm/projects/ai_paper');p=R/'data/graph/edges.jsonl';es=[json.loads(l) for l in p.read_text().splitlines()];e=next(e for e in es if e['id']=='E-1807B019A8E275D8');assert e['relation']=='depends_on' and e['version']==1
raw=(json.dumps({'edges':[e]},ensure_ascii=False,indent=2)+'\n').encode();z=gzip.compress(raw,mtime=0);assert gzip.decompress(z)==raw;archive='data/graph/history/GEN088-dependency-before.json.gz';(R/archive).write_bytes(z)
e.update(relation='historical_context',version=2,updated_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),evidence_status='source_content_checked',prior_version_archive=archive,updated_by_generation_id='GEN-20261022-088',source_locator='Matrix introduction lines52-98 and all included proof sections read: all action/trace/path/spectral steps proved in matrix manuscript;scalar companion cited for method and scalar specialization. Reclassify intro-only theorem dependency as historical method context;stable edge ID retained for version continuity.')
p.write_text(''.join(json.dumps(e,ensure_ascii=False,sort_keys=True)+'\n' for e in es))
p=R/'reports/reproducibility/20261022-lieb-thirring/curation.json';j=json.loads(p.read_text());j.update(old_edges_exact=False,old_edges_exact_except=['E-1807B019A8E275D8'],old_edge_prior_archive=archive,reason='Whole proof reading corrects initial intro-only dependency;both source mathematical claims/grades unchanged');p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
print('One old edge versioned to historical_context;original exact prior preserved')
