"""Bounded WP092 audit; no scientific experiment replay or upstream clone."""
import datetime,gzip,hashlib,json,os,shutil,subprocess,sys,tempfile
from pathlib import Path
R=Path('/Users/smzdm/projects/ai_paper');sys.path.insert(0,str(R/'src'))
from ai_value.graph import load,impact_report,validate
out=R/'reports/reproducibility/20261022-lieb-thirring';out.mkdir(parents=True,exist_ok=True)
def pack(name,j):
 b=(json.dumps(j,ensure_ascii=False,indent=2)+'\n').encode();z=gzip.compress(b,mtime=0);assert gzip.decompress(z)==b;(out/(name+'.json.gz')).write_bytes(z)
nodes,edges=load(R);checked=[]
cases=[('CLM-262-S-LEM-AVERAGE',['CLM-262-SCALAR'],['CLM-262-MATRIX','CLM-262-E-THM-MAIN']),('CLM-262-M-THM-TRACE',['CLM-262-MATRIX'],['CLM-262-SCALAR']),('CLM-262-E-TRACE-DEFICIT',['CLM-262-E-THM-MAIN'],['CLM-262-MATRIX']),('CLM-262-E-PRE-YOUNG',['CLM-262-E-COMP-RELATIONS','CLM-262-E-THM-MAIN'],['CLM-262-SCALAR']),('CLM-262-E-RIG-FIXED-RIGHT-SPACES',['CLM-262-E-RIG-FIXED-LEFT-SPACES','CLM-262-E-THM-MAIN'],['CLM-262-MATRIX']),('CHECK-262-CONTINUUM',['ANALYSIS-F-262'],['CLM-262-SCALAR','APP-113-01']),('P-a1aa8e17be727f9b',['CLM-262-SCALAR'],['CLM-262-MATRIX']),('LIT-262-READSCHULZ2026',[],['CLM-262-SCALAR','CLM-262-MATRIX'])]
for change,yes,no in cases:
 result=impact_report(nodes,edges,{change});assert set(yes)<=set(result['affected']);assert not set(no)&set(result['affected']);checked.append({'changed':change,'expected_affected':yes,'expected_unaffected':no,'actual':result})
pack('impact',{'cases':checked,'meaning':'Dependency routing only;proof self-contained appendices and historical_context do not imply theorem refutation;unaffected not verified'})
archives=[]
for p in sorted((R/'experiments/runs').glob('*/manifest.json')):
 j=json.loads(p.read_text());folder=p.parent
 for name,want in j['outputs'].items():assert hashlib.sha256((folder/name).read_bytes()).hexdigest()==want
 for name,meta in j.get('compressed_payloads',{}).items():assert hashlib.sha256(gzip.decompress((folder/name).read_bytes())).hexdigest()==meta['uncompressed_sha256']
 snap=json.loads(gzip.decompress((folder/j['source_snapshot']).read_bytes()))
 for name,text in snap.items():assert hashlib.sha256(text.encode()).hexdigest()==j['inputs'][name]
 archives.append({'run_id':j['run_id'],'compressed_outputs_and_uncompressed_hashes':True,'source_members':len(snap),'actual_replayed':False})
pack('archives',{'archives':archives,'count':len(archives),'new_replays':[],'reason':'No experiment source/spec/data or comparators changed. Prior WP089 actual EXP200/332 replays retained;do not rerun frozen adverse grids for code fingerprints.'})
annotations=[s for n in nodes.values() if n['id'].startswith(('GEN-','CLM-','PART-','LIT-','CHECK-','XPL-','ANALYSIS-','APP-','PROB-')) for s in n.get('sources',[])]
# Every canonical row, including retained software/tool kinds, gets its own byte audit.
canon=[json.loads(x) for x in (R/'data/graph/nodes.jsonl').read_text().splitlines()];local=external=0
for n in canon:
 for s in n['sources']:
  if 'path' in s:assert hashlib.sha256((R/s['path']).read_bytes()).hexdigest()==s['sha256'];local+=1
  else:external+=1
old=[json.loads(x) for x in subprocess.check_output(['git','show','e6e2ee2:data/graph/nodes.jsonl'],cwd=R,text=True).splitlines()];lookup={n['id']:n for n in canon};revised={'CLM-262-SCALAR','CLM-262-MATRIX'}
for n in old:
 if n['id'] not in revised:assert lookup[n['id']]==n
prior=json.loads(gzip.decompress((R/'data/graph/history/GEN088-F262-before.json.gz').read_bytes()))['records'];assert prior==[n for n in old if n['id'] in revised]
oldedges=[json.loads(x) for x in subprocess.check_output(['git','show','e6e2ee2:data/graph/edges.jsonl'],cwd=R,text=True).splitlines()];nowedges=[json.loads(x) for x in (R/'data/graph/edges.jsonl').read_text().splitlines()];changed='E-1807B019A8E275D8'
assert [e for e in nowedges[:len(oldedges)] if e['id']!=changed]==[e for e in oldedges if e['id']!=changed]
assert json.loads(gzip.decompress((R/'data/graph/history/GEN088-dependency-before.json.gz').read_bytes()))['edges']==[e for e in oldedges if e['id']==changed]
assert next(e for e in nowedges if e['id']==changed)['relation']=='historical_context'
pack('canonical-and-sources',{'canonical_nodes':len(canon),'new_canonical_nodes':len(canon)-len(old),'old_nodes_exact':len(old)-2,'two_exact_prior_records':True,'old_edges_exact_except':[changed],'exact_old_edge_archive':True,'new_edges':len(nowedges)-len(oldedges),'local_source_hashes':local,'external_annotations_without_retained_bytes':external,'all_canonical_annotations':local+external,'validation':validate(R)})
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(R/'src'))
for command in ['export-graph','organize-graph']:
 p=subprocess.run([sys.executable,'-m','ai_value.cli',command],cwd=R,env=env,text=True,capture_output=True);(Path(__file__).parent/(command+'.log')).write_text(p.stdout+p.stderr);assert p.returncode==0,p.stderr
paths=subprocess.check_output(['git','ls-files','-c','-o','--exclude-standard','-z'],cwd=R).split(b'\0');paths=sorted(set(x.decode() for x in paths if x));paths=[x for x in paths if x.split('/')[0] not in {'math','.git','.venv','.cache'} and '__pycache__' not in x.split('/')]
with tempfile.TemporaryDirectory(prefix='ai-paper-no-math-') as tmp:
 c=Path(tmp);total=0;count=0
 for name in paths:
  p=R/name
  if not p.is_file():continue
  assert not p.is_symlink(),name;q=c/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q);total+=p.stat().st_size;count+=1
 assert not (c/'math').exists();e=dict(env,PYTHONPATH=str(c/'src'));p=subprocess.run([sys.executable,'scripts/check.py'],cwd=c,env=e,text=True,capture_output=True,timeout=180)
 (Path(__file__).parent/'clean-core-check.log').write_text(p.stdout+p.stderr)
 pack('no-math-clean-directory',{'files':count,'bytes_copied':total,'math_present':False,'exit_code':p.returncode,'new_install':False,'cleaned_on_exit':True,'scope':'Entire existing68core/validate/report/provenance workflow;not scientific or Lean build'});assert p.returncode==0,p.stderr[-1000:]
print(json.dumps({'canonical_nodes':len(canon),'impact_cases':len(cases),'archives':len(archives),'new_replays':0,'no_math_clean_exit':0,'all_canonical_annotations':local+external},indent=2))
