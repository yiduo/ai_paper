"""WP092 source curation. Run once on the recorded e6e2ee2 base, not a replay script."""
import copy, datetime, gzip, hashlib, json, re, subprocess, sys
from pathlib import Path
ROOT=Path('/Users/smzdm/projects/ai_paper'); TMP=Path(__file__).parent
sys.path.insert(0,str(ROOT/'src'))
from ai_value.source_results import named_results
G='GEN-20261022-088'; UP='1581d4cbdd69a0faf34b2089614fe2a814316a6a'
NOW=datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256((ROOT/p).read_bytes()).hexdigest()
def dump(p,v):
 p=ROOT/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def pack(p,v):
 b=(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode();z=gzip.compress(b,mtime=0);assert gzip.decompress(z)==b;(ROOT/p).parent.mkdir(parents=True,exist_ok=True);(ROOT/p).write_bytes(z)
def src(p,l):return {'path':p,'sha256':sha(p),'commit':UP if p.startswith('math/') else None,'locator':l}
j=json.loads((ROOT/'state/reading-progress/F-262.json').read_text());assert all(f['fully_read'] for f in j['files'])
ms=[json.loads(l) for l in (ROOT/'data/corpus/manuscripts.jsonl').read_text().splitlines()];ms=[m for m in ms if m['family_id']=='F-262']
tag={'P-a1aa8e17be727f9b':'S','P-f667c4cb31984c1b':'M','P-5bf2f618b4e7fd26':'E'}
folders={tag[m['id']]:'math/'+str(Path(m['path']).parent) for m in ms}
owners={t:next(m['id'] for m in ms if tag[m['id']]==t) for t in folders}
common='0<sigma=gamma-1/2<1; p=1+sigma, q=1+1/sigma, r=1/sigma. Entire real-line continuum, finite channel dimension, ordinary unnormalized matrix trace; not a finite-grid matrix estimate.'
scope={
'S::thm:main':('Scalar sharp full moment','All negative eigenvalues with multiplicities satisfy Tr(H_-^gamma)<=C_gamma integral W^p; optimal one-state constant, attained by (r+1)sech^2(rx).','W>=0 measurable in L^p(R), including rough/unbounded W and potentially infinitely many negative eigenvalues. Attainment does not classify all optimizers.'),
'S::thm:action':('Scalar-family action','Supremum of E_K(Cu) over real lower triangular C is at least sum integral[-ki,ki](ki^2-s^2)^sigma ds.','Bounded interval, u in H1_0 with integral uu^T=I, ki>0; C need not be invertible. Auxiliary matrix size counts orthonormal functions.'),
'S::path:existence':('Two-endpoint path','Some lower triangular C and C1 symmetric B connect K to -K with epsilon Bprime=M(B)-(Cu)(Cu)^T and opnorm B<=opnorm K.','Field local Lipschitz, sign equivariance, increasing scalar coordinate and directional bounds; fixed field,K,interval gives bounded C uniformly epsilon<=1. No uniform Bprime or delta bound or efficient constructor.'),
'S::path:parity':('Relative odd-zero continuation','A continuous homotopy of rank-d bundle sections over smooth d-manifold with compact total zero set retains a zero at the final endpoint.','Initial section smooth with odd finite transverse zeros; no orientation needed. Quotient applied only on free sign locus, not all triangular matrices.'),
'S::lem:HS-calculus':('HS functional calculus','Scalar L-Lipschitz h yields ||h(A)-h(B)||HS<=L||A-B||HS.','Hermitian finite matrices with spectra in the scalar interval; not a dimension-independent operator-norm Lipschitz assertion.'),
'S::lem:field-regularity':('Symmetric-cutoff field primitive','The field integral converges locally uniformly, is locally Lipschitz, and J=-integral_0^1 tr(B M(tB))dt is C1 with dJ=-tr(M dB).','Fixed delta>0 and diagonal positive K; cancellation of leading odd s tail is essential; HS remainder O(|s|^(2beta-2)).'),
'S::lem:mu':('Scalar regularization and shift','mu is locally Lipschitz and strictly increasing, mu(0)=0, mu(z)=(z+delta)^sigma-delta^sigma for z>=0; fixed translations retain the symmetric-cutoff integral.','Negative z uses tangent extension; individual nonintegrable terms cannot be translated separately without paired-tail cancellation.'),
'S::lem:jensen':('Directional field comparison','e^T M(B)e<=mu(e^TK^2e-(e^TBe)^2); coordinate eigenvectors give exact mu; J(-K)-J(K) is the sum of scalar mu integrals.','Real symmetric B, real unit e; scalar concavity in a spectral basis, not global operator concavity on the extended real line.'),
'S::prop:rankone':('Rank-one coercivity','M(B)=aa^T implies a^T(K^2-B^2)a>=|a|^(2q).','D=K^2-B^2 may be indefinite; positivity of the full quadratic symbol follows from M>=0, not assumed D>=0.'),
'S::lem:resolvent-tangent':('Positive-argument tangent','Resolvent representation of f gives f(X)<=f(Y)+T_Y(X-Y), with divided-difference Schur derivative including repeated eigenvalues.','X,Y>=0 Hermitian; regularization delta>0, -1/2<beta<1/2. Not an operator tangent claim on negative arguments.'),
'S::lem:average':('Random unitary tangent average','Integrated tangent map has kernel integral_0^1(1+tau(1-tau)(zi-zj)^2/(d+delta))^(sigma-1)dt and is an even probability average of conjugations exp(itB).','d>0 chosen from rank-one mass, delta>0; map is unital and self-adjoint for trace pairing. Positivity of kernel proved by Gaussian mixtures.'),
'S::lem:trace-average':('Trace contraction along averaging','tr(M(B)D)>=tr(M(B)P(D)).','B,D,P are the specific rank-one construction; obtained by trace Klein monotonicity. Does not assert D>=P(D) as matrices.'),
'S::spectral:forms':('Rough-potential form and discreteness','The H1 form is closed and lower bounded; negative projections below -alpha have finite rank; bounded-interval Dirichlet form has compact resolvent.','p>1, W>=0 in L^p; compact multiplication follows by bounded compact-support approximation and Sobolev control.'),
'S::spectral:dirichlet':('Dirichlet finite-family bound','First N negative Dirichlet eigenvalues obey sum k_j^(2gamma)<=C_gamma integral_I W^p.','Bounded interval, ordered k1>=...>=kN>0; triangular C preserves the nested energy bound. This is not a finite-grid discretization certificate.'),
'S::spectral:signed':('Signed form extension','For signed V the natural weighted form is closed/lower bounded, has discrete negative spectrum and Tr(HV)_-^gamma<=C_gamma integral V_-^p.','V_- in L^p and D_V={v in H1:integral V_+|v|^2<infty} dense in L2, e.g. V_+ locally integrable; cannot omit domain hypothesis.'),
'M::thm:main':('Finite-channel sharp moment','All negative spectral moments obey C_gamma integral tr W^p with scalar sharp constant independently of finite m, attained by one nonzero soliton channel.','Measurable Hermitian PSD W, integrable tr W^p; arbitrary rank and noncommuting W(x); not infinite-channel assertion or optimizer classification.'),
'M::thm:action':('Rectangular action','For U in H1_0(R^(n by d)), integral UU^T=I_n, supremum E_K(CU)>=b_sigma sum ki^(2gamma).','Arbitrary finite n,d; lower triangular C and ordinary trace powers. Does not assume rank-one AA^T.'),
'M::lem:field-regularity':('Matrix field primitive','Symmetric-cutoff M_delta exists locally uniformly and is locally Lipschitz; its negative field has a C1 primitive.','Fixed delta,K; odd-tail subtraction and HS calculus, not an operator-norm functional-calculus shortcut.'),
'M::lem:field-properties':('Boundary and sign symmetries','mu_delta(z)=(z+delta)^sigma-delta^sigma for z>=0; directional/coordinate comparison, sign equivariance and scalar endpoint primitive limit hold.','B real symmetric, K fixed diagonal positive; shift requires symmetric-cutoff cancellation, not all-basis equivariance.'),
'M::prop:field-comparison':('Positive-field trace comparison','M_delta(B)>=0 implies Q_s>=0, M<=kappa^(2sigma)I and tr(M(K^2-B^2))>=tr M^q-E_delta.','V=K^2-B^2+delta I may be indefinite; N=M+delta^sigma I. E_delta=n(delta kappa^(2sigma)+delta^sigma(kappa^2+delta)); fixed n,K before delta->0.'),
'M::prop:paths':('Rectangular connecting path','epsilon Bprime=M_delta(B)-(CU)(CU)^T connects K,-K, opnorm<=kappa; C bounded uniformly epsilon<=1.','Row-orthonormal U on bounded interval; sign quotient free where every row nonzero, not requiring invertible C; fixed delta bound, no efficient algorithm.'),
'M::lem:form-compactness':('Matrix form compactness','Whole-line H1 form closes and has discrete negative spectrum; compactly supported smooth functions form a core and negative eigenfunctions belong to H1.','Finite real or complex channel m, W Hermitian PSD, integral tr W^p<infty; all eigenvalue multiplicities counted.'),
'M::thm:trace':('Integrated matrix trace comparison','With R=pi^-1 integral(X_s+tI)^-1ds, N=c_sigma integral t^beta(t^-1/2 I-R)dt>=0, tr(NV)>=tr N^q; exact nonnegative two-term deficit is derived.','Hermitian B,V with full symbol X_s=(sI-B)^2+V>=bI for all real s, b>0; V need not be PSD. Norm-convergent integrals.'),
'M::lem:trace-half-lines':('Half-line resolvent recovery','Hermitian boundary maps S,T yield L=(S+T)/2=R^-1>0, Z=(S-T)/2 and V+tI=L^2+Z^2+i[B,Z], LZ+ZL+i[B,L]=0.','Same coercive full symbol, t>0; S,T individually need not be positive. Fourier derivative jump fixes factor one-half; tr(R(V+tI))=tr L-tr(RZ^2).'),
'E::thm:main':('All finite-matrix equality cases','Equality iff a single constant unitary diagonalizes W a.e. into k<=m independent profiles (r+1)a_j^2 sech^2(r a_j(x-x_j)) and zero channels.','Strict 1/2<gamma<3/2; finite complex Hermitian PSD potential with integrable trace power. Repeated scales/profiles allowed; each active channel exactly one eigenvalue -a_j^2. No endpoint3/2 or near-equality rate.'),
'E::act:quantitative-action':('Capped quantitative action','For every eta>0 some C,B make E_K(CU)>=b_sigma sum ell_i^(2gamma)+integral(||Aprime-BA||HS^2+c_*Phi)-eta.','Phi=min(1,||[B,K^2]||op^2+||K^2-B^2-(AA^T)^r||op^2); c_*(sigma,kappa)>0 independent n,d,smallest ell; not a global distance-to-soliton bound.'),
'E::act:constraint':('Uniform constrained defect','Under M_delta(B)=AA^T, the action defect plus c_*Phi is bounded by E_n,delta tending to zero for fixed n,K.','E_n,delta=n(delta kappa^(2sigma)+delta^sigma(kappa^2+delta))+delta^(2sigma); exact trace deficit on t in [1,2] controls commutator and power mismatch; c_* dimension independent but regularization error is not.'),
'E::field:properties':('Equality field foundation','Regularized field has local HS regularity, C1 primitive, scalar mu, directional inequality, coordinate identity, sign equivariance and sharp endpoint limit.','delta>0,K positive diagonal; scalar tangent extension and symmetric cutoff needed; not global operator concavity.'),
'E::field:positive':('Positive field identifies trace input','M_delta(B)>=0 forces Q_s>=0 and 0<=M<=kappa^(2sigma)I; with V=K^2-B^2+delta I, N=M+delta^sigma I.','Full symbol >=delta I even if V indefinite. Fubini justified by t^beta(1+t+s^2)^-2 resolvent majorant.'),
'E::path:connecting':('Equality connecting path foundation','For rectangular row-orthonormal U, lower C and C1 B solve epsilon Bprime=M_delta(B)-AA^T with endpoints K,-K and opnorm<=kappa.','Fixed delta,K,interval; C uniform epsilon<=1. Smooth equivariant approximation/Sard and free sign quotient of compact 1-manifold, not a numerical solver.'),
'E::trace:deficit':('Exact noncommutative deficit','tr(NV)-tr(N^q)=c_sigma integral t^beta[tr(RZ^2)+q||R^-1/2-R^1/2(tI+N^r)^1/2||HS^2]dt.','Full symbol>=bI, N>=0; R>0,L=R^-1,Z Hermitian. No commutation required for HS square. Commuting B,V gives V>=bI and zero deficit.'),
'E::comp:relations':('Infinite-family equality compactness','At nonzero real equality obtain H1 rows a_i within each equal-energy eigenspace and pointwise bounded self-adjoint B commuting with Lambda^2, Lambda^2-B^2=(AA^T)^r, Aprime=BA, W=q(A^TA)^r.','Negative eigenlist may initially be infinite; common spectral shifts preserve gaps, fixed physical rank m gives tail HS bound m(s_h+e)^(1/r). Pointwise B subsequences may depend on x; no measurable B asserted.'),
'E::pre:spectral':('Equality spectral setup','Finite-channel rough PSD form is closed/semibounded with smooth core and discrete finite-multiplicity negative spectrum, eigenfunctions in H1 satisfying distributional ODE.','p>1, integral tr W^p<infty, no finite negative-spectrum assumption made in advance.'),
'E::pre:young':('Trace Young equality','D_sigma tr W^p-tr(WZ)+tr Z^q>=0 with equality iff W=q Z^r; coercivity >=1/2 tr Z^q-(2^(p-1)-1)D_sigma tr W^p.','W,Z finite Hermitian PSD; diagonal convexity establishes equality including zero coordinates; simultaneous basis is a conclusion at equality, not an assumption.'),
'E::rig:fixed-right-spaces':('Fixed physical channel spaces','ker G_alpha(x) and right row space are constant; different energy right spaces orthogonal and sum of dimensions<=m, so finitely many nonzero blocks.','Use ||(G_alpha v)prime||<=kappa||G_alpha v|| a.e. and two-sided Gronwall; continuous H1 representatives. Does not assume all initial rows nonzero or choose measurable B.'),
'E::rig:fixed-left-spaces':('Fixed row spaces and Riccati rigidity','For each active block, range G_alpha(x) is constant; in fixed bases invertible D gives symmetric B0=Dprime D^-1 and B0prime=r(B0^2-alpha^2 I).','Distributional ODE upgrades active blocks to C2. Strict alpha^2 I-B0^2>0 selects negative tanh branches in one constant basis; yields independent centres/scales.'),
'E::bound:sharp':('Equality sharp bound derivation','Same full finite-matrix spectral moment bound follows from quantitative action, Young and exhaustion.','Finite eigenfamily uses common shift xi<k_n^2 and smooth compact approximants; then eta->0,xi->0,full spectral exhaustion. Complex realification doubles both ordinary traces and divides by two.')}
rows=[];byfile={};closure={}
for t,folder in folders.items():
 base=ROOT/folder/'build'; todo=[base/'main.tex'];seen=set(); assets=[]
 while todo:
  p=todo.pop()
  if p in seen:continue
  assert p.exists(),str(p);seen.add(p);text=p.read_text()
  for x in re.findall(r'\\(?:input|include)\{([^}]+)\}',text):todo.append(base/(x if x.endswith('.tex') else x+'.tex'))
  for x in re.findall(r'\\includegraphics(?:\[[^\]]*\])?\{([^}]+)\}',text):
   choices=[base/x]+[base/(x+ext) for ext in ['.pdf','.png']];choices=[p for p in choices if p.is_file()];assets.extend(str(p.relative_to(ROOT)) for p in choices)
 inventory={ROOT/f['path'] for f in j['files'] if f['path'].startswith(folder+'/') and f['path'].endswith('.tex')};assert inventory==seen,(t,inventory-seen,seen-inventory)
 closure[t]={'included_tex_files':sorted(str(p.relative_to(ROOT)) for p in seen),'all_included_tex_read':True,'figure_assets':sorted(set(assets))}
 for p in sorted(seen):
  file=str(p.relative_to(ROOT));byfile[file]={};text=p.read_text()
  for r in named_results(text):
   key=t+'::'+r['label'];assert key in scope,key
   title,statement,condition=scope[key];ident='CLM-262-'+t+'-'+re.sub('[^A-Z0-9]+','-',r['label'].upper()).strip('-')
   if key=='S::thm:main':ident='CLM-262-SCALAR'
   if key=='M::thm:main':ident='CLM-262-MATRIX'
   rows.append({'id':ident,'qualified_label':key,'label':r['label'],'aliases':r['label_aliases'],'title':title,'statement':statement,'conditions':condition,'constants':common+' '+condition,'file':file,'lines':[text[:r['start']].count('\n')+1,text[:r['statement_end']].count('\n')+1],'manuscript_id':owners[t],'grade':'B' if key=='S::thm:main' else 'C'})
   byfile[file][r['label']]=ident
assert len(rows)==len(scope)==37
bykey={r['qualified_label']:r['id'] for r in rows}
formalpaths=['math/lean/docs/262.md','math/lean/ComparatorChallenges/LiebThirring.json','math/lean/ComparatorChallenges/LiebThirring.lean']+['math/lean/OAI/Analysis/LiebThirring/'+x+'.lean' for x in ['Model','Main','MomentBound','SpectralMain']]
formalread={p:{'sha256':sha(p),'lines':len((ROOT/p).read_text().splitlines()),'read_scope':'Entire selected body read;no local build or transitive proof audit'} for p in formalpaths}
model=(ROOT/formalpaths[3]).read_text();challenge=(ROOT/formalpaths[2]).read_text();assert model[model.index('structure H1'):model.index('end SharpLiebThirring')].strip()==challenge[challenge.index('structure H1'):challenge.index('/-- Full sharp Lieb')].strip()
indices=[];union={}
for file in ['data/graph/lean_indices/F-262-scalar.json.gz','data/graph/lean_indices/F-262-spectral.json.gz']:
 z=(ROOT/file).read_bytes();raw=gzip.decompress(z);idx=json.loads(raw);assert gzip.decompress(gzip.compress(raw,mtime=0))==raw
 for f in idx['local_files']:assert sha(f['path'])==f['sha256'];union[f['path']]=f
 indices.append({'path':file,'sha256':sha(file),'uncompressed_sha256':hashlib.sha256(raw).hexdigest(),'files':len(idx['local_files']),'declarations':sum(len(f['declarations']) for f in idx['local_files']),'external_unread':idx['external_modules_not_present'],'no_build':True})
formal={'selected_read_files':formalread,'indices':indices,'unique_static_files':len(union),'unique_static_declarations':sum(len(f['declarations']) for f in union.values()),'build':False,'Comparator':False,'human_review':None,'full_dependency_grade':'unknown','main_claim_definition_exact_selected_comparison':True,'scope':'Scalar full-moment/optimal constant/explicit attainment only. Supporting spectral operator bridge selected actual code read;not a separately registered matrix or equality-classification proof. No local proof closure/elaboration audit.'}
acq=json.loads((TMP/'acquisitions.json').read_text())
history=[
 {'key':'ReadSchulz2026','acquisition':'ReadSchulz2026v2','locator':'arXiv2609.10478v2 PDF1-4 Theorems1/2 and cumulative-mass setup;PDF7-8 Proposition4/operator eq2.1/lifting proof','fact':'Exponent1 sharp scalar and operator-valued bound already precedes all3 manuscripts;constant4/(3sqrt(3)pi),higher-dimensional ratio2/sqrt(3).','boundary':'Selected source scopes,not all 18 proof pages audited. No new gamma1 numerical benefit credited.'},
 {'key':'HLW2000','acquisition':'HLW1999v1','locator':'arXivmath-ph/9906013v1 PDF4 Theorem3.1;PDF8-11 Corollary3.5/Theorem4.1 and dimension-lifting proof','fact':'Old operator-valued endpoint1/2 constant1/2 and full moment upper2Lcl in 1D;higher-dimensional lifting requires operator-valued fibre hypotheses.','boundary':'1999v1 selected interfaces/proof,not identity with final2000 journal. Coarse2Lcl is a valid baseline but not automatically strongest recent bound.'},
 {'key':'LaptevWeidl2000','acquisition':'LaptevWeidl1999v2','locator':'arXivmath-ph/9903007v2 PDF18-20 Theorem2.2/Theorem3.1 and lifting proof','fact':'Semiclassical sharp constant for gamma>=3/2 with operator-valued potentials;dimension lift passes through compact operators on separable Hilbert fibres.','boundary':'Finite channel F262 alone needs separately justified operator-limit extension for this lifting route. No new general higher-dimensional sharpness inferred.'},
 {'key':'FrankGontierLewin2025','acquisition':'FGL2023v2','locator':'arXiv2109.05984v2 PDF9-10 eq20-24/Theorem5;PDF35-36 Section7 Lemma25 and maximizing-sequence proof','fact':'At endpointgamma3/2 scalar finite-rank maximizers include KdV multisolitons and arbitrary numbers of bound states.','boundary':'2023v2 actual original bytes,not separately checked final2025journal;strict interval F262 fixed-basis one-state classification cannot be extended to endpoint. Inverse-scattering dependencies not audited.'}]
# Bibliography bindings preserve manuscript-specific keys, merge only identified same works.
bindings={};works={};internal={'ScalarCompanion':owners['S'],'MLT':owners['M']}
for t,folder in folders.items():
 p=folder+'/build/references'+('.bib' if t=='S' else '.tex');text=(ROOT/p).read_text()
 pat=r'@\w+\{([^,]+),' if t=='S' else r'\\bibitem\{([^}]+)\}'
 hits=list(re.finditer(pat,text))
 for i,m in enumerate(hits):
  k=m[1];entry=text[m.start():hits[i+1].start() if i+1<len(hits) else len(text)].strip();key=t+'::'+k
  normalized='HLT1998' if k=='HundertmarkLiebThomas1998' else k
  ident=internal.get(k,'LIT-262-'+normalized.upper());bindings[key]=ident
  if k in internal:continue
  work=works.setdefault(ident,{'key':normalized,'bindings':[],'entries':[]});work['bindings'].append(key);work['entries'].append({'file':p,'line':text[:m.start()].count('\n')+1,'entry':entry})
methods=[
('HS-CALCULUS','Hermitian finite matrices and scalar Lipschitz map','HS-norm functional-calculus bound','Do not replace HS norm by dimension-independent operator norm', ['S::lem:HS-calculus']),
('SYMMETRIC-TAIL','Quadratic symbol with nonintegrable odd leading tail','Locally Lipschitz integrated field and C1 primitive','Pair symmetric cutoffs;scalar tangent extension and fixed delta;not an efficient evaluator',['S::lem:field-regularity','M::lem:field-regularity','E::field:properties']),
('UNITARY-AVERAGE','Rank-one mass and divided differences on positive matrices','Unital self-adjoint even Gaussian-mixture conjugation map','Specific rank-one construction;no arbitrary indefinite operator tangent',['S::lem:resolvent-tangent','S::lem:average','S::lem:trace-average']),
('SIGN-PARITY','Compact zeros of equivariant triangular endpoint map','Nonempty final endpoint via odd quotient boundary count','Free nonzero-row locus; no orientation/invertibility assumption or complexity guarantee',['S::path:parity','M::prop:paths','E::path:connecting']),
('HALF-LINE','Coercive full Hermitian symbol and prescribed boundary vectors','R^-1=(S+T)/2 and noncommutative Riccati relations','S,T may be indefinite; Fourier jump fixes factor2;positive full symbol needed',['M::lem:trace-half-lines']),
('TRACE-DEFICIT','Hermitian B,V with full symbol>=bI and N>=0','Two nonnegative HS/resolvent terms exactly equal trace defect','V may be indefinite but N positivity indispensable;not generic matrix loss decomposition',['M::thm:trace','E::trace:deficit']),
('RECTANGULAR-ACTION','H1_0 row-orthonormal rectangular family','Finite-interval action bound at sharp endpoint integral','All ranks allowed; lower triangular C preserves ordered spectral energy',['M::thm:action','E::act:quantitative-action']),
('REGULARIZATION-ORDER','Fixed delta path and epsilon penalty identity','Constrained action inequality after epsilon->0 then delta->0','No uniform Bprime/delta limit or cost estimate; n-dependent regularization error',['M::prop:field-comparison','E::act:constraint']),
('FORM-EXHAUSTION','Rough integrable PSD potential and finite eigenfamilies','Full negative spectral sum via form core, cutoffs and minmax','Infinite spectrum permitted;quadrature/discretization needs separate certification',['S::spectral:forms','S::spectral:dirichlet','E::bound:sharp']),
('SIGNED-DOMAIN','Signed scalar V with V_- in Lp','Sharp upper bound using negative part and form order','Positive part weighted domain must be dense;not arbitrary signed matrix extension',['S::spectral:signed']),
('TRACE-YOUNG','Two finite PSD matrices with conjugate exponents','Sharp Young bound/coercivity and equality W=qZ^r','Commutation is deduced only at equality;nonnegative matrix inputs essential',['E::pre:young']),
('COMMON-SHIFT','Growing finite eigenfamilies near equality','Energy-gap-preserving compactness with fixed physical-rank tails','Common xi shifts preserve gaps;pointwise B need not have measurable global selection',['E::comp:relations']),
('GLOBAL-CHANNELS','Pointwise equality block relations and bounded logarithmic derivative','Fixed right kernels/left ranges and constant-basis solitons','Exact equality only;no quantitative distance-to-soliton or noisy-data estimator',['E::rig:fixed-right-spaces','E::rig:fixed-left-spaces','E::thm:main']),
('COMPLEX-REALIFICATION','Finite complex Hermitian PSD potential','Real symmetric double-channel representation preserving both traces by factor2','A constant unitary is required;pointwise diagonalization introduces derivative connections',['M::thm:main','E::thm:main'])]
gaps=['All3 current natural sources read, but transitive natural/formal proof dependencies and full historical lineage are not complete.','4 historical original works have selected scopes checked;other bibliography originals unread;old strongest non-unit-exponent constants not exhaustively compared.','Only selected scalar Lean specifications/proof endpoints read;no Lean or Comparator run/human specification review. Matrix/equality have no established formal scope in this audit.','No certified continuum-to-grid bridge, quadrature/tail error, real caller workload or independent application oracle;known soliton calibration is not a new application test.','Exact equality rigidity and capped proof defect do not establish a usable near-equality stability algorithm.','Second provider and real human gates deferred,not waived;all full-family/history/application completion counts remain unchanged.']
pixels=[]
for name,page,which in [('S-main',1,'S'),('M-main',1,'M'),('E-main',2,'E'),('S-formula',2,'S'),('M-formula',2,'M'),('Read-main',8,'ReadSchulz2026v2'),('HLW-bound',9,'HLW1999v1'),('FGL-equality',10,'FGL2023v2')]:
 p=TMP/(name+'.png');pixels.append({'name':name,'source':which,'pdf_page':page,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size,'actual_pixels_inspected':True,'retained':False})
versions={'reconciliation':[json.loads(l) for l in (ROOT/'data/corpus/reconciliation.jsonl').read_text().splitlines() if json.loads(l).get('family_id')=='F-262'],'archived_replacement_rows':0,'history_scope':'Pinned history exacttitle search no entry;local git log bounded to three paths shows initialadc7f1241 only;3 unchanged catalogue paths and0 archive rows are not an exhaustive remote/git history audit.'}
ledger={'family_id':'F-262','manuscript_ids':[m['id'] for m in ms],'work_package':'WP-092','generation_id':G,'recorded_at':NOW,'upstream_commit':UP,'project_base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'read_files':{f['path']:{'sha256':f['sha256'],'total_lines':f['lines'],'read_ranges':f['body_read_ranges'],'fully_read':True} for f in j['files']},'source_closure':closure,'tex_files':31,'tex_lines':5362,'extra_scalar_bibliography_lines':255,'named_result_count':37,'named_results':rows,'result_label_aliases_not_extra_results':[],'methods':methods,'formal_scope':formal,'original_history_scopes':history,'original_acquisitions':[a for a in acq if 'failure' not in a],'failed_acquisitions':[a for a in acq if 'failure' in a],'pixel_inspections':pixels,'source_figure_png_read':j['visual_reads'],'version_audit':versions,'bibliography_bindings':len(bindings),'external_works':len(works),'historical_roots_selected_checked':4,'new_candidate_count':0,'new_numerical_run':False,'full_family_complete':False,'historical_lineage_complete':False,'dependency_closure_complete':False,'gaps':gaps}
dump('data/provenance/readings/F-262.json',ledger)
policy=json.loads((ROOT/'configs/research.json').read_text());dump('data/provenance/research-at-generation-088.json',policy)
base_source=src('data/provenance/readings/F-262.json','WP092 actual31TeX5362+255Bib/3READMEs;37 per-source results;scalar selected formal endpoints;4 primary works selected scopes/8PDFpixels;not proof or full lineage review')
nodes=[json.loads(l) for l in (ROOT/'data/graph/nodes.jsonl').read_text().splitlines()];edges=[json.loads(l) for l in (ROOT/'data/graph/edges.jsonl').read_text().splitlines()];ids={n['id'] for n in nodes};before=copy.deepcopy(nodes);oldedges=copy.deepcopy(edges)
assert G not in ids
def node(ident,kind,props,sources=None,ev='source_content_checked'):
 n={'id':ident,'kind':kind,'version':1,'created_at':NOW,'evidence_status':ev,'properties':dict(props,model_generation_id=G),'sources':sources or [base_source]}
 if ident in ids:
  ix=next(i for i,n in enumerate(nodes) if n['id']==ident);old=nodes[ix];assert ident in ['CLM-262-SCALAR','CLM-262-MATRIX'];n.update(version=old['version']+1,created_at=old['created_at'],updated_at=NOW,updated_by_generation_id=G,prior_version_archive='data/graph/history/GEN088-F262-before.json.gz');nodes[ix]=n
 else:nodes.append(n);ids.add(ident)
 return ident
def edge(a,rel,b,loc):
 ident='E-'+hashlib.sha256(f'{a}|{rel}|{b}'.encode()).hexdigest()[:16].upper()
 if any(e['id']==ident for e in edges):return
 edges.append({'id':ident,'source':a,'relation':rel,'target':b,'version':1,'evidence_status':'source_content_checked','source_locator':loc,'source_commit':UP,'created_at':NOW})
pack('data/graph/history/GEN088-F262-before.json.gz',{'records':[n for n in nodes if n['id'] in ['CLM-262-SCALAR','CLM-262-MATRIX']]})
node(G,'generation',{'title':'F262三篇当前全文、算子历史基线与等号范围','family_ids':['F-262'],'provider':'OpenAI','model':'Current user-selected session;exact backend unknown','human_review':None,'independent_second_provider':None,'source_commit':UP,'project_base_commit':ledger['project_base_commit'],'task':'Actual natural body/selected formal and historical interface reading;no mathematical proof verification or application experiment'},[base_source,src('data/provenance/research-at-generation-088.json','Frozen research policy')])
for r in rows:
 fs=None
 if r['grade']=='B':fs={'module':'OAI.Analysis.LiebThirring.Main','declaration':'OAI.SharpLiebThirring.sharp_lieb_thirring','build':False,'Comparator':False,'human_review':False,'scope':'Scalar full moment,optimal constant,explicit attainment;not all optimizers/matrix generalization'}
 sources=[base_source,src(r['file'],f"Lines{r['lines'][0]}-{r['lines'][1]};label{r['label']};entire source body/proof read")]
 if fs:sources += [src(p,'Entire selected actual specification/proof endpoint read;no build') for p in formalpaths if p.endswith(('Model.lean','Main.lean','LiebThirring.json'))]
 node(r['id'],'claim',{'title':r['title'],'statement':r['statement'],'conditions':[common,r['conditions']],'constants_and_constructions':[r['constants']],'family_id':'F-262','family_ids':['F-262'],'manuscript_id':r['manuscript_id'],'natural_label':r['label'],'natural_label_aliases':r['aliases'],'credibility':r['grade'],'source_claim_grade':r['grade'],'formalized':bool(fs),'formal_scope':fs,'dependency_closure_complete':False,'proof_review':'Full natural body reading and selected formal comparison by one model;not independent/human proof review'},sources)
 edge(r['id'],'member_of','F-262','Per-source result binding');edge(r['id'],'derived_from',r['manuscript_id'],'Actual current natural statement and included proof')
# Explicit direct proof uses; do not infer all bibliography edges from key occurrence.
deps={
'S::thm:main':['S::spectral:forms','S::spectral:dirichlet'],
'S::spectral:dirichlet':['S::thm:action'],
'S::thm:action':['S::path:existence','S::prop:rankone','S::lem:jensen'],
'S::path:existence':['S::path:parity','S::lem:jensen','S::lem:field-regularity'],
'S::prop:rankone':['S::lem:resolvent-tangent','S::lem:average','S::lem:trace-average'],
'S::lem:field-regularity':['S::lem:HS-calculus'],
'S::spectral:signed':['S::thm:main','S::spectral:forms'],
'M::thm:main':['M::thm:action','M::lem:form-compactness'],
'M::thm:action':['M::prop:paths','M::prop:field-comparison','M::lem:field-properties'],
'M::prop:field-comparison':['M::thm:trace','M::lem:field-properties'],
'M::thm:trace':['M::lem:trace-half-lines'],
'M::prop:paths':['M::lem:field-regularity','M::lem:field-properties'],
'E::thm:main':['E::bound:sharp','E::comp:relations','E::rig:fixed-right-spaces','E::rig:fixed-left-spaces'],
'E::bound:sharp':['E::pre:spectral','E::pre:young','E::act:quantitative-action'],
'E::act:quantitative-action':['E::act:constraint','E::path:connecting','E::field:properties'],
'E::act:constraint':['E::trace:deficit','E::field:positive'],
'E::comp:relations':['E::act:quantitative-action','E::pre:young','E::pre:spectral'],
'E::rig:fixed-right-spaces':['E::comp:relations'],
'E::rig:fixed-left-spaces':['E::rig:fixed-right-spaces','E::comp:relations'],
'E::field:positive':['E::field:properties','E::trace:deficit'],
'E::path:connecting':['E::field:properties']}
for a,ds in deps.items():
 for b in ds:edge(bykey[a],'depends_on',bykey[b],'Direct proof use in actually read included source;not full transitive proof audit')
methodids=[]
for name,inp,out,lim,keys in methods:
 ident='PART-262-'+name;methodids.append(ident);node(ident,'method',{'title':name,'input':inp,'output':out,'conditions':[common,lim],'cannot_transfer':lim,'source_result_ids':[bykey[k] for k in keys],'family_ids':['F-262'],'credibility':'C','dependency_closure_complete':False})
 for k in keys:edge(ident,'depends_on',bykey[k],'Input-output contract extracted from selected source results')
for ident,w in works.items():
 hs=next((h for h in history if h['key']==w['key']),None);sources=[base_source]+[src(e['file'],f"Bibliography entry line{e['line']};workbinding{w['bindings']}") for e in w['entries']]
 props={'title':w['key'],'bibliography_bindings':w['bindings'],'bibliography_entries':w['entries'],'family_ids':['F-262'],'credibility':'unknown','dependency_closure_complete':False,'content_verified':bool(hs),'selected_only':True,'scope':hs['locator']+';'+hs['boundary'] if hs else 'Bibliography metadata only;original body unread'}
 if hs:
  a=next(a for a in acq if a['id']==hs['acquisition']);sources.append({'url':a['url'],'sha256':a['sha256'],'source_revision':a['id'],'content_checked':True,'locator':hs['locator']});props.update(original_content_fact=hs['fact'],original_content_boundary=hs['boundary'])
 node(ident,'literature',props,sources)
for key,ident in bindings.items():
 t=key.split('::')[0];edge(bykey[t+'::thm:main'],'historical_context',ident,'Manuscript-specific bibliography context;content check limited to literature node scope')
domains=[('生物','一维多通道结合态的谱预算','需实际导出Schrodinger模型、单位和势可积性；一般反应网络谱不匹配'),('金融','尾部风险谱矩约束的结构类比','风险矩阵不是连续Schrodinger算子；未找到保前提映射'),('交通','多车道局域缺陷模态','车流非自伴/离散动力学不自动满足HermitianPSD势'),('能源','波导或有效质量模型中的负模预算','需一维连续有效模型、动能系数重标定和真实负态目标'),('语言','谱嵌入中的低特征值预算','图拉普拉斯/语言矩阵没有已证连续化桥梁'),('艺术','耦合弦或声学通道的局域模态','声学频率与Schrodinger负能量的物理映射未确认，边界条件必须保留'),('物流','调度矩阵的极端特征值控制','没有合法的空间势/二次型映射，旧离散优化法可能足够'),('材料','多带准一维缺陷束缚态矩','可能保留有限内部通道，但真实有效哈密顿量与独立谱裁判尚缺'),('机器人','柔性机构局域振动模态','需自伴连续模型和PSD负扰动；未给噪声或控制收益'),('云计算','不稳定模态资源预算','服务矩阵通常非自伴且离散；未建立保谱桥梁')]
allnodes={n['id']:n for n in nodes}
cross=[]
for fid,idea,boundary in [('F-025','正有理积分权重的单位分数表示能否辅助有限求积','单位分数精确表示不证明连续算符求积、尾部误差或矩阵谱对应；未找到数值优势'),('F-325','非交换有限矩阵与谱界','数值域/谱集有界算子问题不同于不有界Schrodinger全谱矩；无直接组合增益'),('F-332','谱正则化与图去噪预算','图平滑使用有限离散图及噪声模型；未建连续化桥梁，不重跑既有不利网格')]:
 candidates=[n['id'] for n in nodes if n['kind']=='method' and (fid in n['properties'].get('family_ids',[]) or n['id'].startswith('PART-'+fid[2:]+'-'))];assert candidates,fid;cross.append({'family_id':fid,'mapping':idea,'boundary':boundary,'target_id':candidates[0]})
node('XPL-262-TEN-DOMAINS','exploration',{'title':'F262十域尝试、三族边界与旧法零假设','family_ids':['F-262'],'domain_attempts':[{'domain':d,'idea':i,'obstacle_or_condition':b,'status':'conditional_map_or_unestablished'} for d,i,b in domains],'cross_family_attempts':cross,'interpretation':'Exploration attempts only;no actual caller,certified continuum bridge,independent benchmark or new candidate established. Existing gamma1 result and old factorization may already suffice.','new_candidate_count':0,'new_application_run':False,'opposition':{'text':'A sharper theorem constant is not measured engineering gain;old gamma1 result, direct numerical solver or known soliton model may already suffice. Finite grid cannot be substituted without certification.','timing':'Post-source/history reading;single-model auxiliary self-check'},'defense':{'text':'Strict nonunit exponents and constant global channel rigidity expose testable contracts once a genuine continuum caller and independent certified spectral reference are located.','timing':'Post-source/history reading;same nonisolated session'}})
for x in cross:edge('XPL-262-TEN-DOMAINS','compares_with',x['target_id'],x['boundary'])
for name,text in [('FORMAL','Only scalar selected proof endpoint has B source scope;matrix/equality cannot inherit it. No local build or human review.'),('CONTINUUM','No certified continuum-to-grid/tail/quadrature bridge and actual consumer;known soliton spectrum not new application evidence.'),('HISTORY','4 selected original scopes out of all external works,full transitive proof/history closure incomplete. Exact equality does not yield an executable near-equality stability theorem.')]:
 ident='CHECK-262-'+name;node(ident,'review',{'title':name+' boundary','family_ids':['F-262'],'review_type':'Single-model source qualification;not mathematical human or second-provider review','finding':text,'new_application_run':False,'credibility':'unknown','dependency_closure_complete':False});edge('ANALYSIS-F-262','depends_on',ident,'Unresolved qualification gate;no full-family completion')
comparisons=[{'item':'Scalar sharp full moment','natural':scope['S::thm:main'][1]+' '+scope['S::thm:main'][2],'Lean':'Actual Model/Comparator definitions identical in selected H1...MainClaim block;Main actual proof endpoint and MomentBound/SpectralMain operator bridge read','assessment':'Selected scalar source B;no build,Comparator,human or full dependency audit'}, {'item':'Matrix bound and all equality cases','natural':scope['M::thm:main'][1]+' '+scope['E::thm:main'][1],'Lean':'docs262/formalization registration/actual challenge and Main specify scalar W:R->R only','assessment':'Source C separately;family title does not transfer B to complex channels or full optimizer classification'}, {'item':'Support lemmas','natural':'All 36 other labelled statements across three current manuscripts read','Lean':'Only selected scalar theorem endpoint attributed;static import index is not per-support specification proof review','assessment':'Conservative C support scope;full dependency grade unknown'}]
node('ANALYSIS-F-262','family_analysis',{'title':'F262三篇当前源文拆解与受限历史/形式化对照','family_id':'F-262','family_ids':['F-262'],'manuscript_ids':[m['id'] for m in ms],'manuscript_source_drafts_complete_ids':[m['id'] for m in ms],'source_sections':sorted(byfile),'source_line_count':5362,'source_decomposition_draft_complete':True,'result_ids_by_label':bykey,'result_ids_by_source':byfile,'method_ids':methodids,'formal_statement_comparison':comparisons,'formal_status':formal,'historical_references_by_key':bindings,'historical_verified_keys':[k for k in bindings if k.split('::')[1] in [h['key'] for h in history]],'source_result_count':37,'full_family_complete':False,'historical_lineage_complete':False,'dependency_closure_complete':False,'credibility':'unknown','gaps':gaps,'source_scope':'31TeX5362lines+255scalarBib+3READMEs all actualread;37results separatelybound;no experiment/candidate'},[base_source])
for r in rows:edge('ANALYSIS-F-262','summarizes',r['id'],'Whole current source decomposition draft;not full family/historical completion')
edge('XPL-262-TEN-DOMAINS','derived_from','ANALYSIS-F-262','Conditional mapping attempts after actual source/history comparison')
# Preserve canonical old rows/edges byte-for-byte except exactly two versioned main claims.
for n in before:
 if n['id'] not in ['CLM-262-SCALAR','CLM-262-MATRIX']:assert next(x for x in nodes if x['id']==n['id'])==n
assert edges[:len(oldedges)]==oldedges
for name,records in [('nodes',nodes),('edges',edges)]:(ROOT/f'data/graph/{name}.jsonl').write_text(''.join(json.dumps(n,ensure_ascii=False,sort_keys=True)+'\n' for n in records))
covp='data/graph/reading_coverage.json';cov=json.loads((ROOT/covp).read_text());pack('data/graph/history/GEN088-reading-coverage-before.json.gz',cov)
cov['partially_read_families']['F-262']=['All3currentmanuscripts31TeX5362lines+255Bib/3READMEs actual full source reading and per-result draft','37namedbindings/14methodcontracts;scalar selected actualLean endpoint/spectralbridge,notmatrix/equalityformalcoverage','4primaryworks selected oldscope interfaces;8PDFpixels plus upstreamfigurePNG;fullhistory/proofclosure incomplete','10domainattempts/3crossfamilyboundaries;no new candidate or numerical application run']
draft=cov['source_decomposition_drafts'];print('draft_type',type(draft).__name__)
if isinstance(draft,list):
 if 'F-262' not in draft:draft.append('F-262')
else:draft['F-262']={'analysis_id':'ANALYSIS-F-262','complete':True,'note':'Current natural source draft only;not full family/history or proof review'}
cov['updated_at']=NOW;dump(covp,cov)
stats={'new_nodes':len(nodes)-len(before),'old_nodes_exact':len(before)-2,'revised_nodes':['CLM-262-SCALAR','CLM-262-MATRIX'],'old_edges_exact':True,'new_edges':len(edges)-len(oldedges),'results':len(rows),'methods':len(methods),'bibliography_bindings':len(bindings),'external_works':len(works),'full_family_complete':False}
dump('reports/reproducibility/20261022-lieb-thirring/curation.json',stats);print(json.dumps(stats,indent=2))
