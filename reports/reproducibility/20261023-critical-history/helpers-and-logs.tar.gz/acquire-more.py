from pathlib import Path
import urllib.request,hashlib,json,datetime
T=Path('/private/tmp/ai-paper-WP100');p=T/'acquisition.json';j=json.loads(p.read_text())
jobs=[('Hatcher-ch0.pdf','https://pi.math.cornell.edu/~hatcher/AT/ATch0.pdf'),('Brown-I-preview.pdf','https://page-one.springer.com/pdf/preview/10.1007/978-1-4684-9327-6_2'),('Brown-VIII-preview.pdf','https://page-one.springer.com/pdf/preview/10.1007/978-1-4684-9327-6_9')]
for name,url in jobs:
 d={'name':name,'url':url,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'ai-paper bounded original-source reading'}),timeout=35) as r:
   b=r.read(j['cap']-j['downloaded_bytes']+1);d.update(status=r.status,final_url=r.url,content_type=r.headers.get('Content-Type'),bytes=len(b));assert len(b)<=j['cap']-j['downloaded_bytes'];assert b[:4]==b'%PDF';(T/name).write_bytes(b);j['downloaded_bytes']+=len(b);d['sha256']=hashlib.sha256(b).hexdigest()
 except Exception as e:d['error']=repr(e)
 j['requests'].append(d);p.write_text(json.dumps(j,indent=2)+'\n');print(json.dumps(d),flush=True)
