from pathlib import Path
import json,gzip,hashlib,datetime
R=Path('/Users/smzdm/projects/ai_paper');path='math/preprints/A-Torsion-Free-Group-Algebra-with-Zero-Divisors-September-23-2026/build/sections/topology.tex';sha=hashlib.sha256((R/path).read_bytes()).hexdigest();p=R/'data/graph/nodes.jsonl';lines=p.read_bytes().splitlines(keepends=True);ids={'PART-196-RESOLUTION-DIMENSION-GATE':'cor:torsion-free,restriction to primecyclic subgroup by coset representatives;Brownpreview separately supports dimension/Ext scope','CHECK-196-HUREWICZ-SPECIALIZATION':'prop:topology,essential-sphere homology split cites Hatcher4.37;the originalHatcherbasepointscope is separately retained'};old=[json.loads(l) for l in lines if json.loads(l)['id'] in ids];assert len(old)==2 and all(n['version']==1 for n in old);b=(json.dumps({'reason':'Add exact F196 primary text bindings for claims combining new original-history scopes with the actual manuscript use;no fact/grade/count changes','records':old},ensure_ascii=False,indent=2)+'\n').encode();z=gzip.compress(b,mtime=0);assert gzip.decompress(z)==b;(R/'data/graph/history/GEN097-before-source-binding.json.gz').write_bytes(z);out=[]
for l in lines:
 n=json.loads(l)
 if n['id'] in ids:
  n['version']=2;n['updated_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();n['sources'].append({'path':path,'sha256':sha,'commit':'1581d4cbdd69a0faf34b2089614fe2a814316a6a','locator':ids[n['id']]});l=(json.dumps(n,ensure_ascii=False,sort_keys=True)+'\n').encode()
 out.append(l)
p.write_bytes(b''.join(out));print('Two newrecordv1s preserved;actual F196 uses now directly bound to sourcehash;old4192records unaffected')
