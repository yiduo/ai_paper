from pathlib import Path
import urllib.request,hashlib,json,datetime
T=Path('/private/tmp/ai-paper-WP100');cap=8388608;rows=[];total=0
jobs=[('LiptonTarjan1979.pdf','https://www.cs.princeton.edu/courses/archive/fall06/cos528/handouts/sepplanar.pdf'),('Hatcher-ch4.pdf','https://pi.math.cornell.edu/~hatcher/AT/ATch4.pdf')]
for name,url in jobs:
 d={'name':name,'url':url,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'ai-paper research reading (bounded public original-source retrieval)'})
  with urllib.request.urlopen(req,timeout=35) as r:
   b=r.read(cap-total+1);d.update(status=r.status,final_url=r.url,content_type=r.headers.get('Content-Type'),bytes=len(b));assert len(b)<=cap-total,'resource cap';assert b[:4]==b'%PDF','not PDF'
   (T/name).write_bytes(b);total+=len(b);d['sha256']=hashlib.sha256(b).hexdigest()
 except Exception as e:d['error']=repr(e)
 rows.append(d);(T/'acquisition.json').write_text(json.dumps({'cap':cap,'downloaded_bytes':total,'requests':rows},indent=2)+'\n');print(json.dumps(d),flush=True)
