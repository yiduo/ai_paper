import json,gzip,hashlib,pathlib,sys,subprocess,xml.etree.ElementTree as ET
R=pathlib.Path('/Users/smzdm/projects/ai_paper');T=pathlib.Path('/private/tmp/ai-paper-WP100');OUT=R/'reports/reproducibility/20261023-critical-history';sys.path.insert(0,str(R/'src'))
from ai_value.graph import load,affected_nodes,theoretical_grade
from ai_value.knowledge import export
def sha(b):return hashlib.sha256(b).hexdigest()
def write(n,j):
 b=(json.dumps(j,ensure_ascii=False,indent=2)+'\n').encode();z=gzip.compress(b,mtime=0);assert gzip.decompress(z)==b;(OUT/n).write_bytes(z)
nodes,edges=load(R);cases=[];main='CLM-196-THM-MAIN';gate='PART-196-FINITE-WITNESS-GATE'
def check(n,seed,yes,no):
 hit=affected_nodes(nodes,edges,set(seed));assert set(yes)<=hit,(n,'missing',set(yes)-hit);assert not(set(no)&hit),(n,'false',set(no)&hit);cases.append({'name':n,'changed':seed,'expected_review':yes,'expected_unaffected':no,'affected':sorted(hit),'pass':True})
check('original_weighted_reaches_recursive_use',['OLD-196-LT-WEIGHTED-SEPARATOR'],['CLM-196-LEM-PLANAR-SEPARATION',main,gate],['CLM-196-LEM-PICTURES'])
check('original_count_reaches_main',['OLD-196-LT-UNWEIGHTED-SEPARATOR'],[main,gate],['CLM-196-PROP-BOUNDED-PATTERN'])
check('CW_HEP_actual_picture_dependency',['OLD-196-HATCHER-CW-HEP'],['CLM-196-LEM-PICTURES',main,gate],['CLM-196-PROP-BOUNDED-PATTERN'])
check('relative_equivalence_not_just_global_contractibility',['OLD-196-HATCHER-RELATIVE-EQUIVALENCE'],['CLM-196-LEM-PICTURES',main],['OLD-196-LT-UNWEIGHTED-SEPARATOR'])
check('homological_Whitehead_is_required',['OLD-196-HATCHER-HOMOLOGICAL-WHITEHEAD'],['CLM-196-COR-TORSION-FREE',main],['CLM-196-PROP-BOUNDED-PATTERN'])
check('natural_Hurewicz_map_is_actual_split_dependency',['OLD-196-HATCHER-HUREWICZ-MAP'],['PART-196-ESSENTIAL-SPHERE-SPLIT',main],['CLM-196-PROP-BOUNDED-PATTERN'])
check('visible_Brown_scope_reaches_torsion_argument',['OLD-196-BROWN-FINITE-RESOLUTION-VANISHING'],['PART-196-RESOLUTION-DIMENSION-GATE','CLM-196-COR-TORSION-FREE',main],['CLM-196-LEM-PLANAR-SEPARATION'])
check('Brown_unread_check_is_routing_not_a_proof_premise',['CHECK-196-BROWN-COMPARISON-UNREAD'],[],[main,gate])
check('Brown_work_change_reopens_its_scope_and_main',['LIT-196-BROWN1982'],['CHECK-196-BROWN-COMPARISON-UNREAD',main],['CLM-196-PROP-BOUNDED-PATTERN'])
check('old_taiko_still_context_only',['LIT-196-SHIN2026'],['CHECK-196-TAIKO-ROUTE-SCOPE'],[main,gate])
check('history_exploration_not_math_premise',['XPL-196-CRITICAL-HISTORY'],[],[main,gate])
check('F256_old_admission_preserved',['LIT-256-GAP-FP-INTERFACE'],['APP-256-01'],[main])
check('F058_QE_preserved',['LIT-058-QEPCAD-INTERFACE'],['APP-058-01'],[main])
check('unqualified_demand_not_source_proof',['PROB-196-CONCRETE-GROUP-RING-FIXTURE'],[],[main,gate])
assert theoretical_grade(nodes,edges,main)=='unknown'
write('impact.json.gz',{'cases':cases,'count':len(cases),'main_dependency_grade':'unknown','meaning':'Review routing,not theorem rejection/build/human or application validation'})
ex=export(R);j=json.loads(gzip.decompress((R/'reports/graph/knowledge.json.gz').read_bytes()));assert {n['id']:n for n in j['nodes']}==nodes and j['edges']==edges
tree=ET.fromstring(gzip.decompress((R/'reports/graph/knowledge.graphml.gz').read_bytes()));ns={'g':'http://graphml.graphdrawing.org/xmlns'}
gn={n.attrib['id']:json.loads(next(d.text for d in n if d.attrib.get('key')=='properties')) for n in tree.findall('.//g:node',ns)};ge={n.attrib['id']:json.loads(next(d.text for d in n if d.attrib.get('key')=='evidence')) for n in tree.findall('.//g:edge',ns)};assert gn==nodes and ge=={e['id']:e for e in edges}
write('exports.json.gz',{'export':ex,'json_full_nodes_edges_exact':True,'graphml_full_nodes_edges_exact':True})
archives=[];members=0
for p in sorted((R/'experiments/runs').glob('*/manifest.json')):
 m=json.loads(p.read_text())
 for name,h in m['outputs'].items():
  b=(p.parent/name).read_bytes();assert sha(b)==h
  if name.endswith('.gz'):gzip.decompress(b)
 for name,d in m.get('compressed_payloads',{}).items():assert sha(gzip.decompress((p.parent/name).read_bytes()))==d['uncompressed_sha256']
 s=json.loads(gzip.decompress((p.parent/m['source_snapshot']).read_bytes()));assert set(s)==set(m['inputs']);assert all(isinstance(t,str) and sha(t.encode())==m['inputs'][n] for n,t in s.items());members+=len(s)
 archives.append({'run_id':m['run_id'],'source_members':len(s),'all_output_and_decompressed_hashes_verified':True,'scientific_replay':False})
write('archives.json.gz',{'archives':archives,'count':len(archives),'source_members':members,'reason_no_replay':'No experimental code/spec/data/comparator changes;WP100 original-history reading not application validation'})
oldraw=subprocess.check_output(['git','show','9e35254:data/graph/nodes.jsonl'],cwd=R);olded=subprocess.check_output(['git','show','9e35254:data/graph/edges.jsonl'],cwd=R)
oldlines={json.loads(l)['id']:l for l in oldraw.splitlines()};newlines={json.loads(l)['id']:l for l in (R/'data/graph/nodes.jsonl').read_bytes().splitlines()};old={i:json.loads(l) for i,l in oldlines.items()};new={i:json.loads(l) for i,l in newlines.items()}
prior=json.loads(gzip.decompress((R/'data/graph/history/GEN097-critical-history-before.json.gz').read_bytes()))['records'];changed={n['id'] for n in prior};assert len(changed)==4 and all(n==old[n['id']] for n in prior)
assert all(newlines[i]==l for i,l in oldlines.items() if i not in changed);assert all(new[i]['version']==old[i]['version']+1 for i in changed)
assert len(old)==4192 and len(new)-len(old)==14 and (R/'data/graph/edges.jsonl').read_bytes().startswith(olded)
for p in ['data/graph/reading_coverage.json','data/provenance/readings/F-196.json']:
 assert (R/p).read_bytes()==subprocess.check_output(['git','show','9e35254:'+p],cwd=R)
assert not subprocess.check_output(['git','diff','--name-only','9e35254','--','src','tests','experiments'],cwd=R,text=True).strip()
assert all(new[i]==n for i,n in old.items() if n['kind']=='connection')
write('canonical-preservation.json.gz',{'base':'9e35254','old_other_records_byte_exact':len(old)-len(changed),'exact_prior_records_archived':sorted(changed),'all_prior_nodes_exact_in_archive':True,'all_old_edge_bytes_prefix_exact':True,'old_candidate_nodes_and_old_WP099_ledger_and_coverage_exact':True,'experimental_code_specs_runs_tests_unchanged':True,'new_records':len(new)-len(old),'new_application_experiments':0})
ledger=json.loads((R/'data/provenance/history/F-196-critical-inputs.json').read_text())
for f in ledger['acquisition']['requests']:assert sha((T/f['name']).read_bytes())==f['sha256']
for p in ledger['actual_pdf_pixels']:assert sha((T/p['image_name']).read_bytes())==p['image_sha256'] and p['pixels_actually_viewed']
assert ledger['comparison_theorem_still_unread'] and ledger['required_original_scope_checked_keys_added']==['LiptonTarjan1979','Hatcher2002']
a=new['ANALYSIS-F-196']['properties'];assert len(a['historical_verified_keys'])==6 and 'Brown1982' not in a['historical_verified_keys'] and a['historical_partial_keys']['Brown1982']
assert not a['full_family_complete'] and not a['historical_lineage_complete']
v1s=json.loads(gzip.decompress((R/'data/graph/history/GEN097-before-source-binding.json.gz').read_bytes()))['records'];assert len(v1s)==2
for v in v1s:
 n=new[v['id']];assert v['version']==1 and n['version']==2 and n['sources'][:-1]==v['sources'];assert n['properties']==v['properties'] and n['sources'][-1]['path'].endswith('/sections/topology.tex')
write('source-binding-addendum.json.gz',{'two_new_record_priors_exact':True,'actual_F196_primary_text_bindings_added':2,'properties_grades_counts_unchanged':True,'all_4192_old_record_scope_unchanged':True})
ss=[s for n in new.values() for s in n['sources']]
write('source-contracts.json.gz',{'original_works':3,'PDF_files':5,'actual_pixels':13,'source_hashes_verified':True,'main_full_dependency_grade':'unknown','Brown_required_comparison_unread':True,'fullfamily_and_full_lineage_not_promoted':True,'all_canonical_annotations':len(ss),'local_annotations':sum('path'in s for s in ss),'external_annotations':sum('url'in s for s in ss),'external_without_byte_hash':sum('url'in s and not s.get('sha256') for s in ss),'new_download_bytes':3115137})
print(json.dumps({'nodes':len(nodes),'edges':len(edges),'canonical_records':len(new),'impact_cases':len(cases),'archives':len(archives),'source_members':members,'old_record_preservation':True}))
