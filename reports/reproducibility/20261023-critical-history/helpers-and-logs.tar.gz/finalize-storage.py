from pathlib import Path
import json,gzip,hashlib,tarfile,io,datetime,subprocess
R=Path('/Users/smzdm/projects/ai_paper');T=Path('/private/tmp/ai-paper-WP100');O=R/'reports/reproducibility/20261023-critical-history';now=datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda b:hashlib.sha256(b).hexdigest()
def write(p,j):(R/p).write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
clean=json.loads(gzip.decompress((O/'no-math-clean-directory.json.gz').read_bytes()));assert clean['exit_code']==0 and not clean['upstream_math_present'] and not (T/'no-math-clean').exists()
assert 'Ran 68 tests' in (T/'core-final.log').read_text() and '\nOK\n' in (T/'core-final.log').read_text()
assert not subprocess.check_output(['git','-C','math','status','--porcelain'],cwd=R,text=True).strip();assert subprocess.check_output(['git','-C','math','rev-parse','HEAD'],cwd=R,text=True).strip()=='1581d4cbdd69a0faf34b2089614fe2a814316a6a'
assert sha((R/'722篇AI数学论文应用价值挖掘纲领.md').read_bytes())=='96fad398177fc3a54a87c07867456c5d84e66a7d538500b00ca4797d0a749c6e'
ledger=json.loads((R/'data/provenance/history/F-196-critical-inputs.json').read_text())
for f in ledger['acquisition']['requests']:assert sha((T/f['name']).read_bytes())==f['sha256']
for p in ledger['actual_pdf_pixels']:assert sha((T/p['image_name']).read_bytes())==p['image_sha256'] and p['pixels_actually_viewed']
raw=[p for p in T.iterdir() if p.is_file() and p.suffix in {'.pdf','.txt','.png'}];meta=[{'name':p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'retention':'Removed after actual source/version/page/image provenance saved;not redistributed'} for p in sorted(raw)]
helpers=[p for p in T.iterdir() if p.is_file() and p not in raw];assert all(p.suffix in {'.py','.log','.json'} for p in helpers);mem={p.name:p.read_bytes() for p in helpers};buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as tar:
 for n,b in sorted(mem.items()):
  x=tarfile.TarInfo(n);x.size=len(b);x.mtime=0;x.mode=0o644;tar.addfile(x,io.BytesIO(b))
b=buf.getvalue();z=gzip.compress(b,mtime=0);assert gzip.decompress(z)==b
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(z)),mode='r:') as tar:
 assert set(tar.getnames())==set(mem)
 for n,v in mem.items():assert tar.extractfile(n).read()==v
out=O/'helpers-and-logs.tar.gz';out.write_bytes(z);assert gzip.decompress(out.read_bytes())==b
storage={'at':now,'temporary_root':str(T),'primary_original_works':3,'downloaded_PDFs':5,'downloaded_bytes':3115137,'actual_pixels':13,'temporary_raw_files':meta,'temporary_raw_bytes_removed':sum(x['bytes'] for x in meta),'own_archive':str(out.relative_to(R)),'compressed_bytes':len(z),'uncompressed_tar_bytes':len(b),'compressed_sha256':sha(z),'uncompressed_tar_sha256':sha(b),'member_bytes':sum(map(len,mem.values())),'members':{n:{'bytes':len(v),'sha256':sha(v)} for n,v in sorted(mem.items())},'all_decompressed_member_bytes_verified_before_plaintext_removal':True,'failed_helper_and_log_retained':True,'official_math_clean_pinned':True,'root_charter_hash_unchanged':True,'new_numerical_experiment_data':False,'install_or_cache_download':False,'external_fulltext_republished':False,'temporary_root_removed':False}
for p in raw:assert sha(p.read_bytes())==next(x['sha256'] for x in meta if x['name']==p.name);p.unlink()
for p in helpers:assert p.read_bytes()==mem[p.name];p.unlink()
T.rmdir();storage['temporary_root_removed']=not T.exists();write('reports/reproducibility/20261023-critical-history/storage.json',storage)
(O/'quality.md').write_text(f'''# WP100 quality receipt

2026-10-23. Three old original works in selected scopes;no new application candidate,initial check,numerical/symbolic experiment,Lean/Comparator build,human review or second-provider invocation.

- Existing 68 core tests with no skips,canonical validation,regenerated reports and lossless source audit passed on the final data. Existing Python3.12.14 and bundled Node;no install. The first pass preceded two direct manuscript-source annotations;final checks cover those additions.
- Fourteen new canonical records,56 new explicit edges,four old records versioned with exact priors;all other4,188 old record lines and all prior edge bytes exact. Two new record initial versions before adding actual F196 source bindings also retained;properties,grades and conditions unchanged. Initial helper indentation failed a duplicate-edge assertion before canonical writes;failed code/log retained,validator unchanged.
- Full graph6,884nodes/18,768relations. All7,232canonical source annotations retained,7,222in core-validated types;6,730local hashed and502external annotations without retained fulltext,347external without byte hash. FullJSON/GraphML objects equal graph.load;14new/old impact cases passed.
- Five originalPDF hashes and13actually inspected page-image hashes verified. Required old LTconstant/disconnected case,HatcherrelativeCW/Hurewicz/Whitehead scopes andBrownVIII.2.1 documented. BrownI.7.5p24 andfullcycliccohomology originalproof remain unread;all full dependency grades unknown. Six selected verified bibliography roots,Brownpartial,15other originalbodies plus recursivehistory incomplete;no fullfamily promotion.
- All43oldcandidate nodes,originalWP099readingledger,readingcoverage,experimentcode/plans/data/comparators/tests unchanged. All15compressed archives/267source members passed compressed,uncompressed andinput-member hashes. No scientific replay,as no experimental changes;integrity is not new application validation.
- Independent clean directory:no math, {clean['files']:,}files/{clean['copied_bytes']:,}bytes,copy hashes verified,existing core/validation/report/provenance workflow exit0. Manifest records actual working files at copy time;later receipt-only edits are not another scientific test. Clean directory removed.
- OriginalPDF download3,115,137bytes within3works/8MiBcap;temporary PDF/text/image bytes{storage['temporary_raw_bytes_removed']:,} hash-checked and removed after provenance recorded. Own helpers/logs{storage['member_bytes']:,}bytes stored in{len(z):,}byte gzip/tar;decompressed every member before plaintext cleanup. No original fulltext redistribution.
- Officialmath clean/pinned andChinesecharter hash unchanged. NoGitHubwrite/push;lastverifiedpublicf0c3ddc remains separate. Daily local commits,meaningful milestone publication batches.

No numerical progress is invented from reading. Counts remain53readfamilies/48current-source drafts/1,294labelled plus2unlabelledresults,43candidates/13checks/13distincthypotheses/5narrowly supported/8adverse,completefamilies/fullhistory/humans/secondprovider/pilots0. WP101F198 has only README/inventory read;actual bodies/formal/history pending,then requiredretro036.
''')
c=json.loads((R/'state/checkpoint.json').read_text());c['saved_at']=now;c['storage_receipt']='reports/reproducibility/20261023-critical-history/storage.json';c['recovery_observation'].update(checkpoint_core_check='68core14impact/fullcanonical-sourceFKgates/wholeJSONGraphML/15archives267members/no-mathclean exit0;ownhelperscompressed/decompressedverified;temporaryrootremoved',research_processes_observation='AllWP100core/QA/no-math sessions terminal;no scientific run or preview started');write('state/checkpoint.json',c)
print(json.dumps({'clean_files':clean['files'],'clean_bytes':clean['copied_bytes'],'raw_removed':storage['temporary_raw_bytes_removed'],'own_compressed':len(z),'temp_removed':not T.exists(),'github_push':False}))
