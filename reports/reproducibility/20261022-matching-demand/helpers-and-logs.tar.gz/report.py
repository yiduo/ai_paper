from pathlib import Path
import json
r=Path('/Users/smzdm/projects/ai_paper')
p=r/'reports/F113-counting-demand.md';p.write_text('''# F113：实际计数需求、旧基线与光子标定联系

2026-10-22，WP091／GEN-20261022-087。规范记录见 CHECK-113-COUNT-DEMAND、XPL-113-DEMAND 和 [逐来源版本／读取范围台账](../data/provenance/demand/F-113-counting-demand-20261022.json)。本包实际核对三个原始来源项目，新增一条有明确条件的近类比候选 [APP-113-01](cards/APP-113-01.md)；没有数值应用运行、初检或有效线索升级。

## 实际需求与替换边界

| 原始来源 | 实际读到的接口／需求 | F113 可用范围与限制 |
| --- | --- | --- |
| Graphillion，固定 e21b0928 | Python 源码的 perfect_matchings、f_factors、精确 cardinality 和真实测试调用；缺少 f(v) 默认为零，可指定额外 graphset 筛选 | 无权简单宿主的纯匹配／指定度对象有直接对应；近似计数不能无提示替换精确整数或任意集合筛选。顶点／孤点与宿主转换须单独核验，后端未构建或运行 |
| The Walrus，固定 54b1062e | 实际 hafnian 分派、Glynn／递归路径、非负 Barvinok determinant 均值、reference 实现及量子振幅／密度／采样调用 | 0/1 无权图计数子问题可映射；真实量子调用还涉及复权、重复指标、loop hafnian 和 Fock 截断，不能据此替换一般 GBS 采样 |
| Brádler 等人的 1712.06729v1 | 原论文明确用光子事件估计一般无向图的完美匹配数，选读公式 6、B1–B2 与扩展图的理想编码范围 | 是具体的近似图计数需求；只是理想事件标定，不证明物理噪声、硬件收益或一般量子模拟。完整图等原例已有闭式，不能作为新算法速度收益案例 |

Graphillion 的旧源文件和许可证从已有压缩证据复用，本次只追加匹配／factor 和 count 的实际读取范围及测试文件。The Walrus 的源代码按不可变提交固定；没有安装 Numba、Graphillion 或量子软件栈。源码分派优先于旧文档关于默认算法的措辞；reference 的一般数域算术、默认 complex128 路径及近似估计是不同数值契约。测试中的 10,000 次抽样和 20% 容差不是所有输入上的 epsilon／delta 证明，也没有在本机重跑。

## 一条具体的待定联系

对于 2m 顶点简单无权图的 0/1 邻接矩阵 A，设 C=#PM(G)=haf(A)。[2017 原始论文](https://arxiv.org/pdf/1712.06729v1)公式 6／B1 给出双份图编码下理想的全单光子事件概率 p=K C²，其中 K=c^(2m)·sqrt(det(I-c²A²))，且 c 必须满足正性与谱约束。两张原 PDF 公式页像素实际查看，版本／SHA 单列；没有审核整篇光学证明或其效率主张。

APP-113-01 保留“用有相对误差保证的经典图计数器做该事件的标定基线”的具体连接。计数相对误差 epsilon 经平方给出至多 2epsilon+epsilon² 的相对贡献；前因子 K 的认证误差须另行预算。该组合是选定接口的初等应用推断，不是新的数学定理，也不是已经写好或运行的计算器。源定理选定入口 B、光学关系选段 C，完整链 unknown，模型假设单独标记。预测、条件计划、反对／辩护自查及重访条件均在卡片中。

必须与真正的旧计数算法比较：Graphillion 表示集的精确计数、Walrus 的 hafnian 及非负估计器；二部、平面、小耳数或已知结构输入还应使用对应更强旧法。不能只比较枚举全部匹配或找到一个匹配的存在性算法。非结构化代表性请求、可运行新构造、公平预算和较大实例的独立裁判尚未建立，因此候选不增加初检计数。

## 字面算法的具体成本障碍

第一篇源文 1596／2252／2285／2431 行分别定义 L=(10⁴ND)^100、q=32L、M=Tq²+q 及固定 s(xi) 步。对于进入一般副本采样分支且 N、D 为正整数的输入，L≥10^400，q≥32·10^400；由 s≥20LM、M≥q 得 s≥640·10^800。即便不把全部副本显式存储，按原规程逐步更新也远超本项目的有限预算。

这是对手稿规定规程的代数资格核查，不是运行计时、数值实验、定理反例，亦非所有可能实现／所有图计数算法的下界。空图／零计数或旧闭式分支不计这笔成本。压缩状态、跳步、改用更小常数或另一个采样器，仍须证明保持目标保证，不能直接用短 Monte Carlo 冒充原 FPRAS。候选保持待定和低即时执行优先级，不正式否定；本包不执行这个巨大规程。

## 图谱、质量与接续

新增 11 条规范记录、27 条显式关系，仅更新 F113 族分析的应用路由，旧版精确保留；其余 3,688 条旧规范、全部旧边及 1,246 条旧数学主张保持不变。新候选的证据分类在提交前改为 hypothesis，并保留其源内容检查分类草稿，避免把真实来源与应用假设混为一谈。覆盖台账和完整阅读证据不变：49 阅读族、43 全文草稿、1,123 标签结果＋2 无标签；F238 的 95 个部分绑定另列。现在 41 候选、13 初检／不同验证、5 限定支持／8 不利观察，完整族／谱系、人审和第二供应商仍零。

质量证据见 [复现目录](reproducibility/20261022-matching-demand/)。本次第一次核心校验拦下了前版档案的封装格式；旧节点内容原本精确保留，现已改为既有 schema 支持的 records 列表，未放宽验证器，失败收据保留。没有修改实验代码、原规格、输出或比较器；15 归档仍按原字节散列检查，无需为此重新跑昂贵科学实验。

下一 WP092 回到未读 F139 或未完整 F262，先按原文对象与完整手稿范围选择。选择理由是停止为已知巨大副本规程造一个不可用原型，保留实际应用映射，同时补未覆盖源文；完成后立即全局复盘033。`math/` 只读且版本未变，全部本包新增研究当前仅本地，公开快照仍以 state/publication.json 的远程实证为准。
''')
p=r/'NOTICE';p.write_text(p.read_text()+'''\nSelected matching-count source review (2026-10-22):\nNine unmodified source/license members are retained in\ndata/provenance/tools/matching-count-tools-20261022.json.gz.\nThe Walrus, Xanadu Quantum Technologies Inc., commit\n54b1062e2b6759ddc733ca6bf636df580ff94968, retains its original\nApache-2.0 license and source headers. Graphillion's new selected test\nfile and complete MIT notice are fixed at\ne21b0928fcacd955154032928044ea3ce2efee3c. Other Graphillion source\nbytes are reused from the existing quota-tree-tools-20261021 archive.\nNo solver was installed or executed and no transitive dependency audit\nis claimed. The 2017 GBS paper is cited by version, scope and hash;\nits full text and temporary formula-page images are not redistributed.\n''')
# Current headline counts change; dated previous package records remain as evidence.
p=r/'README.md';s=p.read_text().replace('已保存40条候选连接','已保存41条候选连接').replace('6155节点、16146关系、6106条规范来源注释（其中6096','6175节点、16201关系、6134条规范来源注释（其中6124').replace('覆盖372族和40候选','覆盖372族和41候选');s+='\n[F113真实计数接口与光子标定联系](reports/F113-counting-demand.md)：实际三来源核对产生一条待定近类比候选，字面副本采样成本不准入，没有运行或新增初检；旧精确／随机计数与一般量子采样边界分别保留。\n';p.write_text(s)
p=r/'README.en.md';s=p.read_text().replace('40 candidate connections','41 candidate connections');s+='\nThe [matching-count demand review](reports/F113-counting-demand.md) adds one conditional graph-probability calibration connection. The literal published replica schedule is not admitted for finite execution. No new preliminary check or general Gaussian-boson-sampling claim is counted.\n';p.write_text(s)
p=r/'PROGRESS.en.md';s=p.read_text().replace('after WP-090; one substantive package','after WP-091; two substantive packages').replace('| 40/500 |','| 41/500 |').replace('6,155 nodes; 16,146 relations; 6,106 canonical citation annotations (6,096','6,175 nodes; 16,201 relations; 6,134 canonical citation annotations (6,124');start=s.index('WP-091 will qualify',s.index('## Next research package'));end=s.index('\nHuman review',start);s=s[:start]+'''WP-091 qualified selected actual Graphillion counting/factor APIs, Walrus hafnian and quantum callers, and the original 2017 graph-count proposal. It adds one conditional connection for ideal graph-event calibration, with an explicit unestablished practical implementation. The literal source replica schedule requires astronomical prescribed update counts in its generic branch. This is a source-cost admission finding, not an experiment, theorem refutation, or lower bound against all algorithms. No solver was installed and no application check was added. See [demand and limits](reports/F113-counting-demand.md).

WP-092 returns to source coverage outside adjacent counting work, selecting F139 or the incomplete F262 after inspecting actual object and manuscript scope. Global retrospective 033 is due immediately after that package, or earlier major evidence.
''' +s[end:];s=s.replace('WP-090 and this updated local progress document','WP-090–WP-091 and this updated local progress document');p.write_text(s)
p=r/'docs/roadmap.md';s=p.read_text().replace('四十候选；480次十域尝试及十七项需求反查不等于497候选','四十一候选；480次十域尝试及十八项需求反查不等于498候选');s+='\nWP091实际核对Graphillion／Walrus／2017图计数原文三来源，建立一条具体光子事件标定近类比候选，字面副本规程因巨大固定步数不准入；41候选、13初检不变，无运行。复盘计数2，下一WP092回未读F139或不完整F262，之后立即复盘033；不得把旧小图公式复算当新初检。\n';p.write_text(s)
p=r/'state/status.md';s=p.read_text();head,tail=s.split('\n\n四十候选',1);head=head.replace('6155节点、16146关系','6175节点、16201关系').replace('6106条来源注释（其中6096','6134条来源注释（其中6124').replace('十七项公开需求反查不等于497候选','十八项公开需求反查不等于498候选');s=head+'\n\n四十一候选'+tail;s+='\nWP091完成实际三来源计数资格：Graphillion固定源与真实测试、Walrus54b1062实际计数／量子调用、1712.06729v1选段与两公式像素。新增待定APP11301理想光子事件经典标定；一般复权／loop／重复指标GBS不适用。原字面副本规程的固定q／s巨大，不启动伪实现或小图校准实验。11新规范27边，旧ANALYSISF113前版及新候选分类草稿保留，3688其他旧规范／所有旧边和旧数学主张不变。当前41候选13初检，49阅读43全文草稿不变。下一WP092补非相邻族源文，复盘计数2，完成后立即033；新增本地科学包尚未推送。\n';p.write_text(s)
print('Report, attribution and bilingual current counts updated;no application check asserted.')
