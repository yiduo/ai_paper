from pathlib import Path
import json,gzip,hashlib,datetime
r=Path('/Users/smzdm/projects/ai_paper');sha=lambda b:hashlib.sha256(b).hexdigest();rows=[]
for p in sorted((r/'experiments/runs').glob('*/manifest.json')):
 m=json.loads(p.read_text())
 for name,want in m['outputs'].items():assert sha((p.parent/name).read_bytes())==want,(p,name)
 for name,info in m['compressed_payloads'].items():
  raw=gzip.decompress((p.parent/name).read_bytes());assert sha(raw)==info['uncompressed_sha256'];json.loads(raw);assert not(p.parent/info['uncompressed_name']).exists()
 snapshot=json.loads(gzip.decompress((p.parent/m['source_snapshot']).read_bytes()));assert set(snapshot)==set(m['inputs'])
 for name,want in m['inputs'].items():assert sha(snapshot[name].encode())==want,(p,name)
 rows.append(dict(run_id=m['run_id'],outputs_verified=len(m['outputs']),snapshot_members_verified=len(snapshot),compressed_payloads_verified=len(m['compressed_payloads'])))
assert len(rows)==15;out=r/'reports/reproducibility/20261022-matching-demand/archive-integrity.json';out.write_text(json.dumps(dict(recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),archives=rows,total_archives=15,plaintext_created=False,new_application_run=False),indent=2)+'\n');print('15 archives verified with all outputs, snapshot members, and raw/summary roundtrips; no extraction plaintext.')
