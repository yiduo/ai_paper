from pathlib import Path
import urllib.request,json,hashlib,gzip,datetime
r=Path('/Users/smzdm/projects/ai_paper');t=Path('/private/tmp/ai-paper-F113-demand');meta={};budget=0
ua={'User-Agent':'ai-paper-source-review','Accept':'application/vnd.github+json'}
def get(url,name):
 global budget
 with urllib.request.urlopen(urllib.request.Request(url,headers=ua),timeout=35) as q:b=q.read(4000001)
 assert len(b)<=4000000;budget+=len(b);assert budget<10000000
 (t/name).write_bytes(b);meta[name]=dict(url=url,sha256=hashlib.sha256(b).hexdigest(),bytes=len(b));return b
archive=r/'data/provenance/demand/quota-tree-tools-20261021.json.gz';d=json.loads(gzip.decompress(archive.read_bytes()));print('reusearchivekeys',list(d))
# This archive is already project-authorized MIT source evidence; do not redownload unchanged files.
print(str(d)[:350])
w=json.loads(get('https://api.github.com/repos/XanaduAI/thewalrus/commits/master','walrus-commit.json'));wc=w['sha'];print('walruscommit',wc)
for repo,commit,label in [('XanaduAI/thewalrus',wc,'walrus'),('graphillion/graphillion','e21b0928fcacd955154032928044ea3ce2efee3c','graphillion')]:
 tree=json.loads(get('https://api.github.com/repos/'+repo+'/git/trees/'+commit+'?recursive=1',label+'-tree.json'));paths=[v['path'] for v in tree['tree']];print(label,[p for p in paths if any(x in p.lower() for x in ['licen','graphset','hafnian','algorithm','fock_tensor'])][:45])
 if label=='walrus':
  for path in ['thewalrus/_hafnian.py','thewalrus/reference.py','thewalrus/samples.py','thewalrus/quantum/fock_tensors.py','docs/algorithms.rst','LICENSE']:
   assert path in paths,path;get('https://raw.githubusercontent.com/'+repo+'/'+commit+'/'+path,'walrus-'+path.replace('/','__'))
get('https://arxiv.org/pdf/1712.06729v1','GBS2017v1.pdf')
(t/'acquisitions.json').write_text(json.dumps(dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),new_bytes=budget,walrus_commit=wc,graphillion_commit='e21b0928fcacd955154032928044ea3ce2efee3c',sources=meta),indent=2)+'\n')
print('newbytes',budget)
