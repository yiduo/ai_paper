from pathlib import Path
import urllib.request,json,hashlib
p=Path('/private/tmp/ai-paper-F113-demand');meta=json.loads((p/'acquisitions.json').read_text());files=[('graphillion/graphillion',meta['graphillion_commit'],'graphillion/test/graphset.py','graphillion-test.py'),('XanaduAI/thewalrus',meta['walrus_commit'],'thewalrus/tests/test_hafnian_approx.py','walrus-test-approx.py')]
for repo,rev,path,name in files:
 u='https://raw.githubusercontent.com/'+repo+'/'+rev+'/'+path
 with urllib.request.urlopen(u,timeout=35) as s:b=s.read(4000001)
 assert len(b)<=4000000;meta['new_bytes']+=len(b);assert meta['new_bytes']<10000000;(p/name).write_bytes(b);meta['sources'][name]=dict(url=u,sha256=hashlib.sha256(b).hexdigest(),bytes=len(b));print(name,len(b))
(p/'acquisitions.json').write_text(json.dumps(meta,indent=2)+'\n')
