from pathlib import Path
import json,gzip,hashlib
r=Path('/Users/smzdm/projects/ai_paper');t=Path('/private/tmp/ai-paper-F113-demand');o=r/'reports/reproducibility/20261022-matching-demand';p=r/'data/graph/history/GEN087-count-demand-before.json.gz'
(o/'prior-wrapper-before-repair.json.gz').write_bytes(p.read_bytes());(o/'core-prior-wrapper-failure.log.gz').write_bytes(gzip.compress((t/'core.log').read_bytes(),mtime=0))
d=json.loads(gzip.decompress(p.read_bytes()));assert list(d)==['ANALYSIS-F-113'];payload=json.dumps(dict(records=list(d.values()),reason='ExactbaseversionbeforeWP091demand/candidatefollowup'),ensure_ascii=False,sort_keys=True).encode();p.write_bytes(gzip.compress(payload,mtime=0));assert json.loads(gzip.decompress(p.read_bytes()))['records'][0]==d['ANALYSIS-F-113']
p=r/'data/graph/nodes.jsonl';lines=[]
for l in p.read_text().splitlines():
 n=json.loads(l)
 if n['id']=='ANALYSIS-F-113':n['properties']['previous_version']['sha256_uncompressed']=hashlib.sha256(payload).hexdigest();l=json.dumps(n,ensure_ascii=False,sort_keys=True)
 lines.append(l)
p.write_text('\n'.join(lines)+'\n')
p=t/'integrity.py';s=p.read_text().replace("assert prior=={k:json.loads(old[k]) for k in changed}","assert prior['records']==[json.loads(old[k]) for k in changed]");p.write_text(s)
p=t/'curate.py';s=p.read_text().replace("priorblob=json.dumps(priors,ensure_ascii=False,sort_keys=True).encode()","priorblob=json.dumps(dict(records=list(priors.values()),reason='ExactbaseversionbeforeWP091demand/candidatefollowup'),ensure_ascii=False,sort_keys=True).encode()").replace("assert json.loads(gzip.decompress(parc.read_bytes()))==priors","assert json.loads(gzip.decompress(parc.read_bytes()))['records']==list(priors.values())");p.write_text(s)
print('Corrected prior archive wrapper to supported records list;exact old node preserved;validator unchanged;failure retained.')
