from pathlib import Path
import json,gzip,hashlib,datetime
r=Path('/Users/smzdm/projects/ai_paper');p=r/'data/graph/nodes.jsonl';ls=p.read_text().splitlines();rows=[json.loads(l) for l in ls];old=next(n for n in rows if n['id']=='APP-113-01');assert old['version']==1 and old['evidence_status']=='source_content_checked'
raw=json.dumps(old,ensure_ascii=False,sort_keys=True).encode();a=r/'data/graph/history/GEN087-candidate-classification-before.json.gz';a.write_bytes(gzip.compress(raw,mtime=0));assert json.loads(gzip.decompress(a.read_bytes()))==old
n=dict(old);n['properties']=dict(old['properties']);n.update(version=2,evidence_status='hypothesis',updated_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),prior_version_archive=str(a.relative_to(r)));n['properties']['previous_version']=dict(path=str(a.relative_to(r)),sha256_uncompressed=hashlib.sha256(raw).hexdigest(),reason='Classify the new untested candidate explicitly as model hypothesis;source-content checks apply to its cited inputs,not application truth');n['properties']['revision_generation_id']='GEN-20261022-087'
for i,x in enumerate(rows):
 if x['id']==n['id']:ls[i]=json.dumps(n,ensure_ascii=False,sort_keys=True)
p.write_text('\n'.join(ls)+'\n')
s=Path('/private/tmp/ai-paper-F113-demand/curate.py');text=s.read_text().replace("evidence_status='source_content_checked',properties=", "evidence_status=('hypothesis' if kind=='connection' else 'source_content_checked'),properties=");s.write_text(text)
s=r/'reports/reproducibility/20261022-matching-demand/curation-summary.json';d=json.loads(s.read_text());d['new_candidate_classification_prior_preserved']=True;s.write_text(json.dumps(d,indent=2)+'\n')
print('New candidate explicitly labelled hypothesis;exact prior version1 retained;no application result/claim grade changed.')
