from pathlib import Path
import json,gzip,hashlib,datetime
r=Path('/Users/smzdm/projects/ai_paper');p=r/'data/graph/nodes.jsonl';lines=p.read_text().splitlines();old=next(json.loads(l) for l in lines if json.loads(l)['id']=='APP-113-01');assert old['version']==2
raw=json.dumps(old,ensure_ascii=False,sort_keys=True).encode();arc=r/'data/graph/history/GEN087-candidate-timing-before.json.gz';arc.write_bytes(gzip.compress(raw,mtime=0));assert json.loads(gzip.decompress(arc.read_bytes()))==old
q=dict(old);q['properties']=dict(old['properties']);props=q['properties'];q.update(version=3,updated_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),prior_version_archive=str(arc.relative_to(r)));props['previous_version']=dict(path=str(arc.relative_to(r)),sha256_uncompressed=hashlib.sha256(raw).hexdigest(),reason='Correct the opinion timing prefix for the existing renderer:source review is complete but no experiment has occurred. Clarify prose without changing hypothesis,conditions or results.')
props['opposition']=dict(old['properties']['opposition'],timing='pre-experiment; after selected source/cost review; not isolated',text='原手稿字面副本规程的固定步数巨大，尚无可运行的新计数器。旧精确算法、结构化公式或随机估计可能已足够。无权图计数不能替代复权量子采样或物理噪声模型。')
props['defense']=dict(old['properties']['defense'],timing='pre-experiment; after selected source/cost review; not isolated',text='原始应用确实需要简单无权图的匹配数。计数相对误差可以传到理想事件概率，前因子误差另行认证；因此具体连接值得保留，执行前仍须解决构造与成本缺口。')
props['source_claim_grade']='选定FPRAS入口局部B；选读光学关系C；完整依赖链未知'
props['resources']='当前不准入原型或数值运行，不安装量子软件栈。先提供有保证且可运行的计数器、独立裁判和公平完整成本基线，再冻结输入与预算；未来输出和源码快照必须压缩并核验散列。'
props['owner']='OpenAI 当前会话；人工负责人未指定'
props['priority_reason']='保留真实图计数到事件标定的具体映射；字面规程成本不准入且强旧基线已存在，近期执行优先级低。'
props['revisit_when']='出现保持原保证的实用计数实现、代表性实际请求及独立裁判后，先登记公平预算与规格再执行。不得运行巨大字面规程，或把未证明的短链当作原FPRAS。'
props['limitations']=['尚无可运行的F113计数器；原字面规程的巨大固定副本数／步数不准入','减少步数、副本或改用跳步实现，必须另证保持原保证','Graphillion的精确整数及额外集合约束不能直接替换成无约束近似计数','一般Walrus量子调用中的复权、重复指标与loop hafnian不在本映射内','光学关系只选读原文，完整历史、证明和人审仍缺','没有硬件标定数据、已准入的大实例独立裁判、冻结的数值规格或应用收益']
for i,l in enumerate(lines):
 if json.loads(l)['id']==q['id']:lines[i]=json.dumps(q,ensure_ascii=False,sort_keys=True)
p.write_text('\n'.join(lines)+'\n')
o=r/'reports/reproducibility/20261022-matching-demand';(o/'card-timing-before.txt.gz').write_bytes(gzip.compress((r/'reports/cards/APP-113-01.md').read_bytes(),mtime=0))
s=o/'curation-summary.json';d=json.loads(s.read_text());d['candidate_classification_and_timing_priors']=2;s.write_text(json.dumps(d,indent=2)+'\n')
print('Candidate v3 keeps hypothesis/results;true pre-experiment timing rendered explicitly;v1/v2 exact priors retained.')
