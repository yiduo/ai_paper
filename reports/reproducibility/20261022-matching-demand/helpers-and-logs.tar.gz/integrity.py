from pathlib import Path
import json,gzip,hashlib,subprocess,sys,datetime
r=Path('/Users/smzdm/projects/ai_paper');sys.path.insert(0,str(r/'src'))
from ai_value.graph import load,impact_report,theoretical_grade
sha=lambda b:hashlib.sha256(b).hexdigest();o=r/'reports/reproducibility/20261022-matching-demand'
oldlines=subprocess.check_output(['git','show','HEAD:data/graph/nodes.jsonl'],cwd=r).decode().splitlines();old={json.loads(l)['id']:l for l in oldlines};newlines=(r/'data/graph/nodes.jsonl').read_text().splitlines();canon={json.loads(l)['id']:json.loads(l) for l in newlines};newraw={json.loads(l)['id']:l for l in newlines}
assert len(old)==3689 and len(canon)==3700
changed=[k for k in old if old[k]!=newraw[k]];assert changed==['ANALYSIS-F-113']
prior=json.loads(gzip.decompress((r/'data/graph/history/GEN087-count-demand-before.json.gz').read_bytes()));assert prior['records']==[json.loads(old[k]) for k in changed]
assert (r/'data/graph/edges.jsonl').read_bytes().startswith(subprocess.check_output(['git','show','HEAD:data/graph/edges.jsonl'],cwd=r))
for path in ['data/graph/reading_coverage.json','data/provenance/readings/F-113.json','configs/research.json']:
 assert (r/path).read_bytes()==subprocess.check_output(['git','show','HEAD:'+path],cwd=r),path
for directory in ['src','tests','configs','experiments/runs']:
 assert not subprocess.check_output(['git','diff','--name-only','HEAD','--',directory],cwd=r),directory
nodes,edges=load(r);app=nodes['APP-113-01']['properties'];assert app['application_result']=='待定' and app['workflow']=='候选' and not app['run_ids'] and not app['summary']['initial_check_eligible'];assert theoretical_grade(nodes,edges,'APP-113-01')=='unknown'
assert len([n for n in canon.values() if n['kind']=='connection'])==41
oldclaims={k:json.loads(v) for k,v in old.items() if json.loads(v)['kind']=='claim'};assert all(canon[k]==v for k,v in oldclaims.items())
local=external=0
for n in canon.values():
 for s in n['sources']:
  if 'path' in s:assert sha((r/s['path']).read_bytes())==s['sha256'],(n['id'],s['path']);local+=1
  else:external+=1
# These are data-routing checks,not numerical experiments or mathematical validity tests.
cases=[]
for seed,yes,no in [
('CLM-113-F-THM-MAIN',['PART-113-CALIBRATION-MAP','APP-113-01'],['PART-113-STRONG-OLD-COUNTERS','APP-115-01','APP-120-01']),
('CLM-113-F-THM-BAG-SAMPLER',['PART-113-LITERAL-BUDGET-GAP','APP-113-01','XPL-113-DEMAND'],['CLM-113-E-ENT-MAIN','CLM-113-E-THM-MAIN']),
('PART-113-LITERAL-BUDGET-GAP',['APP-113-01','XPL-113-DEMAND'],['CLM-113-F-THM-MAIN','CLM-113-F-THM-BAG-SAMPLER','CLM-113-E-ENT-MAIN']),
('LIT-113-GBS2017',['PART-113-CALIBRATION-MAP','PROB-113-GBS-CALIBRATION','APP-113-01'],['CLM-113-F-THM-MAIN','CLM-113-E-ENT-MAIN','PART-113-STRONG-OLD-COUNTERS']),
('LIT-113-WALRUS-COUNT',['PART-113-STRONG-OLD-COUNTERS'],['APP-113-01','CLM-113-F-THM-MAIN','PART-113-CALIBRATION-MAP']),
('LIT-113-GRAPHILLION-COUNT',['PART-113-STRONG-OLD-COUNTERS'],['APP-113-01','CLM-113-F-THM-MAIN','PART-113-CALIBRATION-MAP']),
('CHECK-113-COUNT-DEMAND',[],['APP-113-01','CLM-113-F-THM-MAIN','PART-113-LITERAL-BUDGET-GAP']),
('PART-113-CALIBRATION-MAP',['APP-113-01'],['CLM-113-F-THM-MAIN','CLM-113-E-ENT-MAIN','PART-113-STRONG-OLD-COUNTERS'])]:
 assert all(k in nodes for k in [seed]+yes+no)
 a=set(impact_report(nodes,edges,{seed})['affected']);assert set(yes)<=a,(seed,yes);assert not set(no)&a,(seed,set(no)&a);cases.append(dict(seed=seed,required=yes,excluded=no,affected=sorted(a)))
ledger=json.loads((r/'data/provenance/demand/F-113-counting-demand-20261022.json').read_text());a=ledger['source_archive'];p=r/a['path'];assert sha(p.read_bytes())==a['sha256'];raw=gzip.decompress(p.read_bytes());assert sha(raw)==a['uncompressed_sha256'];files=json.loads(raw)['files'];assert len(files)==9
for name,info in ledger['sources'].items():
 if name.startswith('reused-'):continue
 assert sha(files[name].encode())==info['sha256']
assert ledger['conclusions']['new_initial_check']==0 and not ledger['conclusions']['new_numerical_run']
q=dict(recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),canonical_total=len(canon),full_graph_nodes=len(nodes),full_graph_edges=len(edges),new_canonical=11,exact_prior_versions=1,old_canonical_unchanged=3688,all_old_edges_exact=True,coverage_and_reading_ledger_unchanged=True,all_old_claims_unchanged=len(oldclaims),canonical_citations=local+external,local_source_hashes_verified=local,external_annotations=external,impact_cases=cases,new_candidate=1,candidates_total=41,new_initial_check=0,new_application_run=False,new_licensed_members=9,compressed_source_bytes=p.stat().st_size,full_family_and_human_gates_unchanged=True)
(o/'integrity.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps({k:v for k,v in q.items() if k!='impact_cases'}))
