from pathlib import Path
import json,gzip,hashlib,datetime,subprocess
R=Path('/Users/smzdm/projects/ai_paper');O=R/'reports/reproducibility/20261023-thin-trees';p=R/'data/graph/nodes.jsonl';raw=p.read_bytes();old=subprocess.check_output(['git','show','e4d5935:data/graph/nodes.jsonl'],cwd=R);assert raw.startswith(old);new=[json.loads(l) for l in raw[len(old):].splitlines()];prior=[];count=0
for n in new:
 ss=[s for s in n['sources'] if 'url' in s and 'sha256' in s and s['sha256'] is None]
 if not ss:continue
 prior.append(json.loads(json.dumps(n)))
 for s in ss:del s['sha256'];count+=1
 n['version']=3;n['properties']['unknown_hash_encoding_correction']='Omit unavailable external-byte sha256 instead of null;content_checked false retained,no bytes or mathematical scope fabricated;exact previous object archived'
payload=(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reason':'Core provenance audit cannot concatenate null hash;use existing absent-hash encoding for genuinely unacquired bytes without changing old records or research facts','previous_exact_objects':prior,'changed_nodes':len(prior),'unknown_hash_fields':count},ensure_ascii=False,indent=2)+'\n').encode();z=gzip.compress(payload,mtime=0);assert gzip.decompress(z)==payload;(O/'unknown-hash-encoding-correction.json.gz').write_bytes(z);p.write_bytes(old+b''.join((json.dumps(n,ensure_ascii=False,sort_keys=True)+'\n').encode() for n in new));print('Corrected',count,'null unknown-byte fields in',len(prior),'new nodes;4412 oldlines exact')
