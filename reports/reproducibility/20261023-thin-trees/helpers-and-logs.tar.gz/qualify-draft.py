"""Explicit first-draft alias and relation corrections before acceptance; keep exact prior bytes."""
from pathlib import Path
import json,gzip,hashlib,datetime,subprocess
R=Path('/Users/smzdm/projects/ai_paper');O=R/'reports/reproducibility/20261023-thin-trees';BASE='e4d5935';lp=R/'data/provenance/readings/F-174.json'
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(p,j):p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
def archive(n,b):
 z=gzip.compress(b,mtime=0);assert gzip.decompress(z)==b;(O/n).write_bytes(z)
raw=(R/'data/graph/nodes.jsonl').read_bytes();eraw=(R/'data/graph/edges.jsonl').read_bytes();old=subprocess.check_output(['git','show',BASE+':data/graph/nodes.jsonl'],cwd=R);olde=subprocess.check_output(['git','show',BASE+':data/graph/edges.jsonl'],cwd=R);assert raw.startswith(old) and eraw.startswith(olde)
archive('unaccepted-first-draft-ledger.json.gz',lp.read_bytes());archive('unaccepted-first-draft-new-nodes.jsonl.gz',raw[len(old):]);archive('unaccepted-first-draft-new-edges.jsonl.gz',eraw[len(olde):])
j=json.loads(lp.read_bytes());pairs={'AOG':'AnariOveisGharan2015','MSS':'MarcusSpielmanSrivastava2015','NashWilliams':'NashWilliams1961','Tutte':'Tutte1961','Goddyn':'Goddyn2004','Asadpour':'AsadpourEtAl2017','AsadpourSODA':'AsadpourEtAl2010','KleinOlverYeoh':'KleinOlverYeoh2026'};refs=j['historical_references_by_key'];rename={refs[a]:refs[b] for a,b in pairs.items()};priorrefs=dict(refs)
for a,b in pairs.items():refs[a]=refs[b]
j.update(version=2,draft_correction={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reason':'Cross-manuscript bibliography aliases identify eight same works. Merge aliases,keep original attribution locators and distinguish publication metadata from inspected arXiv bytes. Lexically extracted source references are references,not asserted proof premises;only manually qualified dependencies propagate invalidation. Exact first draft archived before correction.','aliases':pairs,'old_GL S_identity':'GLS1988 exactDOI reused from LIT-114-DC4ADB604E;no inherited unread theorem scope'},historical_external_work_count=len(set(refs.values())-set(j['manuscript_ids'])),historical_unverified_external_work_ids=sorted(set(refs.values())-set(j['manuscript_ids'])-{o['node_id'] for o in j['historical_selected_originals']}))
j['historical_verified_keys']+=['AOG'];j['unread_root_body_keys']=[k for k in j['unread_root_body_keys'] if k!='AOG']
for m in j['readmes']:m['scope']='README18lines actually read;complete body reading independently recorded in per-file ranges'
j['gaps'].append('Dependency graph retains all observed result/citation references separately from manually qualified proof premises;remaining untyped proof closure is incomplete,not silently approved.')
put(lp,j);h=sha(lp.read_bytes());new=[json.loads(l) for l in raw[len(old):].splitlines()];byid={n['id']:n for n in new}
for a,b in pairs.items():
 n=byid[priorrefs[b]];alias=byid[priorrefs[a]];n['sources']+=alias['sources'];n['properties'].setdefault('bibliography_aliases',[]).append({'key':a,'metadata':alias['properties'],'status':'Same cited work,not publication-byte equivalence'})
new=[n for n in new if n['id'] not in rename]
for n in new:
 n['version']=2;n['properties']['draft_revision_reason']='Qualified bibliography alias identity and reference/dependency distinction;exact unaccepted draft retained'
 if n['kind']=='family_analysis':
  n['properties']['historical_references_by_key']=refs;n['properties']['historical_verified_keys']=j['historical_verified_keys'];n['properties']['gaps']=j['gaps']
 for s in n['sources']:
  if s.get('path')=='data/provenance/readings/F-174.json':s['sha256']=h
 # Dedup exact duplicate annotations introduced by merging.
 n['sources']=list({json.dumps(s,sort_keys=True):s for s in n['sources']}.values())
newed=[];seen=set();refcount=0
for line in eraw[len(olde):].splitlines():
 e=json.loads(line)
 for key in ['source','target']:e[key]=rename.get(e[key],e[key])
 if e['source_locator'].startswith(('Actual source result/proof reference ','Actual source attribution ')):
  e['relation']='source_reference';e['source_locator']='Observed lexical reference,not automatically a required proof premise: '+e['source_locator'];refcount+=1
 e['id']='E-'+sha(f"{e['source']}|{e['relation']}|{e['target']}".encode())[:16].upper();e['version']=2
 if e['id'] not in seen:seen.add(e['id']);newed.append(e)
(R/'data/graph/nodes.jsonl').write_bytes(old+b''.join((json.dumps(n,ensure_ascii=False,sort_keys=True)+'\n').encode() for n in new));(R/'data/graph/edges.jsonl').write_bytes(olde+b''.join((json.dumps(e,ensure_ascii=False,sort_keys=True)+'\n').encode() for e in newed))
p=R/'state/reading-progress/F-174.json';q=json.loads(p.read_bytes());q['source_body_read']=True;put(p,q)
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'new_records':len(new),'new_explicit_edges':len(newed),'initial_draft_records':110,'same_work_aliases':pairs,'lexical_references_separated':refcount,'external_work_identities':j['historical_external_work_count'],'all4412oldlines_and_oldedges_exact':True,'old_current_source_record_hashes_recomputed':h,'reason':j['draft_correction']['reason']};archive('draft-qualification.json.gz',(json.dumps(receipt,indent=2)+'\n').encode());print(json.dumps(receipt))
