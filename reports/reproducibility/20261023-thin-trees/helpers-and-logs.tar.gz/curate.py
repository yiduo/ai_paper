from pathlib import Path
import json,gzip,re,sys,hashlib,datetime,subprocess
R=Path('/Users/smzdm/projects/ai_paper');T=Path('/private/tmp/ai-paper-WP105');O=R/'reports/reproducibility/20261023-thin-trees';O.mkdir(parents=True,exist_ok=True)
sys.path[:0]=[str(R/'src'),str(T)]
from ai_value.source_results import named_results
from ai_value.graph import validate
from facts import RESULTS,METHODS
NOW=datetime.datetime.now(datetime.timezone.utc).isoformat();UP='1581d4cbdd69a0faf34b2089614fe2a814316a6a';BASE='e4d5935cd5824cfb887e09ee028478f5a87e6830';GEN='GEN-20261023-102';F='F-174'
sha=lambda b:hashlib.sha256(b).hexdigest()
def enc(j):return (json.dumps(j,ensure_ascii=False,indent=2)+'\n').encode()
def write(p,j):p=R/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(enc(j))
def gz(p,j):
 b=enc(j);z=gzip.compress(b,mtime=0);assert gzip.decompress(z)==b;p=R/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z)
def local(p,loc):return {'path':p,'locator':loc,'sha256':sha((R/p).read_bytes()),'commit':UP if p.startswith('math/') else None}
def cid(label):return 'CLM-174-'+re.sub('[^A-Za-z0-9]+','-',label).upper()
J=json.load(open(R/'state/reading-progress/F-174.json'));A=json.load(open(T/'history-acquisition.json'))
files=[f for m in J['manuscripts'] for f in m['files']];tex=[f['path'] for f in files if f['path'].endswith('.tex')]
assert len(files)==34 and len(tex)==32 and all(f['actually_read'] and sha((R/f['path']).read_bytes())==f['sha256'] and J['actual_read_ranges'][f['path']]==[[1,f['lines']]] for f in files)
assert sum(f['lines'] for f in files if f['path'].endswith('.tex'))==7384 and sum(f['lines'] for f in files if f['path'].endswith('.bib'))==582
rows=[];bind={p:{} for p in tex};alllabels=set()
for m in J['manuscripts']:
 for f in m['files']:
  p=f['path']
  if not p.endswith('.tex'):continue
  s=(R/p).read_text()
  for x in named_results(s):
   label=x['label'];assert label in RESULTS and label not in alllabels;alllabels.add(label);statement,condition=RESULTS[label];r={'id':cid(label),'label':label,'path':p,'manuscript_id':m['id'],'statement_lines':[s[:x['start']].count('\n')+1,s[:x['statement_end']].count('\n')+1],'statement':statement,'conditions':[condition],'constants_and_constructions':[condition],'source_claim_grade':'B' if label in ['thm:main','thm:tt-algorithm'] else 'C','dependency_chain_grade':'unknown'};rows.append(r);bind[p][label]=r['id']
assert len(rows)==len(RESULTS)==58,(len(rows),len(RESULTS),set(RESULTS)-alllabels)
# Actual local includes, not a TeX interpreter. All read modules also retained even if no include is found.
includes=[]
for p in tex:
 s=re.sub(r'(?<!\\)%[^\n]*','',(R/p).read_text());m=next(m for m in J['manuscripts'] if p in [f['path'] for f in m['files']]);root=R/m['readme']['path'];root=root.parent/'build/source'
 for v in re.findall(r'\\(?:input|include)\{([^}]+)\}',s):
  target=(root/v).with_suffix('.tex');assert target.exists() and str(target.relative_to(R)) in tex,(p,v);includes.append({'source':p,'target':str(target.relative_to(R))})
# Bib metadata only: retain exact body locator, no bibliography-only scope credit.
def value(block,key):
 mt=re.search(r'(?im)^\s*'+key+r'\s*=\s*',block)
 if not mt:return None
 start=mt.end();ch=block[start]
 if ch=='{':
  dep=1;i=start+1
  while i<len(block) and dep:
   if block[i]=='{' and (i==0 or block[i-1]!='\\'):dep+=1
   if block[i]=='}' and (i==0 or block[i-1]!='\\'):dep-=1
   i+=1
  return block[start+1:i-1]
 return block[start:].split(',')[0].strip().strip('"')
bibs={};bibpaths={};rawbibs={}
for f in files:
 if not f['path'].endswith('.bib'):continue
 text=(R/f['path']).read_text();matches=list(re.finditer(r'(?m)^@\w+\{([^,]+),',text))
 for i,mt in enumerate(matches):
  key=mt[1];block=text[mt.start():matches[i+1].start() if i+1<len(matches) else len(text)];entry={k:value(block,k) for k in ['title','author','year','doi','url','eprint']}
  # Two source versions may include distinct notes and harmless metadata formatting.
  bibs.setdefault(key,entry);bibpaths.setdefault(key,[]).append(f['path']);rawbibs.setdefault(key,[]).append(block)
refs={k:'LIT-174-'+k.upper() for k in bibs};refs['GLS1988']='LIT-114-DC4ADB604E';refs['ThinTreesCompanion']='P-402de1fcb7f04b26';refs['ConstructiveThinTreesCompanion']='P-df23ae02b1b76555'
refs={k:v for k,v in refs.items() if k in bibs}
oldspec=[('EzeunalaJiang2026','EJ2026v1','arXiv2609.17266v1 submitted2026-09-15','Extracted lines65-150,180-360,365-605,805-995;Theorem1.1,Lemmas2.1/3.1/3.2,Section3.2,Section4.1 includingClaim4.1,andselectedLemma4.5 proof. PDF5,9,10 pixels viewed.','Same rational rank-one signing contract already claimed with13;current manuscript supplies40,c384 and quantitative rational mesh/oracle details. Selected original proof not complete;remaining local descent and root covariance proof not independently closed.'),('AnariOveisGharan2015','AOG2015v4','arXiv1411.4613v4 revised2015-09-01','Extracted lines430-520;Theorems1.6/1.7,Corollary1.8,Theorem1.9 and surrounding input limits. PDF8/10 pixels viewed,printed6/8.','Old cut-preserving shortcut and polyloglog(n)/k thin-tree route already exists;k>=7log n,good-edge connectivity,nonalgorithmic convex program and explicit oracle condition retained. Full proof/hierarchy not read.'),('Bansal2024','Bansal2024','PublishedToC20(6),2024,23pages,DOI10.4086/toc.2024.v020a006','Extracted lines460-506;Theorem2.5 and covariance/range construction;PDF10 pixels viewed.','Old covariance output has range in subspace,diagonal<=1,trace>=zeta n,PSD upper eta diag;condition1/eta+zeta<=dimG/n. Theorem explicitly reusesBansalGarg2017Theorem6,whose original body remains unread.')]
olds=[]
for key,name,version,scope,meaning in oldspec:
 a=next(x for x in A['items'] if x['id']==name);assert a['status']=='acquired' and sha(Path(a['path']).read_bytes())==a['sha256'];olds.append({**a,'key':key,'node_id':refs[key],'version':version,'actually_read_selected_scope':scope,'verified_contract':meaning,'whole_work_and_recursive_history_complete':False})
assert A['total_downloaded_bytes']==1635535 and A['total_downloaded_bytes']<=A['bytes_cap'] and len(olds)<=4
pixels=[]
for name in ['EJ-p5','EJ-p9','EJ-p10','AOG-p8','AOG-p10','Bansal-p10']:
 p=T/(name+'.png');pixels.append({'image':str(p),'image_sha256':sha(p.read_bytes()),'pixels_actually_viewed':True,'scope':'Page labels refer to physical PDF page,not printed page;see selected scopes'})
formalpaths=['math/lean/docs/174.md','math/lean/ComparatorChallenges/StrongThinTree.json','math/lean/ComparatorChallenges/AlgorithmicThinTrees.json','math/lean/ComparatorChallenges/StrongThinTree.lean','math/lean/ComparatorChallenges/AlgorithmicThinTrees.lean','math/lean/OAI/Combinatorics/ThinTrees/Main.lean','math/lean/OAI/Combinatorics/ThinTrees/AlgorithmicMain.lean','math/lean/OAI/Combinatorics/ThinTrees/Model.lean','math/lean/OAI/Combinatorics/ThinTrees/Encoding/AlgorithmicMain.lean']
formal={'selected_files_actually_read':[{'path':p,'sha256':sha((R/p).read_bytes()),'lines':len((R/p).read_text().splitlines())} for p in formalpaths],'existence_registered_in_yaml':True,'algorithmic_yaml_exact_registration_found':False,'algorithmic_document_and_comparator_and_imported_solution_observed':True,'matching_main_claims':['thm:main','thm:tt-algorithm'],'auxiliary_claims_not_assigned_B':56,'challenge_sorry_scope':'The two ComparatorChallenges files have deliberate sorry statement placeholders;actual solution Main and Encoding/AlgorithmicMain contain proofs. This is not evidence of solution sorry or a passed Comparator.','local_lean_build':False,'comparator_run':False,'human_spec_review':False,'full_import_proof_reading':False,'fractional_rounding_formal_match_not_established':True,'assessment':'Two selected main scopes retain upstream B,not A;all full dependency grades unknown;existence n>=2 versus algorithm singleton n>=1 distinguished.'}
attempts=[('network routing','All-cut constrained spanning routing skeleton','thin-cheap source corollary could replace fractional all-cut design','Need actual workload,positive support,constants and total solver cost;MST zero hypothesis may suffice'),('quantum channels','Exact rational positive Choi/PSD certificate','Rational unweighted outer products avoid square-root extensions','Weighted LDL already supplies an exact certificate;no consumer requiring unweighted rational Kraus columns identified'),('machine learning','Spectral covariance sample pruning','Two-system split suggests shared sample selection','Graph cut guarantee is not general PSD spectral approximation;source rank-one signing already old'),('robotics','Resilient communication tree','All-cut relative load might select sparse links','Unweighted multigraph connectivity and nonnegative costs must be justified;no latency/control performance guarantee'),('energy','Power-grid topology planning','Simultaneous cut+cost support tree','Electrical PSD/dynamics stability is stronger than cut thinness;not supplied'),('biology','Sparse interaction network backbone','Graph cut skeleton','No mechanism making all-cut relative load a biological objective;no admissible caller'),('finance','Portfolio scenario reduction','Analogy to partition-preserving sparsification','Tree and cut structure absent;cost not equivalent to risk or PSD control'),('traffic','Road network simplification','One sparse connected tree','Directed routes,travel-time and capacity constraints not covered;old MST may match actual objective'),('language processing','Sparse attention or dependency tree','Rational signing of rank-one contributions','No typed graph/input/output bridge;all-cut theorem not attention quality bound'),('materials','Mechanical network sparsification','Retain tree while bounding cuts','Rigidity/stiffness requires spectral/geometric conditions not implied by source all-cut ratio')]
cross=[{'family':'F-114','comparison':'Degree/color quota trees versus all-cut thin trees','boundary':'Degree,arbitrary quota side constraints and every-cut ratio are distinct;F114 does not provide required full-cut premises;no candidate.'},{'family':'F-238','comparison':'Uniform random tree or random walk versus one deterministic cut-thin tree','boundary':'Distribution/mixing guarantee does not imply one output all cuts satisfies C/k;no transferred runtime benefit.'},{'family':'F-332','comparison':'Simultaneous operator-norm control versus frozen denoising losses','boundary':'Operator signing does not imply held-out denoising quality;prior adverse experiment unchanged;no new validation.'}]
gaps=['All two current source manuscripts32TeX7384+582Bib andtwoREADME18each actually read;58labelled result drafts and12method contracts are not full mathematical proof approval.','Only three historical originals read in specific retained scopes;all other root bodies and recursive inputs,including GLS exact oracle chapters,BansalGarg covariance proof,MSS/Barthe and remaining geometry history,unverified.','Selected Lean statements/solution entries statically compared;no full proof-import reading,no localLean/Comparator,no human specification review. Two main statementsB,other56C,full theory chainsunknown.','No actual implementation,finite numeric absolute constants,consumer contract,benchmark,candidate application card or experiment this package. Source thin-cheap corollary and EJ signing are existing source results,not project discoveries.','No mapped extra current manuscript in pinned F174 corpus;this does not establish all unavailable historical versions reviewed. Fullfamily/history/human/secondprovider/pilot remain incomplete.']
ledger={'family_id':F,'work_package':'WP-105','generation_id':GEN,'at':NOW,'base_commit':BASE,'upstream_commit':UP,'manuscript_ids':[m['id'] for m in J['manuscripts']],'read_files':files,'readmes':[m['readme'] for m in J['manuscripts']],'actual_read_ranges':J['actual_read_ranges'],'manual_file_reading_notes':J['reading_notes'],'source_sections':tex,'source_tex_lines':7384,'bibliography_lines':582,'include_links_checked':includes,'results':rows,'methods':[{'id':'PART-174-'+s,'input':i,'output':o,'conditions':c,'source_label':l} for s,i,o,l,c in METHODS],'historical_references_by_key':refs,'historical_selected_originals':olds,'historical_verified_keys':[o['key'] for o in olds],'unread_root_body_keys':[k for k in bibs if k not in {o['key'] for o in olds} and k not in ['ThinTreesCompanion','ConstructiveThinTreesCompanion']],'formal_status':formal,'actual_pdf_pixels':pixels,'acquisition':A,'domain_attempts':[{'domain':a,'problem':b,'possible_mapping':c,'judgment':d,'counts_as_new_candidate':False} for a,b,c,d in attempts],'cross_family_attempts':cross,'gaps':gaps,'source_decomposition_draft_complete':True,'full_family_complete':False,'historical_lineage_complete':False,'new_candidates':0,'new_initial_checks':0,'numeric_or_symbolic_run':False,'source_reuse_policy':'Third-party bodies and pixels temporary,do not publish;retain own paraphrases,hashes and locators only. Official math remains read-only and excluded.','github_push':False}
lp='data/provenance/readings/F-174.json';assert not (R/lp).exists();write(lp,ledger)
cfg='data/provenance/research-at-generation-102.json';(R/cfg).write_bytes((R/'configs/research.json').read_bytes());base=[local(lp,'Complete actual reading ranges and qualified source claims;not fullfamily/history/verification')]
raw=(R/'data/graph/nodes.jsonl').read_bytes();eraw=(R/'data/graph/edges.jsonl').read_bytes();assert len(raw.splitlines())==4412
ids={json.loads(l)['id'] for l in raw.splitlines()};eids={json.loads(l)['id'] for l in eraw.splitlines()};added=[];edges=[]
def node(i,k,p,ss=None,ev='source_content_checked'):
 assert i not in ids,i;ids.add(i);added.append({'id':i,'kind':k,'version':1,'created_at':NOW,'evidence_status':ev,'properties':{'family_ids':[F],'model_generation_id':GEN,'credibility':'unknown','dependency_closure_complete':False,**p},'sources':ss or base.copy()})
def edge(a,r,b,locator='Qualified source dependency or structural comparison,WP105',ev='source_content_checked'):
 i='E-'+sha(f'{a}|{r}|{b}'.encode())[:16].upper()
 if i in eids:return
 eids.add(i);edges.append({'id':i,'source':a,'relation':r,'target':b,'version':1,'created_at':NOW,'evidence_status':ev,'source_locator':locator,'source_commit':UP})
node(GEN,'generation',{'title':'F174 two current manuscripts,qualified Lean scopes and three selected old sources','provider':'OpenAI','model':'Current user-selected session;exact backend unknown','project_base_commit':BASE,'human_review':None,'independent_second_provider':None},base+[local(cfg,'Frozen local-first milestone publication policy')])
for k,b in bibs.items():
 if k in ['GLS1988','ThinTreesCompanion','ConstructiveThinTreesCompanion']:continue
 old=next((o for o in olds if o['key']==k),None);ss=[local(p,'Bibliography key '+k+';metadata only unless qualified selected original below') for p in bibpaths[k]]
 if old:ss+=base+[{'url':old['url'],'sha256':old['sha256'],'locator':old['version']+';'+old['actually_read_selected_scope'],'content_checked':True}]
 else:
  url=b.get('url') or ('https://doi.org/'+b['doi'] if b.get('doi') else 'https://arxiv.org/abs/'+b['eprint'] if b.get('eprint') else None)
  if url:ss+=[{'url':url,'sha256':None,'content_checked':False,'locator':'Source bibliography metadata;original body not read WP105'}]
 node(refs[k],'literature',{'title':b['title'] or k,'authors':b['author'],'year':b['year'],'doi':b['doi'],'url':b['url'],'bib_key':k,'retrieval_status':'selected_original_scope_actually_read' if old else 'bibliography_only_body_unread','verified_scope':old,'whole_original_proof_complete':False},ss,ev='source_content_checked' if old else 'source_claim')
for r in rows:
 ss=base+[local(r['path'],r['label']+' statement lines'+str(r['statement_lines']))]
 if r['label']=='thm:main':ss+=[local('math/lean/OAI/Combinatorics/ThinTrees/Main.lean','Actual proof endpoint strongThinTree;read statically,no build/Comparator')]
 if r['label']=='thm:tt-algorithm':ss+=[local('math/lean/OAI/Combinatorics/ThinTrees/Encoding/AlgorithmicMain.lean','Actual imported algorithmic_strong_thin_trees proof endpoint65-85;no build/Comparator')]
 node(r['id'],'claim',{'title':r['label'],'statement':r['statement'],'conditions':r['conditions'],'constants_and_constructions':r['constants_and_constructions'],'manuscript_id':r['manuscript_id'],'source_claim_grade':r['source_claim_grade'],'credibility':r['source_claim_grade'],'source_label':r['label'],'source_statement_lines':r['statement_lines'],'dependency_chain_grade':'unknown'},ss,ev='source_claim');edge(r['id'],'member_of',F)
# Complete-body source-attribution edges; distinguishes theorems from equations/definitions.
resultids={r['label']:r['id'] for r in rows}
for r in rows:
 text=(R/r['path']).read_text();starts=list(re.finditer(r'\\begin\{(?:theorem|lemma|proposition|corollary|verification)\}',text));end=next((mt.start() for mt in starts if mt.start()>text.find('\\label{'+r['label']+'}')),len(text));start=text.find('\\label{'+r['label']+'}');scope=text[start:end]
 for label in re.findall(r'\\(?:[cC]ref|ref|eqref)\{([^}]+)\}',scope):
  for label in label.split(','):
   if label.strip() in resultids and label.strip()!=r['label']:edge(r['id'],'depends_on',resultids[label.strip()],'Actual source result/proof reference '+label.strip())
 for keylist in re.findall(r'\\cite(?:\[[^\]]*\])?\{([^}]+)\}',scope):
  for key in keylist.split(','):
   key=key.strip()
   if key in refs:edge(r['id'],'depends_on',refs[key],'Actual source attribution '+key+';body scope limited as recorded')
# Main and unlabelled glue dependencies actually read outside theorem environments.
manual={'thm:main':['thm:extraction','prop:step','thm:packing'], 'thm:extraction':['lem:response','thm:fixedpoint','lem:packing-parts'], 'thm:hierarchy-power':['lem:hierarchy-dual','prop:hierarchy-bags','prop:hierarchy-compact','prop:hierarchy-assigned'], 'lem:response':['thm:hierarchy-power'], 'prop:step':['lem:auxiliary-representation','lem:projected-trace-packing','lemma:two-system-split','lem:resistance-order'], 'lemma:two-system-split':['thm:mss'], 'thm:mss':['lem:mss-expectation','lem:mss-selection','lem:mss-root-bound'], 'prop:hierarchy-assigned':['ha:pruning','ha:insertable-arrangement','ha:construction','ha:shrink-cost','ha:labeled-energy'], 'thm:tt-algorithm':['prop:ta-extraction','lem:ta-frame','lem:ta-signing','lem:ta-sparsification'], 'cor:ta-fractional-rounding':['thm:tt-algorithm'], 'lem:ta-signing':['lem:rational-psd','thm:rational-signing'], 'prop:ta-extraction':['lem:ta-continuation','lem:ta-separation','lem:ta-bits'], 'lem:ta-continuation':['prop:tg-response'], 'prop:tg-response':['thm:tg-hierarchy'], 'thm:tg-hierarchy':['tg:dual','tg:profiles','tg:transfer','prop:hierarchy-bags','prop:hierarchy-compact','prop:hierarchy-assigned']}
for label,deps in manual.items():
 for dep in deps:edge(cid(label),'depends_on',cid(dep),'Actual fully read argument dependency,including unlabelled assembly paragraphs')
for label,key in [('thm:rational-signing','EzeunalaJiang2026'),('thm:rational-signing','Bansal2024'),('thm:rational-signing','GLS1988'),('lem:ta-bits','GLS1988'),('lem:ta-separation','GLS1988'),('lem:ta-frame','Barthe1998'),('lem:ta-sparsification','Terao2023')]:edge(cid(label),'depends_on',refs[key],'Critical historical interface;selected scope does not close recursive proof')
for s,i,o,l,c in METHODS:
 node('PART-174-'+s,'method',{'title':s,'input':i,'output':o,'conditions':c,'cannot_transfer':c,'application_gain_tested':False},base+[local(next(r['path'] for r in rows if r['label']==l),'Actually read result/proof '+l)]);edge('PART-174-'+s,'depends_on',cid(l))
for label,key in [('thm:main','AnariOveisGharan2015'),('thm:rational-signing','EzeunalaJiang2026'),('thm:mss','MarcusSpielmanSrivastava2015')]:edge(cid(label),'compared_with',refs[key],'Historical comparison does not mean whole original proof audited')
node('XPL-174-DOMAIN-AND-COMBINATION','exploration',{'title':'Ten mapping attempts and three actual cross-family boundaries;no admitted application candidate','domain_attempts':ledger['domain_attempts'],'cross_family_attempts':cross,'new_candidates':0,'new_initial_checks':0,'no_numeric_run':True,'selected_next_question':'Find whether a real exact rational-PSD consumer requires unweighted rational columns;weighted LDL null hypothesis and full bit/serialization cost must be compared before candidate/experiment.'},ev='hypothesis')
for s in ['THIN-CHEAP-ROUNDING','RATIONAL-PSD-OUTERS','TWO-SYSTEM-HALF']:edge('XPL-174-DOMAIN-AND-COMBINATION','uses','PART-174-'+s,ev='hypothesis')
for ff in ['F-114','F-238','F-332']:edge('XPL-174-DOMAIN-AND-COMBINATION','compared_with',ff,'Scoped structural attempt,not proved dependency or candidate',ev='hypothesis')
comparison=[{'item':'Existence main','natural':'n>=2,loopless indexed multigraph,k>=1,absolute C and every nontrivial cut','Lean':'StrongThinTree.MainStatement and actual solution Main.lean','assessment':'Selected scope matches statically;B upstream proof claim,no build/Comparator/human review'}, {'item':'Algorithmic main','natural':'n>=1 including singleton,explicit or binary multiplicities,polynomial total binary input length','Lean':'AlgorithmicThinTrees challenge stack-machine time a(length+1)^degree and imported Encoding/AlgorithmicMain endpoint','assessment':'Selected scope matches statically;B upstream proof claim;ALG exact YAML entry absent while docs/challenge/solution present;no whole import closure approval'}, {'item':'Remaining56 and fractional corollary','natural':'All auxiliary statements retain exact source conditions','Lean':'No individual match established this package','assessment':'C and full chain unknown;do not distribute main B across all auxiliary claims'}]
node('ANALYSIS-F-174','family_analysis',{'title':'F174 complete current-source decomposition draft,two manuscripts','family_id':F,'manuscript_ids':ledger['manuscript_ids'],'manuscript_source_drafts_complete_ids':ledger['manuscript_ids'],'source_decomposition_draft_complete':True,'full_family_complete':False,'historical_lineage_complete':False,'source_sections':tex,'source_line_count':7384,'source_result_count':58,'result_ids_by_label':resultids,'result_ids_by_source':bind,'method_ids':['PART-174-'+s for s,*_ in METHODS],'reading_ledger':lp,'historical_references_by_key':refs,'historical_verified_keys':ledger['historical_verified_keys'],'formal_status':formal,'formal_statement_comparison':comparison,'gaps':gaps})
for n in added:
 if n['id']!=GEN:edge(n['id'],'generated_by',GEN)
(R/'data/graph/nodes.jsonl').write_bytes(raw+b''.join((json.dumps(n,ensure_ascii=False,sort_keys=True)+'\n').encode() for n in added));(R/'data/graph/edges.jsonl').write_bytes(eraw+b''.join((json.dumps(e,ensure_ascii=False,sort_keys=True)+'\n').encode() for e in edges))
cov=json.load(open(R/'data/graph/reading_coverage.json'));assert F not in cov['partially_read_families'];cov['partially_read_families'][F]={'scope':'Two current manuscripts32TeX7384+582Bib,58qualified result drafts,12methods,three selected old originals,sixPDFpixels,two selected mainB;not fullfamily/history/proof review','evidence':lp,'manuscript_ids':ledger['manuscript_ids'],'full_family_complete':False};write('data/graph/reading_coverage.json',cov)
J.update(at=NOW,status='canonical_source_draft_curated_quality_pending',canonical_coverage_promoted=True,source_body_all_read=True,source_result_count=58,new_candidates=0,new_initial_checks=0,reading_ledger=lp,next_action='Finish fullgraph/hash/impact/export/core/no-math checks,compress own records and verify cleanup;then bounded realPSDconsumer qualification or alternate lowcoverage route.')
for m in J['manuscripts']:
 m['source_body_all_read']=True;m['readme']['scope']='README18lines actually read;body completion now independently documented with per-file ranges'
write('state/reading-progress/F-174.json',J)
v=validate(R);gz(str(O.relative_to(R))+'/curation.json.gz',{'at':NOW,'base_commit':BASE,'new_records':len(added),'new_ids':[n['id'] for n in added],'new_explicit_edges':len(edges),'all4412oldlines_and_oldedges_exact':True,'named_results':58,'methods':12,'bib_keys':len(bibs),'selected_originals':3,'actualpixels':6,'new_candidates':0,'new_initial_checks':0,'validation':v});print(json.dumps({'new_records':len(added),'new_edges':len(edges),'bib_keys':len(bibs),'validation':v}))
