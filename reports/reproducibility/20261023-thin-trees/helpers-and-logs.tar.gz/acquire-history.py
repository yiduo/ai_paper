from pathlib import Path
import urllib.request,hashlib,json,datetime
p=Path('/private/tmp/ai-paper-WP105'); rows=[];used=0
items=[('EJ2026v1','https://arxiv.org/pdf/2609.17266v1'),('AOG2015v4','https://arxiv.org/pdf/1411.4613v4'),('Bansal2024','https://theoryofcomputing.org/articles/v020a006/v020a006.pdf')]
for name,url in items:
 r={'id':name,'url':url,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tls':'normal verified TLS'}
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'ai-paper provenance research'})
  with urllib.request.urlopen(req,timeout=35) as response:
   body=response.read(8*1024*1024-used+1);r['final_url']=response.url
  if len(body)>8*1024*1024-used:raise ValueError('total eight MiB cap reached')
  if not body.startswith(b'%PDF'):raise ValueError('not PDF')
  used+=len(body);(p/(name+'.pdf')).write_bytes(body);r.update(bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),status='acquired',path=str(p/(name+'.pdf')))
 except Exception as e:r.update(status='failed',error=str(e))
 rows.append(r);(p/'history-acquisition.json').write_text(json.dumps({'total_downloaded_bytes':used,'works_cap':4,'bytes_cap':8388608,'items':rows},indent=2)+'\n');print(name,r['status'],r.get('bytes',r.get('error')),flush=True)
