from pathlib import Path
import json,gzip,tarfile,io,hashlib,datetime,shutil,subprocess
R=Path('/Users/smzdm/projects/ai_paper');T=Path('/private/tmp/ai-paper-WP105');O=R/'reports/reproducibility/20261023-thin-trees';Q=str(O.relative_to(R));now=datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda b:hashlib.sha256(b).hexdigest()
def load(p):return json.load(open(R/p))
def put(p,j):p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
clean=json.loads(gzip.decompress((O/'no-math-clean-directory.json.gz').read_bytes()));assert clean['exit_code']==0 and not clean['upstream_math_present'] and not (T/'no-math-clean').exists()
log=(T/'core.log').read_text();assert 'Ran 69 tests' in log and '\nOK\n' in log and '"canonical_citations": 7884' in log and 'Traceback' not in log
source=json.loads(gzip.decompress((O/'source-contracts.json.gz').read_bytes()));assert source['metrics']['nodes']==7362 and source['metrics']['edges']==20333
ledger=load('data/provenance/readings/F-174.json');third=[]
for d in ledger['historical_selected_originals']:
 p=Path(d['path']);b=p.read_bytes();assert sha(b)==d['sha256'];third.append({'path':str(p),'bytes':len(b),'sha256':sha(b),'type':'primary_pdf'})
for d in ledger['actual_pdf_pixels']:
 p=Path(d['image']);b=p.read_bytes();assert sha(b)==d['image_sha256'];third.append({'path':str(p),'bytes':len(b),'sha256':sha(b),'type':'viewed_pdf_pixels'})
for p in sorted(T.glob('*.txt')):
 b=p.read_bytes();third.append({'path':str(p),'bytes':len(b),'sha256':sha(b),'type':'temporary_pdf_text_derivative_not_published'})
assert len([d for d in third if d['type']=='primary_pdf'])==3 and len([d for d in third if d['type']=='viewed_pdf_pixels'])==6
for d in third:Path(d['path']).unlink()
for d in third:assert not Path(d['path']).exists()
put(T/'cleanup-source-receipt.json',{'at':now,'policy':'Original bodies not republished;hashes,version locators,own scope notes retained. No installs/upstream writes or new scientific data.','verified_removed':third,'total_removed_bytes':sum(d['bytes'] for d in third)})
b=load('state/backlog.json');task=next(x for x in b['tasks'] if x['id']=='WP-105');assert task['status']=='source_draft_done_quality_pending';task.update(status='completed',completed_at=now,quality_scope='69core/fullsourceFKgates/12impact/fullJSONGraphML/15archives267members/no-mathclean passed;storageverified separately;no scientificreplay/newexperiment');b['updated_at']=now;put(R/'state/backlog.json',b)
c=load('state/checkpoint.json');c.update(saved_at=now,overall_status='active_incomplete',last_completed_work_package=task,active_work_package=None,work_packages_since_last_retrospective=1,retrospective_due_after='WP107thenretro038;earlier major evidence/two no-information packages',running_research_experiments=[],storage_receipt=Q+'/storage.json',previous_goal_turn_classification={'classification':'progress','evidence':'WP105 actual complete two-source reading and qualified graph,three primary selected sources,no new application efficacy claim','goal_complete':False});assert 'WP-105' not in c['completed_work_packages'];c['completed_work_packages'].append('WP-105')
c['recovery_observation'].update(at=now,checkpoint_core_check='69core/fullsourceFKgates/12impact/fullJSONGraphML/15archives267members/no-mathclean exit0;initialnullhashmetadatafailure preserved and repaired;storage nextverified byreceipt',research_processes_observation='All core/QA/clean jobs terminal,no scientific/replay/Lean/Comparator process;final readonly process observation recorded separately',current_reading='WP105 completed current-source draft;fullfamily/history and human/provider pending;nextWP106 three-project contract qualification',public_state='No GitHub write;last verified public f0c3ddc,WP093-WP105/retro034-037 local')
c['resume_commands']=['Read goal/AGENTS/charter/roadmap/status/checkpoint/backlog/latestretro037;verify disk/process/finalquality/storage','WP105 complete local source draft;do not rerun curator or reacquire three primary PDFs,do not repeat known nullhash metadata encoding failure','Read F174 ledger/results/conditions and XPL174;no real unweighted rational PSD consumer,benchmark,candidate or newrun admitted','BeginWP106 bounded3project/2MiB primary exactPSD output qualification;strong weightedLDL/SOS/numerical baseline contract and fullcost first;isolated roles onlyifnewhypothesis','Counter1afterretro037;WP107thenretro038 or major evidence/two no-information packages. Routine localonly,noGitHubpush,mathreadonly/excluded,humans/providerdeferrednotwaived'];c['recovery_commands']=c['resume_commands'];put(R/'state/checkpoint.json',c)
j=load('state/reading-progress/F-174.json');j.update(at=now,status='completed_current_source_draft',quality_evidence=Q,source_body_read=True,next_action='WP106bounded actual exactPSD consumer qualification,then alternatecoverage if unmet;not new experiments before independent prerequisites/specification');put(R/'state/reading-progress/F-174.json',j)
with (R/'state/work_packages.jsonl').open('a') as f:f.write(json.dumps({'at':now,'id':'WP-105','status':'completed','evidence':'data/provenance/readings/F-174.json','quality':Q,'new_records':102,'new_explicit_edges':333,'new_candidates':0,'new_initial_checks':0,'retrospective_counter':1,'github_push':False,'next':'WP-106'},ensure_ascii=False,sort_keys=True)+'\n')
(O/'quality.md').write_text(f'''# WP105 quality and evidence scope

All 69 core checks passed with complete source/FK/gate/provenance checks. Twelve new and old dependency-impact cases passed; full JSON and GraphML objects exactly match the full graph. All15 experiment archives and267 source members passed compressed/decompressed hash integrity. Experimental algorithm/spec/data/comparator did not change; this is not a new scientific replay or application validation.

The separate clean directory without math or Git history passed the full check with exit0: {clean['files']} files / {clean['copied_bytes']} bytes copied and individually verified, then removed. With no upstream present,the pinned manifest checks hashes;it does not freshly read or verify the originals.

The final graph has7362 nodes/20333 relations;4514 canonical records,7884 source annotations(7874 core-validated). All4412 old record lines,old edges,old candidates,experimental source/data/tests and old family reports remain byte-exact. New source reading:58result drafts/12methods,three selected primary originals/six viewed pages;56read families/51source drafts. Candidate44/preliminary13/distinct13 counts unchanged;fullfamily/history/human/provider/pilots remain0.

Eight aliases and104 lexical references were qualified with the exact unaccepted first draft preserved. First core and first clean-directory runs failed at the provenance audit because32 unacquired-byte hashes were encoded null. Their logs/manifests and27 exact previous new objects remain archived;the existing absent-hash convention was restored,without inventing bytes or changing old records. Full affected checks then passed. See draft-qualification,unknown-hash-encoding-correction and compressed helper logs.

Normal TLS acquired1635535 bytes,within four-work/eight-MiB cap. Original PDFs/text/pixels were hash-verified and removed,not republished. Own helper/logs/failures are compressed with every member's decompressed SHA256 checked before plaintext deletion;actual storage receipt is storage.json. No installation,scientific experiment,Lean/Comparator build,GitHub write or official math deployment. Selected main upstream B scopes are not human approval. Overall goal active_incomplete;nextWP106 bounded realPSD consumer qualification,retro038 afterWP107 or earlier significant evidence.
''')
# Preserve exact implementation and logs,including this script,without third-party bodies.
own=sorted(p for p in T.iterdir() if p.is_file());assert all(p.suffix in {'.py','.json','.log'} for p in own),[p.name for p in own]
members=[];buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w') as tf:
 for p in own:
  body=p.read_bytes();info=tarfile.TarInfo(p.name);info.size=len(body);info.mtime=0;info.mode=0o644;tf.addfile(info,io.BytesIO(body));members.append({'name':p.name,'bytes':len(body),'sha256':sha(body)})
raw=buffer.getvalue();compressed=gzip.compress(raw,mtime=0);assert gzip.decompress(compressed)==raw;path=O/'helpers-and-logs.tar.gz';path.write_bytes(compressed)
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(path.read_bytes())),mode='r:') as tf:
 assert set(tf.getnames())=={m['name'] for m in members}
 for m in members:assert sha(tf.extractfile(m['name']).read())==m['sha256']
for p in own:p.unlink()
assert not list(T.iterdir());T.rmdir()
receipt={'at':now,'archive':str(path.relative_to(R)),'compressed_bytes':len(compressed),'uncompressed_tar_bytes':len(raw),'archive_sha256':sha(compressed),'decompressed_tar_sha256':sha(raw),'members':members,'all_member_roundtrip_hashes_verified':True,'own_plaintext_bytes_removed':sum(m['bytes'] for m in members),'third_party_temporary_files_verified_removed':third,'third_party_temporary_bytes_removed':sum(d['bytes'] for d in third),'temporary_root_removed':not T.exists(),'new_scientific_experiment':False,'numeric_data_policy':'No new numerical data;all15 existing scientific archives verified,no uncompressed experiment data introduced.','upstream_math_written':False,'github_write':False,'all_quality_jobs_terminal':True,'overall_goal':'active_incomplete'};put(O/'storage.json',receipt);print(json.dumps({k:v for k,v in receipt.items() if k not in ['members','third_party_temporary_files_verified_removed']},ensure_ascii=False))
