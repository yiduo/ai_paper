from pathlib import Path
import json,sys,datetime
R=Path('/Users/smzdm/projects/ai_paper');p=R/'state/reading-progress/F-174.json';j=json.load(open(p));prefix=sys.argv[1];files=sys.argv[2].split(',');note=sys.argv[3];m=next(m for m in j['manuscripts'] if ('The-strong-thin' in m['readme']['path'])==(prefix=='exist'))
seen=[]
for rel in files:
 f=next(f for f in m['files'] if f['path'].endswith('/'+rel));j['actual_read_ranges'][f['path']]=[[1,f['lines']]];f['actually_read']=True;seen.append(f['path'])
j['reading_notes'].append({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manuscript_id':m['id'],'source_files':seen,'note':note});j['at']=datetime.datetime.now(datetime.timezone.utc).isoformat();p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n');print('Recorded',prefix,len(files),'files;actualread',len(j['actual_read_ranges']))
