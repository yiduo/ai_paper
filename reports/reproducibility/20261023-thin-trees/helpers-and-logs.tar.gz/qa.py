from pathlib import Path
import json,gzip,hashlib,sys,subprocess,xml.etree.ElementTree as ET
R=Path('/Users/smzdm/projects/ai_paper');T=Path('/private/tmp/ai-paper-WP105');O=R/'reports/reproducibility/20261023-thin-trees';BASE='e4d5935';sys.path.insert(0,str(R/'src'))
from ai_value.graph import load,affected_nodes,theoretical_grade
from ai_value.knowledge import export
from ai_value.reporting import render
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(n,j):
 b=(json.dumps(j,ensure_ascii=False,indent=2)+'\n').encode();z=gzip.compress(b,mtime=0);assert gzip.decompress(z)==b;(O/n).write_bytes(z)
nodes,edges=load(R);cases=[]
def check(name,seeds,yes,no):
 h=affected_nodes(nodes,edges,set(seeds));assert set(yes)<=h,(name,'missing',set(yes)-h);assert not(set(no)&h),(name,'false',set(no)&h);cases.append({'name':name,'changed':seeds,'expected_review':yes,'expected_unaffected':no,'affected':sorted(h),'pass':True})
main='CLM-174-THM-MAIN';alg='CLM-174-THM-TT-ALGORITHM';cheap='CLM-174-COR-TA-FRACTIONAL-ROUNDING';sign='CLM-174-THM-RATIONAL-SIGNING';psd='CLM-174-LEM-RATIONAL-PSD';metric='CLM-174-THM-TG-HIERARCHY'
check('existence_core',['CLM-174-THM-HIERARCHY-POWER'],[main],['APP-304-01'])
check('metric_geometry_constructor',[metric],[alg,cheap],[main,'APP-304-01'])
check('rational_signing_constructor',[sign],[alg,cheap,'PART-174-ROBUST-SIGNING'],[main,psd])
check('rational_psd_padding',[psd],[alg,cheap,'PART-174-RATIONAL-PSD-OUTERS'],[main])
check('old_EJ_required',['LIT-174-EZEUNALAJIANG2026'],[sign,alg,cheap],[main])
check('old_covariance_required',['LIT-174-BANSAL2024'],[sign,alg],[main])
check('old_GLS_required',['LIT-114-DC4ADB604E'],[alg,cheap],[main])
check('old_AOG_context_not_new_proof',['LIT-174-ANARIOVEISGHARAN2015'],[],[main,alg,cheap])
check('fractional_corollary_not_core_premise',[cheap],['PART-174-THIN-CHEAP-ROUNDING'],[main,alg])
check('F304_component_preserved',['CLM-304-LAT-FINITE-CHASES'],['APP-304-01'],[main,alg])
check('F256_conditional_guard_preserved',['LIT-256-GAP-FP-INTERFACE'],['APP-256-01'],[main,alg])
check('F198_context_preserved',['LIT-198-QPA-COMPLEX'],['CHECK-198-QPA-CALLER'],[main,alg])
for i in [main,alg,cheap,sign,psd]:assert theoretical_grade(nodes,edges,i)=='unknown'
write('impact.json.gz',{'count':len(cases),'cases':cases,'full_grades':'unknown','meaning':'Qualified dependency routing;source_reference/compared_with do not masquerade as premises'})
ex=export(R);j=json.loads(gzip.decompress((R/'reports/graph/knowledge.json.gz').read_bytes()));assert {n['id']:n for n in j['nodes']}==nodes and j['edges']==edges
ns={'g':'http://graphml.graphdrawing.org/xmlns'};tree=ET.fromstring(gzip.decompress((R/'reports/graph/knowledge.graphml.gz').read_bytes()));gn={n.attrib['id']:json.loads(next(d.text for d in n if d.attrib.get('key')=='properties')) for n in tree.findall('.//g:node',ns)};ge={n.attrib['id']:json.loads(next(d.text for d in n if d.attrib.get('key')=='evidence')) for n in tree.findall('.//g:edge',ns)};assert gn==nodes and ge=={e['id']:e for e in edges};write('exports.json.gz',{'export':ex,'json_full_nodes_edges_exact':True,'graphml_full_nodes_edges_exact':True})
archives=[];members=0
for p in sorted((R/'experiments/runs').glob('*/manifest.json')):
 m=json.loads(p.read_text())
 for n,h in m['outputs'].items():
  b=(p.parent/n).read_bytes();assert sha(b)==h
  if n.endswith('.gz'):gzip.decompress(b)
 for n,d in m.get('compressed_payloads',{}).items():assert sha(gzip.decompress((p.parent/n).read_bytes()))==d['uncompressed_sha256']
 s=json.loads(gzip.decompress((p.parent/m['source_snapshot']).read_bytes()));assert set(s)==set(m['inputs']);assert all(isinstance(t,str) and sha(t.encode())==m['inputs'][n] for n,t in s.items());members+=len(s);archives.append({'run_id':m['run_id'],'source_members':len(s),'all_hashes_verified':True,'scientific_replay':False})
assert len(archives)==15 and members==267;write('archives.json.gz',{'archives':archives,'count':len(archives),'source_members':members,'reason_no_replay':'No experimental source/spec/data/comparator changed;221/325 full scientific replays just passed WP104. Full archive hash integrity is not another experiment.'})
oldraw=subprocess.check_output(['git','show',BASE+':data/graph/nodes.jsonl'],cwd=R);olded=subprocess.check_output(['git','show',BASE+':data/graph/edges.jsonl'],cwd=R);raw=(R/'data/graph/nodes.jsonl').read_bytes();eraw=(R/'data/graph/edges.jsonl').read_bytes();assert raw.startswith(oldraw) and eraw.startswith(olded);assert len(oldraw.splitlines())==4412 and len(raw.splitlines())==4514
protected=0
for prefix in ['experiments','src','tests','data/provenance/readings','reports/families']:
 paths=subprocess.check_output(['git','ls-tree','-r','--name-only',BASE,'--',prefix],cwd=R,text=True).splitlines()
 for p in paths:assert (R/p).read_bytes()==subprocess.check_output(['git','show',BASE+':'+p],cwd=R),p;protected+=1
oldcov=json.loads(subprocess.check_output(['git','show',BASE+':data/graph/reading_coverage.json'],cwd=R));cov=json.load(open(R/'data/graph/reading_coverage.json'));del cov['partially_read_families']['F-174'];assert cov==oldcov
write('canonical-preservation.json.gz',{'base':BASE,'old_records':4412,'alloldrecordlines_and_oldedgebytes_exact':True,'protected_files_exact':protected,'only_new_coverage_entry':'F-174','new_records':102,'new_edges':333,'new_candidates':0,'new_initial_checks':0,'new_application_runs':0})
l=json.load(open(R/'data/provenance/readings/F-174.json'));assert len(l['results'])==58 and len(l['methods'])==12 and len(l['source_sections'])==32
for f in l['read_files']:assert sha((R/f['path']).read_bytes())==f['sha256'] and f['actually_read']
for o in l['historical_selected_originals']:assert sha(Path(o['path']).read_bytes())==o['sha256']
for p in l['actual_pdf_pixels']:assert sha(Path(p['image']).read_bytes())==p['image_sha256'] and p['pixels_actually_viewed']
assert len(l['historical_selected_originals'])==3 and len(l['actual_pdf_pixels'])==6 and l['historical_external_work_count']==30 and len(l['historical_unverified_external_work_ids'])==27
assert len(l['historical_references_by_key'])==40 and l['new_candidates']==0 and l['new_initial_checks']==0 and not l['numeric_or_symbolic_run']
assert sum(r['source_claim_grade']=='B' for r in l['results'])==2 and sum(r['source_claim_grade']=='C' for r in l['results'])==56
m=render(R);family=(R/'reports/families/F-174.md').read_text();assert all(r['id'] in family and r['statement'].replace('|',r'\|') in family for r in l['results']);assert m['candidate_connections']==44 and m['externally_checked_cards']==13 and m['source_decomposition_drafts']==51 and m['partial_reading_families']==56
cur=[json.loads(x) for x in raw.splitlines()];sources=[s for n in cur for s in n['sources']]
receipt={'selected_original_works':3,'actual_pixels':6,'source_and_image_hashes_verified':True,'named_results':58,'methods':12,'actual_tex_lines':7384,'bib_lines':582,'upstream_selected_B_bindings':2,'local_lean_build_or_comparator':False,'fullchain_unknown':True,'all_canonical_annotations':len(sources),'local_annotations':sum('path'in s for s in sources),'external_annotations':sum('url'in s for s in sources),'external_without_byte_hash':sum('url'in s and not s.get('sha256') for s in sources),'download_bytes':l['acquisition']['total_downloaded_bytes'],'metrics':m};write('source-contracts.json.gz',receipt);print(json.dumps({'full_nodes':len(nodes),'full_edges':len(edges),'canonical_records':len(cur),'impact_cases':len(cases),**receipt},ensure_ascii=False))
