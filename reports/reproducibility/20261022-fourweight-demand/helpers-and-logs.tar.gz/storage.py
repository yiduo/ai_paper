"""Preserve own helpers and licensed selected sources;verify raw bytes,then clean."""
import datetime,gzip,hashlib,io,json,tarfile
from pathlib import Path
R=Path('/Users/smzdm/projects/ai_paper');T=Path(__file__).parent;O=R/'reports/reproducibility/20261022-fourweight-demand'
def sha(b):return hashlib.sha256(b).hexdigest()
helpernames=['acquire.py','acquire-selected.py','curate.py','qa.py','save.py','final-exports.py','storage.py','acquisitions.json','execution-notes.json','core-check.log','clean-core-check.log','qa.log','export-graph.log','organize-graph.log','final-render.log','final-exports.log','HELPERS.txt']
(T/'HELPERS.txt').write_text('WP094 one-shot curation/save at aa50432;not an executable replay chain. Do not rerun curate/save against already-promoted canonical data.\nSources were only statically read,no external source executed,solver installed or numerical application experiment.\nacquire scripts use public read-only requests,normalTLS,capped byte budget;they are acquisition receipts,not baseline runtime.\ncore and clean logs retain actual68-test workflows;final-render/final-exports are focused follow-ups after two timing metadata strings were normalized. This did not change code,proof/experiment criteria or scientific data.\nOriginal selected software bytes+complete licenses retained separately in fourweight-interfaces-20261022.tar.gz;external fulltextHTML and metadata copies deleted after hashes.\nPublic GitHub commit unchanged;officialmath remains readonly and not copied or redeployed.\n')
rawfiles={name:(T/name).read_bytes() for name in helpernames};buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as a:
 for name,raw in rawfiles.items():
  info=tarfile.TarInfo(name);info.size=len(raw);info.mtime=0;info.mode=0o644;a.addfile(info,io.BytesIO(raw))
rawtar=buf.getvalue();z=gzip.compress(rawtar,mtime=0);assert gzip.decompress(z)==rawtar
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(z))) as a:
 assert set(a.getnames())==set(rawfiles)
 for name,raw in rawfiles.items():assert a.extractfile(name).read()==raw
(O/'helpers-and-logs.tar.gz').write_bytes(z)
ledger=json.loads((R/'data/provenance/demand/F-273-fourweight-demand.json').read_text());bundle=R/ledger['software_archive']['path'];bz=bundle.read_bytes();assert sha(bz)==ledger['software_archive']['sha256']
assert sha(gzip.decompress(bz))==ledger['software_archive']['uncompressed_tar_sha256']
with tarfile.open(bundle,'r:gz') as a:
 for m in ledger['software_archive']['members']:
  assert sha(a.extractfile(m['member']).read())==m['sha256'];assert (T/m['member']).read_bytes()==a.extractfile(m['member']).read()
with tarfile.open(R/'reports/reproducibility/20261022-log-concave/helpers-and-logs.tar.gz','r:gz') as a:assert (T/'prior-qa.py').read_bytes()==a.extractfile('qa.py').read()
acq=json.loads((T/'acquisitions.json').read_text())
for a in acq:assert sha((T/a['file']).read_bytes())==a['sha256']
third=[{'name':p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'removed':True,'retained_in_licensed_source_archive':any(m['member']==p.name for m in ledger['software_archive']['members'])} for p in sorted(T.iterdir()) if p.name not in helpernames and p.name!='prior-qa.py']
own_plain=sum(map(len,rawfiles.values()))+(T/'prior-qa.py').stat().st_size
receipt={'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'helper_archive':'helpers-and-logs.tar.gz','helper_gzip_bytes':len(z),'helper_gzip_sha256':sha(z),'uncompressed_tar_sha256':sha(rawtar),'all_members_exact_roundtrip':True,'members':[{'name':n,'bytes':len(b),'sha256':sha(b)} for n,b in rawfiles.items()],'thirdparty_temporary_files':third,'thirdparty_temporary_bytes_removed':sum(p['bytes'] for p in third),'own_plaintext_bytes_removed':own_plain,'prior_helper_copy_verified_against_existing_archive':True,'licensed_source_archive':ledger['software_archive'],'original_paper_html_retained':False,'new_dependency_install':False,'new_numerical_experiment':False,'math_source_copied_or_modified':False,'remote_push':False,'temporary_root_removed':str(T)}
raw=(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n').encode();packed=gzip.compress(raw,mtime=0);assert gzip.decompress(packed)==raw;(O/'storage.json.gz').write_bytes(packed);assert json.loads(gzip.decompress((O/'storage.json.gz').read_bytes()))==receipt
for p in list(T.iterdir()):assert p.is_file();p.unlink()
T.rmdir();assert not T.exists()
p=R/'state/checkpoint.json';c=json.loads(p.read_text());c['last_quality_evidence'].update(helper_gzip_bytes=len(z),temporary_thirdparty_bytes_removed=receipt['thirdparty_temporary_bytes_removed'],own_plaintext_bytes_removed=own_plain,temporary_root_removed=True);c['saved_at']=receipt['recorded_at'];p.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'helpers_gzip_bytes':len(z),'thirdparty_temporary_bytes_removed':receipt['thirdparty_temporary_bytes_removed'],'licensed_source_gzip_bytes':len(bz),'own_plaintext_removed':own_plain,'temporary_root_exists':T.exists(),'all_member_bytes_verified':True}))
