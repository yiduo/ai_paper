"""Focused follow-up after normalizing two opinion timing metadata strings."""
import gzip,hashlib,json,subprocess,sys,xml.etree.ElementTree as ET
from pathlib import Path
R=Path('/Users/smzdm/projects/ai_paper');sys.path.insert(0,str(R/'src'))
from ai_value.graph import load
from ai_value.knowledge import export
nodes,edges=load(R);result=export(R)
payload=json.loads(gzip.decompress((R/'reports/graph/knowledge.json.gz').read_bytes()))
assert {n['id']:n for n in payload['nodes']}==nodes and payload['edges']==edges
tree=ET.fromstring(gzip.decompress((R/'reports/graph/knowledge.graphml.gz').read_bytes()));ns={'g':'http://graphml.graphdrawing.org/xmlns'}
assert {n.attrib['id'] for n in tree.findall('.//g:node',ns)}==set(nodes)
assert {(e.attrib['id'],e.attrib['source'],e.attrib['target']) for e in tree.findall('.//g:edge',ns)}=={(e['id'],e['source'],e['target']) for e in edges}
canon=[json.loads(l) for l in (R/'data/graph/nodes.jsonl').read_text().splitlines()]
old=[json.loads(l) for l in subprocess.check_output(['git','show','aa50432:data/graph/nodes.jsonl'],cwd=R,text=True).splitlines()]
lookup={n['id']:n for n in canon}
for n in old:
 if n['id']!='APP-273-01':assert lookup[n['id']]==n
prior=json.loads(gzip.decompress((R/'data/graph/history/GEN090-APP27301-before.json.gz').read_bytes()));assert prior==next(n for n in old if n['id']=='APP-273-01')
for field in ['prediction','run_ids','test_spec','dedup_key','theoretical_grade','workflow','application_result']:assert lookup['APP-273-01']['properties'][field]==prior['properties'][field]
card=(R/'reports/cards/APP-273-01.md').read_text();assert card.count('检验前的辅助自查')==2 and '生成时点未记录' not in card
assert hashlib.sha256((R/'experiments/plans/APP-273-01-conditional.json').read_bytes()).hexdigest()=='d8de8bc109761a17ff3b86e8759fb144e5fbcbcac115d4a7bd3a3568c10a59c6'
receipt={'nodes':len(nodes),'edges':len(edges),'json_exact':True,'graphml_exact':True,'old_other_nodes_exact':len(old)-1,'prior_candidate_exact':True,'prediction_plan_unchanged':True,'timing_labels':'Both same-model pre-experiment opinions after original-demand reading,now render recorded timing correctly','followup_scope':'Only two APP27301 timing strings normalized after68core/no-math run;no code,edge,sourcecitation,hypothesis or experiment changes. CLI report reran full graph validation and card generation,then exports rechecked;did not redundantly rerun scientific experiments or unit suite.','export':result}
b=(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n').encode();z=gzip.compress(b,mtime=0);assert gzip.decompress(z)==b;(R/'reports/reproducibility/20261022-fourweight-demand/final-render-and-exports.json.gz').write_bytes(z)
p=R/'state/checkpoint.json';c=json.loads(p.read_text());c['last_quality_evidence']['focused_final_render_followup']='reports/reproducibility/20261022-fourweight-demand/final-render-and-exports.json.gz';p.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'nodes':len(nodes),'edges':len(edges),'exports_exact':True,'timing_labels_correct':True,'old_other_nodes_exact':len(old)-1}))
