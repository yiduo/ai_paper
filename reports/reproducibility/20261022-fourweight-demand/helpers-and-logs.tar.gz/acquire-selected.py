"""Follow only paths discovered in the pinned repository directory."""
import hashlib,json,urllib.request
from pathlib import Path
T=Path(__file__).parent;records=json.loads((T/'acquisitions.json').read_text());total=sum(r['bytes'] for r in records)
def get(name,url,cap=150000):
 global total
 with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'ai-paper-source-audit/1.0'}),timeout=25) as r:b=r.read(cap+1)
 assert len(b)<=cap and total+len(b)<=10*1024*1024;total+=len(b);(T/name).write_bytes(b);records.append({'file':name,'url':url,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'normal_TLS':True,'read_only':True});return b
head=json.loads((T/'lipsdp-head.json').read_text())['sha'];root='https://raw.githubusercontent.com/arobey1/LipSDP/'+head+'/'
get('lipsdp-solve_sdp.py',root+'LipSDP/solve_sdp.py')
d=json.loads(get('lipsdp-engine-directory.json','https://api.github.com/repos/arobey1/LipSDP/contents/LipSDP/matlab_engine?ref='+head))
for e in d:
 print(e['path'],e['type'])
 if e['type']=='file' and e['name'].endswith(('.m','.py')):get('lipsdp-'+e['name'],e['download_url'])
get('LipSDP-v2.html','https://arxiv.org/html/1906.04893v2',2500000)
(T/'acquisitions.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps({'total_bytes':total,'files':len(records)}))
