"""Bounded public metadata/source acquisition; normal TLS,no credentials or clone."""
import datetime,hashlib,json,urllib.request
from pathlib import Path
T=Path(__file__).parent
MAX=10*1024*1024;records=[];total=0
def get(name,url,cap=1024*1024):
 global total
 req=urllib.request.Request(url,headers={'User-Agent':'ai-paper-source-audit/1.0','Accept':'application/vnd.github+json' if 'api.github.com' in url else '*/*'})
 with urllib.request.urlopen(req,timeout=25) as r:b=r.read(cap+1)
 assert len(b)<=cap and total+len(b)<=MAX,(url,len(b));total+=len(b);(T/name).write_bytes(b);records.append({'file':name,'url':url,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'normal_TLS':True,'read_only':True});return b
for slug,label in [('arobey1/LipSDP','lipsdp'),('cvxpy/cvxpy','cvxpy')]:
 meta=json.loads(get(label+'-repo.json','https://api.github.com/repos/'+slug,150000));branch=meta['default_branch']
 commit=json.loads(get(label+'-head.json','https://api.github.com/repos/'+slug+'/commits/'+branch,500000))['sha']
 get(label+'-README.md','https://raw.githubusercontent.com/'+slug+'/'+commit+'/README.md',100000)
 if label=='lipsdp':
  get(label+'-LICENSE','https://raw.githubusercontent.com/'+slug+'/'+commit+'/LICENSE',50000)
  get(label+'-directory.json','https://api.github.com/repos/'+slug+'/contents/LipSDP?ref='+commit,100000)
 else:
  get(label+'-LICENSE','https://raw.githubusercontent.com/'+slug+'/'+commit+'/LICENSE',50000)
  for path in ['cvxpy/constraints/psd.py','cvxpy/constraints/constraint.py']:
   get(label+'-'+Path(path).name,'https://raw.githubusercontent.com/'+slug+'/'+commit+'/'+path,100000)
(T/'acquisitions.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps({'bytes':total,'files':len(records),'commits':{label:json.loads((T/(label+'-head.json')).read_text())['sha'] for label in ['lipsdp','cvxpy']}}))
