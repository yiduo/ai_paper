from pathlib import Path
import json,gzip,hashlib,copy,datetime
r=Path('/Users/smzdm/projects/ai_paper');sha=lambda b:hashlib.sha256(b).hexdigest();now=datetime.datetime.now(datetime.timezone.utc).isoformat();G='GEN-20261021-040';ledger='data/provenance/demand/F-366-segmentation-tool-contracts.json';p=r/ledger;j=json.loads(p.read_text());sourcearc=j['source_archive'];a=r/sourcearc
prior=[]
for path in [ledger,sourcearc]:
 target=r/'data/provenance/demand/history'/(Path(path).name+'.before-gallery-scope.gz');target.parent.mkdir(parents=True,exist_ok=True);raw=(r/path).read_bytes();target.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(target.read_bytes())==raw;prior.append(dict(path=path,archive=str(target.relative_to(r)),sha256=sha(raw)))
payload=json.loads(gzip.decompress(a.read_bytes()));count=len(payload['files']['doc/examples/segmentation/plot_chan_vese.py'].splitlines());assert count==85
def fix(value):
 if isinstance(value,dict):return {k:fix(v)for k,v in value.items()}
 if isinstance(value,list):return [fix(v)for v in value]
 if isinstance(value,str):return value.replace('Whole90line gallery','Whole85line gallery')
 return value
payload=fix(payload);raw=(json.dumps(payload,ensure_ascii=False,indent=2)+'\n').encode();a.write_bytes(gzip.compress(raw,mtime=0));j=fix(j);j['version']=2;j['source_archive_sha256']=sha(a.read_bytes());j['decompressed_sha256']=sha(raw);j['prior_metadata_archives']=prior;j['metadata_repair']='Gallery whole file has85lines,not guessed90;actualfullfilescope unchanged. Sourcearchive metadata,ledger andcurrentciters refreshed;former bytes preserved.';p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
hashes={ledger:sha(p.read_bytes()),sourcearc:sha(a.read_bytes())};nodes=[json.loads(l)for l in(r/'data/graph/nodes.jsonl').read_text().splitlines()];old=[];arc='data/graph/history/GEN-20261021-040-gallery-scope-before.json.gz'
for n in nodes:
 if not any(s.get('path')in hashes for s in n['sources']):continue
 old.append(copy.deepcopy(n));n.update(version=n['version']+1,updated_at=now,prior_version_archive=arc,updated_by_generation_id=G);n['properties']=fix(n['properties'])
 for s in n['sources']:
  if s.get('path')in hashes:s['sha256']=hashes[s['path']];s['locator']+=';v2 actual85line gallery metadata correction'
  if 'locator'in s:s['locator']=fix(s['locator'])
(r/arc).write_bytes(gzip.compress((json.dumps(dict(generation_id=G,records=old),ensure_ascii=False,indent=2)+'\n').encode(),mtime=0));(r/'data/graph/nodes.jsonl').write_text(''.join(json.dumps(n,ensure_ascii=False,sort_keys=True)+'\n'for n in nodes));out=r/'reports/reproducibility/20261021-segmentation-demand';(out/'core-check.log').rename(out/'core-before-gallery-line-correction.log');(out/'gallery-scope-repair.json').write_text(json.dumps(dict(actual_gallery_lines=count,prior_nodes=len(old),prior_source_and_ledger=prior,grades_or_application_counts_changed=False),indent=2)+'\n');print({'gallery_lines':count,'prior_nodes':len(old)})
