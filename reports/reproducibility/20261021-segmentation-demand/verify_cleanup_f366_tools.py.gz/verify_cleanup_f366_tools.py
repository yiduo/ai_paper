from pathlib import Path
import json,gzip,hashlib,datetime,subprocess
r=Path('/Users/smzdm/projects/ai_paper');t=Path('/private/tmp/ai-paper-F366-tools');out=r/'reports/reproducibility/20261021-segmentation-demand';sha=lambda b:hashlib.sha256(b).hexdigest();j=json.loads((r/'data/provenance/demand/F-366-segmentation-tool-contracts.json').read_text());a=r/j['source_archive'];raw=gzip.decompress(a.read_bytes());assert sha(a.read_bytes())==j['source_archive_sha256'] and sha(raw)==j['decompressed_sha256'];payload=json.loads(raw)
for k,v in j['sources'].items():assert sha(payload['files'][k].encode())==v['sha256']
for v in j['selected_original_scopes'].values():
 p=t/v['file'];assert sha(p.read_bytes())==v['pdf_sha256'];assert sha(p.with_suffix('.txt').read_bytes())==v['extracted_text_sha256']
old=json.loads(gzip.decompress((r/'data/graph/history/GEN-20261021-040-before.json.gz').read_bytes()))['records'];head={n['id']:n for n in map(json.loads,subprocess.check_output(['git','show','HEAD:data/graph/nodes.jsonl'],cwd=r,text=True).splitlines())}
for n in old:assert n==head[n['id']]
removed=[]
for p in t.iterdir():
 assert p.is_file();removed.append(dict(path=str(p),sha256=sha(p.read_bytes()),bytes=p.stat().st_size,retention='Necessary source/licensebytes in archive;PDF/text hashes andfacts inledger;fullAPIcontacts notretained'));p.unlink()
t.rmdir()
(out/'source-and-cleanup-integrity.json').write_text(json.dumps(dict(recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_members_checked=len(j['sources']),source_archive_sha256=sha(a.read_bytes()),decompressed_sha256=sha(raw),selected_original_pdf_and_text_hashes_checked=2,old_nodes_match_HEAD=len(old),temporary_files_removed=removed,removed_bytes=sum(v['bytes']for v in removed),new_numerical_application_run=False),ensure_ascii=False,indent=2)+'\n');print({'members':len(j['sources']),'prior_nodes':len(old),'removed_bytes':sum(v['bytes']for v in removed)})
