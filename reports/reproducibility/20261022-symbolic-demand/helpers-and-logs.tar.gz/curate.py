from pathlib import Path
import base64, copy, datetime, gzip, hashlib, json

root = Path('/Users/smzdm/projects/ai_paper')
tmp = Path('/private/tmp/ai-paper-F025-demand')
out = root / 'reports/reproducibility/20261022-symbolic-demand'
out.mkdir(parents=True, exist_ok=True)
now = datetime.datetime.now(datetime.timezone.utc).isoformat()
generation = 'GEN-20261022-085'
upstream = '1581d4cbdd69a0faf34b2089614fe2a814316a6a'
commit = '30a3915c898e45f61b225b79c3efc1c9f765d2c5'
digest = lambda b: hashlib.sha256(b).hexdigest()

def write(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')

nodes_path = root / 'data/graph/nodes.jsonl'
edges_path = root / 'data/graph/edges.jsonl'
lines = nodes_path.read_text().splitlines()
nodes = {json.loads(line)['id']: json.loads(line) for line in lines}
old = copy.deepcopy(nodes)
assert len(nodes) == 3538 and generation not in nodes
retrieval = json.loads((tmp / 'retrieval.json').read_text())
issue = json.loads((tmp / 'sympy-issue7221.json').read_text())
comments = json.loads((tmp / 'sympy-issue7221-comments.json').read_text())
assert len(comments) == 20 and issue['comments'] == 10
assert 'shortest result' in issue['body']
assert 'ufrac-dfs' in (tmp / 'dense-ufrac-conjecture.scm').read_text()
assert 'chez -q' in (tmp / 'dense-u_frac.py').read_text()
assert 'keywords.iteritems()' in (tmp / 'eppstein-egypt.py').read_text()

snapshot = root / 'data/provenance/tools/dense-egyptian-30a3915.json.gz'
files = {}
for name in ['README.md', 'LICENSE.txt', 'u_frac.py', 'ufrac-conjecture.scm', 'ufrac.scm']:
    raw = (tmp / ('dense-' + name)).read_bytes()
    files[name] = dict(bytes=len(raw), sha256=digest(raw),
                       lines=len(raw.splitlines()), content_base64=base64.b64encode(raw).decode())
payload = (json.dumps(dict(repository='https://github.com/ChlorophyII/Dense-Egyptian-Fractions',
                          commit=commit, license='MIT', files=files), indent=2) + '\n').encode()
snapshot.write_bytes(gzip.compress(payload, mtime=0))
restored = json.loads(gzip.decompress(snapshot.read_bytes()))
for name, rec in restored['files'].items():
    raw = base64.b64decode(rec['content_base64'])
    assert raw == (tmp / ('dense-' + name)).read_bytes()
    assert digest(raw) == rec['sha256']

derived = []
for name in ['restricted-denominators.txt', 'theorem-page7.png', 'caller-page22.png']:
    raw = (tmp / name).read_bytes()
    derived.append(dict(file=name, bytes=len(raw), sha256=digest(raw)))

findings = [
    'SymPy issue7221 original body requests ordinary proper-rational decomposition and optional shortest-among-methods output; its20 returned comments discuss resource blowup and output tests, not a specified exact-marker request. This is historical public demand, not evidence of a current unresolved feature.',
    'Issue metadata comments=10 differs from the20 returned comment objects. Both response SHAs retained; do not claim a complete issue history or silently replace either count.',
    'Eppstein author-hosted1086-line Python file actually inspected at1-145,700-750,810-1086: constraint predicate, default greedy search, filters, full option definitions and interfaces. Default named greedy enumerates possible denominators; it is not just the one-path Sylvester algorithm.',
    'Eppstein options include length, min/maxdenominator, parity, squares, repeats and enumeration/minimization filters. The inspected option definitions do not expose a required-marker option. The subroutine contains keywords.iteritems(); compatibility was not executed or repaired. No blanket claim about all other methods or software versions.',
    'Martin-Shi2025 author PDF23pages: selected1-2,6-7(Theorem3.2),13-18(selected UFRAC/KILL/early-stop/implementation interfaces),19-20(selected reported costs),21-22(second-largest application). Not a full proof or runtime audit; two actual formula/contract pages7and22 visually checked.',
    'The selected old finite-multiset algorithm returns representations from a finite allowed multiset, with an early-stop variant; a distinct input set is needed for distinct denominators. Finite search and unrestricted short expansion are different output contracts.',
    'A real published mathematical-software caller asks for prescribed second-largest d and largest c*d, with residual target1-1/d-1/(c*d) and bounded remaining denominators. Current pinned Scheme caller sld actually reserves both and calls ufrac-dfs on a constrained range. This establishes related public computational use, not an engineering deployment or an eligible caller for the current single-marker-only APP contract.',
    'Pinned dense-egyptian commit30a3915: full245-line README,105-line Python wrapper,32-line conjecture caller,256-line main Scheme and21-line MIT license read. Source line totals are computed below, not used as research coverage. Transitive Scheme math/branch/multithread/prime modules and witnesses were not downloaded or audited.',
    'Python wrapper actually spawns chez and loads compiled ufrac.so; it is not a standalone Python implementation. No scheme/chez/chezscheme/racket/guile command on current PATH and no SymPy in inspected Python3.12.14 or3.14.8. No install, execution, upstream tests or benchmark; old published timings are author reports, not measured here.',
    'Existing source-guided small-tail prefix does not guarantee two markers, a specified second-largest rank, a finite allowed set, shortest output or maximum denominator. A smaller positive tail excludes reserved reciprocals but can introduce larger denominators, conflicting with rank constraints.',
    'Stop the bounded three-project/source qualification here. Retain APP02501 pending, lower immediate implementation priority; original prediction, conditional-v2 plan, empty run IDs, theory grade and initial-check count unchanged. No global absence inference and no formal rejection.'
]
# Correct the descriptive inventory from actual bytes before the ledger is frozen.
findings[7] = ('Pinned dense-egyptian commit30a3915: full selected files read: ' +
               ', '.join(f'{n}={r["lines"]}lines' for n, r in files.items()) +
               '. Transitive Scheme math/branch/multithread/prime modules and witnesses were not downloaded or audited; no full software proof/compatibility claim.')
ledger = root / 'data/provenance/demand/F-025-demand-followup-20261022.json'
assert not ledger.exists()
write(ledger, dict(work_package='WP-089', generation_id=generation, recorded_at=now,
                  base_local_commit='f2ae293', family_id='F-025', candidate='APP-025-01',
                  scope='Bounded three original source projects; source/consumer qualification, not an application experiment',
                  search_queries=[
                      'site:github.com/sympy/sympy "egyptian_fraction" "denominator" "issue"',
                      '"Egyptian fraction" "include" "specified denominator" software',
                      '"Egyptian fraction" "fixed denominator" "program"',
                      'site:github.com/sympy/sympy/issues "egyptian"',
                      '"EgyptianFraction" "denominators" "Options"',
                      '"egyptian fractions" "required" "denominators" algorithm',
                      'site:ics.uci.edu/~eppstein/numth/egypt "restricted"'],
                  original_source_projects=3,
                  source_groups=['SymPy original issue7221 body and returned comments',
                                 'Eppstein author site and Python CLI',
                                 'Martin-Shi2025 original paper and associated pinned Dense-Egyptian-Fractions implementation'],
                  retrieval=retrieval, temporary_derivatives=derived,
                  failures=[dict(kind='web_pdf_fetch_timeout', url='https://personal.math.ubc.ca/~gerg/papers/downloads/AEFRRD.pdf', resolved_by='normal TLS bounded direct retrieval; exact SHA retained'),
                            dict(kind='web_python_content_unsupported', url='https://ics.uci.edu/~eppstein/numth/egypt/egypt.py', resolved_by='normal TLS bounded raw text retrieval'),
                            dict(kind='raw_README_TLS_EOF', resolved_by='official content API for the same commit; Git blob SHA1 checked; no TLS bypass')],
                  issue=dict(url='https://github.com/sympy/sympy/issues/7221', updated_at=issue['updated_at'], state=issue['state'],
                             body_checked=True, returned_comment_objects=len(comments), metadata_comment_count=issue['comments'],
                             comments_scope='All20returned body texts read, one page; count discrepancy unresolved, no complete history claim',
                             exact_marker_demand_in_checked_text=False),
                  eppstein=dict(url='https://ics.uci.edu/~eppstein/numth/egypt/egypt.py', lines=1086,
                                read_ranges=[[1,145],[700,750],[810,1086]], fully_read=False,
                                actual_runtime_executed=False, redistributed=False,
                                license='No explicit redistribution license observed in selected file; exact hash and paraphrased contract only'),
                  martin_shi=dict(title='An algorithm for Egyptian fraction representations with restricted denominators',
                                  authors=['Greg Martin','Yue Shi'], year=2025, doi='10.2140/involve.2025.18.1',
                                  url='https://personal.math.ubc.ca/~gerg/papers/downloads/AEFRRD.pdf',
                                  pdf_sha256='091fda9c8319208dcf32e95370ead1774c88b7fb596285215d6548bf36b321e8',
                                  selected_scope='Printed1-2;6-7Theorem3.2;13-18selected control/earlystop/implementation;19-20selected author timings;21-22actual second-largest application',
                                  visual_pages=[7,22], full_proof_review=False, runtime_reproduced=False,
                                  source_heading_note='Printed section5.2 says Second-smallest denominators but its explicit task and examples are second-largest; record actual explicit contract, no source correction asserted'),
                  old_software=dict(commit=commit, repository='https://github.com/ChlorophyII/Dense-Egyptian-Fractions',
                                    snapshot=str(snapshot.relative_to(root)), gzip_sha256=digest(snapshot.read_bytes()),
                                    raw_snapshot_sha256=digest(payload), files={n:{k:v for k,v in r.items() if k!='content_base64'} for n,r in files.items()},
                                    license='MIT; full original notice included in compressed snapshot',
                                    exact_marker_related_caller=True, current_APP_contract_eligible=False,
                                    caller_contract='Two fixed largest denominators d,c*d; bounded residual denominator range; not arbitrary single-marker expansion',
                                    transitive_dependencies_read=False, actual_runtime_executed=False),
                  runtime=json.loads((tmp/'runtime-inventory.json').read_text()), findings=findings,
                  decision='Do not install/benchmark the current wrapper solely for card count; retain candidate pending and route actual rank/finite-set constraints to a separate unestablished gate',
                  new_candidate_count=0, new_initial_checks=0, new_application_run=False,
                  original_prediction_unchanged=True, conditional_plan_unchanged=True,
                  source_reading_coverage_unchanged=True, human_review=None, second_model_provider=None))

def local(path, locator):
    return dict(path=str(path.relative_to(root)), sha256=digest(path.read_bytes()), commit=None, locator=locator)

ls = local(ledger, 'WP089 bounded three original-source qualification, exact retrieval/version/scope and limits; not a numerical application test')
ss = local(snapshot, 'Five full selected MIT source/readme/license files; raw byte base64 and member SHAs verified; transitive dependencies unreviewed')
policy = root / 'data/provenance/research-at-generation-085.json'
write(policy, json.loads((root/'configs/research.json').read_text()))

def add(id, kind, title, properties, sources=None, evidence='source_content_checked'):
    assert id not in nodes
    nodes[id] = dict(id=id, kind=kind, version=1, created_at=now, evidence_status=evidence,
                     properties=dict(title=title, family_ids=['F-025'], model_generation_id=generation, **properties),
                     sources=sources or [ls])

add(generation, 'generation', '符号分数真实需求与旧约束搜索核查',
    dict(provider='OpenAI', model='Current user-selected session; exact backend unknown', source_commit=upstream,
         task='Actual original-source consumer qualification; no library execution or application claim', human_review=None, independent_second_provider=None),
    [ls, local(policy,'Frozen research policy')])
add('PROB-025-SYMPY-ORIGINAL-DEMAND', 'problem', '原始请求：普通分解与多个算法的短输出',
    dict(input='Historical public issue7221 proper rational input', output='Denominator list, optional shortest among available algorithms',
         eligibility='Actual original feature request; inspected text does not request an exact marker, current demand not inferred',
         scope='Issue body plus20 returned comment bodies; metadata count differs, no complete issue-history claim'),
    [ls, dict(url='https://github.com/sympy/sympy/issues/7221', locator='Original issue body and returned comments37009139..37009159, excluding absent37009142; historical requirements/resource concern, not new measurements', content_checked=True, checked_at=now)])
add('PART-025-BOUNDED-OLD-SEARCH', 'method', '旧工具：受长度及分母约束的回溯搜索',
    dict(input='Author-hosted Eppstein Python CLI; rational and length/minmax/parity/square/repeat options',
         output='First/all/shortest/minmax streams subject to selected options',
         conditions=['Actual selected option/search/filter bodies read; default greedy enumerates branches', 'No required-marker option in inspected option definitions', 'No runtime execution or unreviewed method correctness claim'],
         cannot_transfer='Not a source of measured speed, arbitrary marker demand or validated Python subroutine compatibility', credibility='unknown', dependency_closure_complete=False),
    [ls, dict(url='https://ics.uci.edu/~eppstein/numth/egypt/egypt.py', locator='Exact retrieved SHA effc73f59f155d6f544691f280fee391e62e830982f26d5f2ce31a47d401e899; selected lines1-145,700-750,810-1086; file not redistributed', content_checked=True, checked_at=now)])
add('LIT-025-MARTIN-SHI-2025', 'literature', '受限分母的有限多重集算法：选定范围',
    dict(credibility='C', dependency_closure_complete=False, content_verified=True, selected_only=True,
         original_link='https://personal.math.ubc.ca/~gerg/papers/downloads/AEFRRD.pdf',
         original_scope='Theorem3.2 printed7;selected control/earlystop/implementation printed13-18;actual constrained caller printed21-22;not whole proof',
         checked_scope_summary='Finite allowed multiset enumeration and early-stop existence differ from unrestricted length; real software use constrains two largest denominators.'),
    [ls, dict(url='https://doi.org/10.2140/involve.2025.18.1', locator='DOI printed on actually retrieved author PDF; publisher endpoint not separately visited', content_checked=True, checked_at=now)])
add('PART-025-FINITE-SET-OLD-SEARCH', 'method', '旧零件：有限允许分母集的精确搜索接口',
    dict(input='Finite allowed positive integer set/multiset D and nonnegative exact rational r',
         output='All submultiset representations or one/false early-stop result',
         conditions=['Distinct input set when distinct denominator output required', 'Pinned code wrapper requires Chez compiled ufrac.so', 'Only selected5files read; transitive dependencies and source algorithm correctness not fully audited'],
         cannot_transfer='No local execution, polynomial runtime, unlimited marker coverage or new F025 increment established', credibility='C', dependency_closure_complete=False), [ls, ss])
add('PROB-025-SECOND-LARGEST-MARKER', 'problem', '真实旧调用：固定第二大及最大分母',
    dict(input='d>=5, selected integer c>1 and bounded residual denominator list',
         output='Exact distinct expansion of1 with largest pair d,c*d; all residual denominators below d',
         eligibility='Actual published computational problem and source caller; not the current single-marker-only APP contract',
         caller='Pinned ufrac-conjecture.scm sld reserves d,c*d, subtracts both, calls ufrac-dfs; transitive execution unresolved',
         author_result_not_reproduced='Reported witnesses up to6000 are not independently verified here'), [ls, ss])
add('PART-025-CALLER-CONSTRAINTS-GATE', 'method', '实际调用约束与单标记构造的缺口',
    dict(input='Actual rank/finite-set/two-marker demand versus current arbitrary single-marker small-tail wrapper',
         output='Explicit eligible caller and a source-supported construction preserving all caller constraints',
         conditions=['Keep two markers and denominator rank constraints if using the published caller', 'Positive-tail separation does not bound newly introduced denominators', 'Do not silently replace actual demand by a weaker one or install a runtime merely for initial-card credit'],
         cannot_transfer='No established eligible caller, strong implemented cost comparison or independent answer test; original functional hypothesis not tested',
         prerequisite_status='unestablished', unestablished=True, credibility='unknown', dependency_closure_complete=False))
add('CHECK-025-CONSUMER-QUALIFICATION', 'review', '三项原始来源的有界需求复核',
    dict(review_type='Current OpenAI source qualification, not external application validation', result=findings,
         initial_check_eligible=False, numerical_application_run=False, independent_provider=False, human_review=False,
         exact_APP_consumer_established=False, related_constrained_public_caller_observed=True,
         selected_software_files=len(files), selected_formula_pages=2), [ls, ss])

changed = ['APP-025-01','PART-025-CONSUMER-GATE','PART-025-SYMPY-RUNTIME-GATE']
prior = (json.dumps(dict(records=[old[k] for k in changed], recorded_at=now,
                         reason='Actual bounded original-source followup distinguishes related constrained demand from eligible single-marker consumer; keep original scientific hypothesis/plan/status'),
                    ensure_ascii=False, indent=2) + '\n').encode()
archive = root/'data/graph/history/GEN085-symbolic-demand-before.json.gz'
archive.write_bytes(gzip.compress(prior, mtime=0))
assert gzip.decompress(archive.read_bytes()) == prior
for id in changed:
    n = nodes[id]
    n.update(version=n['version']+1, updated_at=now, updated_by_generation_id=generation, prior_version_archive=str(archive.relative_to(root)))
    n['properties']['previous_version'] = dict(path=str(archive.relative_to(root)), sha256_uncompressed=digest(prior),
                                             reason='Actual demand qualification; no prediction or experimental result change')
    n['sources'].append(ls)
p = nodes['PART-025-CONSUMER-GATE']['properties']
p.update(input='Actual positive distinct-unit-fraction caller; related bounded two-marker/rank demand now observed',
         conditions=['SymPy original generic output request does not establish exact marker demand',
                     'Published second-largest caller imposes two markers and finite/rank restrictions absent from current wrapper',
                     'No eligible exact current-contract caller or representative frozen workload established in inspected scope'],
         cannot_transfer='Related public computational demand is real; current single-marker wrapper does not establish satisfaction of those additional constraints',
         prerequisite_status='unestablished', followup_gate_ids=['PART-025-CALLER-CONSTRAINTS-GATE'], demand_followup_id='CHECK-025-CONSUMER-QUALIFICATION')
p = nodes['PART-025-SYMPY-RUNTIME-GATE']['properties']
p.update(conditions=['SymPy absent in current inspected Python3.12.14 and3.14.8; no eligible caller established',
                     'Old finite-set Python wrapper requires Chez, not standalone Python; no relevant Scheme command on inspected PATH',
                     'No package install, library execution, benchmark or upstream test performed'],
         runtime_inventory_at=now, prerequisite_status='unestablished')
p = nodes['APP-025-01']['properties']
p.update(demand_followup_id='CHECK-025-CONSUMER-QUALIFICATION',
         priority_reason='Lower immediate implementation priority after bounded three-source qualification: related real two-marker/rank demand is not satisfied by current wrapper; strong old constrained search already exists',
         revisit_when='An actual caller matching this exact single-marker contract, or a separately justified source-supported construction preserving published two-marker/rank/finite-set constraints; qualify runtime/strong old full-cost baseline, then freeze requests before outputs.',
         revision_generation_id=generation)
p['limitations'] = ['No eligible caller for current single-marker-only contract established in the bounded three original-source projects',
                    'Related published second-largest-denominator caller is real but adds a second marker, rank and finite allowed-denominator constraints',
                    'SymPy absent in current inspected runtimes; finite-set old Python wrapper additionally requires unavailable Chez commands',
                    'No implemented short-asymptotic constructor/effective finite constant or full-cost comparison run',
                    'No exact-k/multiple-marker/optimality/maxdenominator guarantee; old finite-set search is not measured here']
p['summary'] = dict(status='bounded_consumer_qualification_no_eligible_caller', supported=None, initial_check_eligible=False)
for k in ['prediction','test_spec','run_ids','application_result','workflow','theoretical_grade','source_claim_grade','dedup_key']:
    assert p[k] == old['APP-025-01']['properties'][k], k

new_edges = []
edge_ids = {json.loads(line)['id'] for line in edges_path.read_text().splitlines()}
def edge(a, relation, b, locator):
    id = 'E-' + digest((a+'|'+relation+'|'+b).encode())[:16].upper()
    assert id not in edge_ids
    edge_ids.add(id)
    new_edges.append(dict(id=id, source=a, relation=relation, target=b, version=1,
                          evidence_status='source_content_checked', source_locator=locator,
                          source_commit=upstream, created_at=now))
for id in set(nodes)-set(old)-{generation}:
    edge(id,'generated_by',generation,'Actual WP089 bounded source qualification; no new application run')
for a,b in [('PART-025-FINITE-SET-OLD-SEARCH','LIT-025-MARTIN-SHI-2025'),
            ('PROB-025-SECOND-LARGEST-MARKER','PART-025-FINITE-SET-OLD-SEARCH'),
            ('PART-025-CALLER-CONSTRAINTS-GATE','PROB-025-SECOND-LARGEST-MARKER'),
            ('PART-025-CALLER-CONSTRAINTS-GATE','PROB-025-SYMPY-ORIGINAL-DEMAND')]:
    edge(a,'uses',b,'Scope comparison preserves all actual caller constraints; not a new application claim')
edge('PART-025-CONSUMER-GATE','depends_on','PART-025-CALLER-CONSTRAINTS-GATE','Eligible caller remains unestablished after actual source qualification')
edge('CHECK-025-CONSUMER-QUALIFICATION','reviews','APP-025-01','Original prediction/status/runIDs unchanged; no initial-check credit')
edge('CHECK-025-CONSUMER-QUALIFICATION','reviews','PART-025-BOUNDED-OLD-SEARCH','Selected source contract and runtime limits only')
edge('CHECK-025-CONSUMER-QUALIFICATION','reviews','PART-025-FINITE-SET-OLD-SEARCH','Selected pinned interfaces and actual related caller; transitive execution not checked')
edge('APP-025-01','compared_with','PART-025-BOUNDED-OLD-SEARCH','Strong old bounded search must not be confused with one-path unmarked default baseline')
edge('APP-025-01','compared_with','PART-025-FINITE-SET-OLD-SEARCH','Finite allowed-set exact old solver is a distinct comparator when constraints matter; not executed')
nodes_path.write_text('\n'.join(json.dumps(nodes[json.loads(line)['id']],ensure_ascii=False,sort_keys=True)
                                if json.loads(line)['id'] in changed else line for line in lines)+'\n'+
                      ''.join(json.dumps(nodes[id],ensure_ascii=False,sort_keys=True)+'\n' for id in nodes if id not in old))
with edges_path.open('a') as f:
    for e in new_edges:
        f.write(json.dumps(e,ensure_ascii=False,sort_keys=True)+'\n')
receipt = dict(generation_id=generation, canonical_before=len(old), canonical_after=len(nodes),
               new_records=len(nodes)-len(old), changed_old_ids=changed, exact_old_versions=len(changed),
               old_unchanged=len(old)-len(changed), new_explicit_edges=len(new_edges),
               primary_source_projects=3, new_candidate=0, new_initial_check=0, new_application_run=False,
               related_constrained_caller_observed=True, exact_APP_caller_established=False,
               original_prediction_and_plan_unchanged=True, source_coverage_unchanged=True,
               dependencies_installed=False, original_formula_pages_pixels=2,
               source_snapshot_gzip_bytes=snapshot.stat().st_size)
write(out/'curation-summary.json',receipt)
print(json.dumps(receipt))
