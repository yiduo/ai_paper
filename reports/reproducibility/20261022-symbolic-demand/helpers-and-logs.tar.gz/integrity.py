from pathlib import Path
import subprocess,json,gzip,hashlib,datetime,sys
r=Path('/Users/smzdm/projects/ai_paper');sys.path.insert(0,str(r/'src'))
from ai_value.graph import load,impact_report,theoretical_grade
o=r/'reports/reproducibility/20261022-symbolic-demand';sha=lambda x:hashlib.sha256(x).hexdigest()
before=subprocess.check_output(['git','show','HEAD:data/graph/nodes.jsonl'],cwd=r).decode().splitlines();after=(r/'data/graph/nodes.jsonl').read_text().splitlines();a={json.loads(l)['id']:l for l in before};b={json.loads(l)['id']:l for l in after};changed=['APP-025-01','PART-025-CONSUMER-GATE','PART-025-SYMPY-RUNTIME-GATE'];assert len(a)==3538 and len(b)==3546;assert all(a[k]==b[k] for k in a if k not in changed)
prior=json.loads(gzip.decompress((r/'data/graph/history/GEN085-symbolic-demand-before.json.gz').read_bytes()))['records'];p={x['id']:x for x in prior};assert all(json.loads(a[k])==p[k] for k in changed)
assert (r/'data/graph/edges.jsonl').read_bytes().startswith(subprocess.check_output(['git','show','HEAD:data/graph/edges.jsonl'],cwd=r))
paths=['experiments/plans/APP-025-01-conditional.json','experiments/plans/APP-025-01-conditional-v2.json','data/graph/reading_coverage.json','data/provenance/readings/F-025.json','data/provenance/demand/F-025-symbolic-consumer.json','data/provenance/tools/sympy-unit-fractions-16fa855.json.gz']
for path in paths:assert (r/path).read_bytes()==subprocess.check_output(['git','show','HEAD:'+path],cwd=r)
app=json.loads(b['APP-025-01'])['properties'];old=json.loads(a['APP-025-01'])['properties']
for field in ['prediction','run_ids','test_spec','theoretical_grade','source_claim_grade','analogy','dedup_key','application_result','workflow']:assert app[field]==old[field],field
assert app['summary']['initial_check_eligible'] is False and not app['run_ids']
nodes,edges=load(r);cases=[]
for seed,yes,no in [
 ('PART-025-CALLER-CONSTRAINTS-GATE',['PART-025-CONSUMER-GATE','APP-025-01'],['CLM-025-LEM-MARKED-GREEDY-PREFIX','APP-094-02']),
 ('PROB-025-SECOND-LARGEST-MARKER',['PART-025-CALLER-CONSTRAINTS-GATE','APP-025-01'],['CLM-025-LEM-MARKED-GREEDY-PREFIX','APP-332-01']),
 ('PROB-025-SYMPY-ORIGINAL-DEMAND',['PART-025-CALLER-CONSTRAINTS-GATE','APP-025-01'],['CLM-025-LEM-MARKED-GREEDY-PREFIX']),
 ('PART-025-FINITE-SET-OLD-SEARCH',['PROB-025-SECOND-LARGEST-MARKER','APP-025-01'],['APP-094-02']),
 ('LIT-025-MARTIN-SHI-2025',['PART-025-FINITE-SET-OLD-SEARCH','APP-025-01'],['CLM-025-LEM-MARKED-GREEDY-PREFIX']),
 ('PART-025-BOUNDED-OLD-SEARCH',[],['APP-025-01','CLM-025-LEM-MARKED-GREEDY-PREFIX']),
 ('CHECK-025-CONSUMER-QUALIFICATION',[],['APP-025-01','CLM-025-LEM-MARKED-GREEDY-PREFIX']),
 ('PART-025-SYMPY-RUNTIME-GATE',['APP-025-01'],['APP-094-02','CLM-025-LEM-MARKED-GREEDY-PREFIX']),
]:
 assert {seed,*yes,*no}<=set(nodes)
 report=impact_report(nodes,edges,{seed});affected=set(report['affected']);assert set(yes)<=affected,(seed,yes,affected);assert not set(no)&affected,(seed,no,affected);cases.append(dict(seed=seed,required=yes,excluded=no,affected=sorted(affected)))
local=external=0
for n in map(json.loads,after):
 for source in n['sources']:
  if 'path' in source:assert sha((r/source['path']).read_bytes())==source['sha256'],(n['id'],source['path']);local+=1
  else:external+=1
assert theoretical_grade(nodes,edges,'APP-025-01')=='unknown'
out=dict(recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),old_unchanged=3535,exact_prior_versions=3,new_canonical=8,new_explicit_edges=17,all_old_edges_exact=True,unchanged_source_and_plan_paths=paths,prediction_and_application_status_unchanged=True,local_source_hashes_verified=local,external_annotations=external,canonical_citations=local+external,impact_cases=cases,candidates=40,application_initials=13,effective_leads=5,new_application_run=False,full_family_or_history_promoted=False)
(o/'integrity.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:out[k] for k in ['local_source_hashes_verified','external_annotations','canonical_citations']})+';8impactcasespassed')
