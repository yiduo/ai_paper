from pathlib import Path
import datetime, gzip, hashlib, json, os, subprocess, sys

root = Path('/Users/smzdm/projects/ai_paper')
out = root / 'reports/reproducibility/20261022-symbolic-demand'
receipts = []
for experiment in ['EXP-200-001', 'EXP-332-001']:
    folders = list((root/'experiments/runs').glob(experiment+'-*'))
    assert len(folders) == 1
    process = subprocess.run([sys.executable, 'scripts/replay_run.py', str(folders[0])],
                             cwd=root, env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'),
                             capture_output=True, timeout=320)
    payload = json.dumps(dict(recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                               experiment=experiment, returncode=process.returncode,
                               stdout=process.stdout.decode(), stderr=process.stderr.decode()), indent=2).encode()+b'\n'
    path = out/('replay-'+experiment+'.json.gz')
    path.write_bytes(gzip.compress(payload, mtime=0))
    assert gzip.decompress(path.read_bytes()) == payload
    assert process.returncode == 0, process.stderr.decode()
    report = json.loads(process.stdout)
    assert all(report['deterministic_outputs_match'].values())
    receipts.append(dict(experiment=experiment, path=str(path.relative_to(root)),
                         uncompressed_sha256=hashlib.sha256(payload).hexdigest(),
                         comparison_scope=report['comparison_scope']))
    print(experiment, 'actual archived-source replay passed', flush=True)
(out/'representative-replays.json').write_text(json.dumps(receipts,indent=2)+'\n')
