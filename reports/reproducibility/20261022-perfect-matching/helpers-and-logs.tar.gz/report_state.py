from pathlib import Path
import json,datetime
r=Path('/Users/smzdm/projects/ai_paper');now=datetime.datetime.now(datetime.timezone.utc).isoformat()
q=json.loads((r/'reports/reproducibility/20261022-perfect-matching/integrity.json').read_text())
s=json.loads((r/'reports/reproducibility/20261022-perfect-matching/curation-summary.json').read_text())
p=r/'reports/perfect-matching-F113-reading.md'
p.write_text('''# F113：匹配计数、边际熵与有限成本接口

2026-10-22，WP090／GEN-20261022-086。由规范图谱中的 ANALYSIS-F-113、62 项 CLM-113-*、26 项方法／构造和三个未建立的应用前提支撑；[逐文件读取、散列、版本和范围台账](../data/provenance/readings/F-113.json)、[派生全文草稿](families/F-113.md)可逐项核对。这里记录来源主张和本地单模型核对，不宣告数学证明审核或工程收益。

两篇当前手稿实际读完全部 16 个 TeX 文件 7,035 行、326 行外置书目、两个 README；第一篇书目嵌入正文。输入闭包含所有正文、附录和图源，无遗漏的 TeX 模块。62 个具名结果分别绑定到稿件与文件；三个标签别名不另计。同名 thm:main 在两篇中是两个不同结果。48 个书目绑定对应 44 个外部作品和一条内部伴随稿引用；共享三个明确同一作品的记录，两个 Edmonds1965 实为不同论文，按身份分开。

## 来源接口与应用边界

| 来源范围 | 输入与输出 | 必须保留的条件 |
| --- | --- | --- |
| 第一篇 thm:main | 显式有限无权简单无向图 → 相对误差 epsilon 的非负有理计数估计 | 概率至少 1-delta，零计数所有随机带都返回零；所有执行的最坏位时间多项式，并无实际小成本保证 |
| 第一篇规定度推论 | 显式简单宿主的 f-factor／固定大小匹配 → 计数与可行近似均匀采样 | 实际使用常纤维规约，因子为 product(deg-f)! 或 (n-2k)!；保见证不自动保计数；额外连通、排名、带权约束不随之成立 |
| 第一篇 deletion-sampler | 计数器＋精确子问题可行性 → 始终可行、TV 误差 tau 的样本 | 独立新计数、可行回退、成本多项式于 tau^-1；不是精确均匀，也不自动具有旧二部采样的 log(tau^-1) 精度成本 |
| 第二篇 ent:main | 可行边际 x → 最大匹配律熵 H 的上下界 | F-(2-2/m)B≤H≤F，所有奇割、边界及平行边标签都保留；H 是指定均值下最大熵，不是任意经验分布的熵 |
| 第二篇确定性计数 | 二进制 pair multiplicities／compact n → N/512^n≤A≤N 整数 | 多项式位时间、精确零；并非相对 epsilon 保证；不展开巨大重数 |
| 第二篇 singleton-loop | 二进制单点覆盖／pair multiplicities → N/2^(18n)≤A≤N 有理数 | singleton loop 覆盖一个顶点，不是普通图论自环的二度贡献；不是第一篇带权 FPRAS 推广 |

关键方法链已入图：逻辑瓶颈容量→奇长度细分→两袋标签→带标记可观测量；有符号四边形恒等式→稀有上下文概率抵消→仅加性 pair-energy→多层副本完整链隙。pair-energy 不适用于任意联合函数，完整 gap 中的 L 被巨大副本数和更新数隐藏，不能当常数成本。单位活性袋 DP 在理想有理分类抽样下精确，固定公平比特实现有受控 TV 误差。失败历史也有最坏时间／位数上限，行平衡主要服务于准确率和 inflation 界。

熵链保留实际匹配多面体、最小面的相对切空间、协方差核、固定坐标移除、奇割收缩省下的 |C|-1 个约束以及先严格系数再取极限。三角展开只给 cut-one 面的仿射对应；Klee 例说明几何余维界锐性，不证明熵系数 2 最优。旧八顶点校准不是新实验。数值算法采用更保守加权 bracket、dyadic 插值、完整图可行性修复和精确 penalty，再作固定网格 ascent；单位增广的时间依赖数值容量 C，只有本构造的 C 有多项式数值界。

## 选定形式化与历史核对

六个 Comparator 配置、挑战规格及实际解答入口已读：FPRAS、精化 pointwise 熵、旧 coefficient-eight 熵、binary count、singleton loop、triangle local face。六个对应来源结果局部 B，剩余 56 项保守标 C，完整依赖均未知；没有 A、人审或本地 Lean／Comparator 构建。挑战里的 sorry 是参考占位，不据此判解答失败。固定 formalization.yaml 的标题登记只含熵，而实际 FPRAS 配置／入口存在，两种事实分别记录。

六根静态导入闭包的唯一并集为 **592 文件／9,217 声明**，来源散列及 gzip 回解已核对；没有本地词法占位或 axiom。它只是索引，不能计为读完所有证明、成功 elaboration、外部 Mathlib 依赖审核或证明有效证据。

实际选读三个原始作品的五项范围，并查看两张当前手稿和三张原文公式页面像素：

- Jerrum–Sinclair–Vigoda 的作者 [2001 会议版](https://people.eecs.berkeley.edu/~sinclair/perm2.pdf)第 1–2 页主定理及 §2.1：旧二部非负矩阵永久式已有相对计数与 TV 采样基线。2004 期刊作者站点返回 403；会议版不是期刊版原字节，后者未声称已审核。
- Štefankovič–Vigoda–Wilmes 的 [1712.07504v1](https://arxiv.org/pdf/1712.07504v1)定义 2.1／定理 2.2 与证明、算法 1／定理 4.1–4.3：仅按洞模式加权的旧链存在小质量／慢混合障碍；限制不针对所有算法。其 Gallai–Edmonds 旧递归在因子临界 order 有界时可行，order 在该文指耳数；旧递归还能高效处理慢混合示例。因此不能把该示例直接当新方法收益案例。
- Anari–Oveis Gharan–Vinzant 的 [FOCS 2018 版](https://ieee-focs.org/FOCS-2018-Papers/pdfs/59f035.pdf)印刷第 38 页 §I.D／猜想 6：实际匹配多面体上的二元边际熵最大化是原问题，不是后来版本的编号，也不是只检查度数的盒优化。

未把这些选段称为完整历史：其余原始作品、2026 更快永久式／高斯截断路线及全部传递证明仍未审核。两篇 catalogue 路径在两批清单相同，固定历史索引没有 F113 替换行；这不证明所有 Git 或远程历史没有修订。

## 映射与下一步

十域尝试逐项保留在 XPL-113-TEN-DOMAINS，覆盖生物、金融、交通、能源、语言、艺术、物流、材料、机器人和云计算。当前没有已建立的实际消费者、预算、输入侧约束和独立裁判，不强造候选或初检。二部／平面／小参数旧方法可能已足够，不能只与“找一个匹配”的存在性算法比较。

三项跨族比较分别保留 F120 的保见证／常计数纤维区别，F115 的均匀表／阶乘权重／边子集律区别，F131 精确有理采样／固定比特 TV 近似和停止成本区别。下一 WP091 限量核对真实完美匹配／规定度计数的公开软件调用与强旧基线，先验证计数语义和预算，再考虑冻结数值规格；不会运行手选小图来增加初检数量。

本包 143 新规范记录、391 条显式关系，3,546 条旧规范及全部旧边原字节不变。当前完整图 6,155 节点／16,146 边；6,106 条规范来源注释，其中 6,096 属核心类型，5,701 本地散列／405 外部注释分列。49 阅读族／43 全文草稿，1,123 带标签结果＋2 无标签主定理；F238 的 95 个部分绑定另列。40 候选、13 初检／不同假设、5 限定支持／8 不利观察不变；完整族、完整谱系、人审和第二供应商仍为零。质量与存储收据见 [复现目录](reproducibility/20261022-perfect-matching/)。`math/` 版本及工作区未变，没有克隆、复制部署、缓存或依赖安装。
''')
# Update current headline facts; historical entries remain dated records.
p=r/'README.md';s0=p.read_text().replace('48族有实际阅读','49族有实际阅读').replace('其中42族为全文拆解草稿，共1061','其中43族为全文拆解草稿，共1123').replace('5980节点、15482关系、5833条规范来源注释（其中5823','6155节点、16146关系、6106条规范来源注释（其中6096');s0+='\n[F113两稿全文与计数接口](reports/perfect-matching-F113-reading.md)：62项结果、26契约及三前提缺口已入图；无权相对计数／二进制粗计数、最大律熵／任意观测熵、保见证／保计数分别保留。六个选定形式规格局部B，未构建／无人审；没有新候选或应用实验。\n';p.write_text(s0)
p=r/'README.en.md';s0=p.read_text();s0=s0.replace('keeps all unmet phase-one targets and selects unread F113 next.','keeps all unmet phase-one targets. F113 is now read in full; [its scope report](reports/perfect-matching-F113-reading.md) separates relative counting, coarse deterministic counting, entropy, and sampling. The next package qualifies actual counting consumers and strong old baselines.');p.write_text(s0)
p=r/'PROGRESS.en.md';s0=p.read_text().replace('after WP-089 and global retrospective 032','local snapshot after WP-090; one substantive package after retrospective 032').replace('48/372 families, about 12.9%','49/372 families, about 13.2%').replace('42/372, about 11.3%','43/372, about 11.6%').replace('1,061 labelled results','1,123 labelled results').replace('5,980 nodes; 15,482 relations; 5,833 canonical citation annotations (5,823','6,155 nodes; 16,146 relations; 6,106 canonical citation annotations (6,096')
start=s0.index('WP-087 actually read');end=s0.index('\n## Latest application check',start)
s0=s0[:start]+'''WP-090 actually read both F113 manuscripts in full: 16 TeX files and 7,035 lines, the 326-line bibliography, and both READMEs. It adds 62 source-result bindings, 26 transferable contracts, three explicit application gaps, and five selected historical interfaces from three original works. Three aliases are not extra results. Six selected registered formal endpoints were compared with source statements; they have local B grades without a build or human review. The other 56 claims remain source C and full dependency grades remain unknown. A six-root static index covers 592 unique local files and 9,217 declarations; this is not proof verification.

The source's relative-error counter accepts explicit unweighted simple graphs. Its deterministic companion handles binary multiplicities with a much coarser factor, and its entropy bound concerns the maximum law at feasible marginals. Those interfaces are preserved separately. Ten-domain and three cross-family attempts establish no new qualified application or numerical benefit. See [source scope and evidence](reports/perfect-matching-F113-reading.md).
''' +s0[end:]
start=s0.index('[Global retrospective 032]',s0.index('## Next research package'));end=s0.index('\nHuman review',start)
s0=s0[:start]+'''WP-091 will qualify actual public perfect-matching or prescribed-degree counting consumers and strong existing baselines. It will distinguish a real count requirement from finding one feasible or optimal matching, preserve weights and other constraints, and check finite cost before any preregistered numerical experiment. The next regular retrospective is due after WP-092, or earlier major evidence. [Retrospective 032](reports/retrospectives/032-demand-constraints-and-next-counting-route.md) remains the current global decision.
''' +s0[end:]
s0+='\nPublication boundary: the last remotely verified scientific snapshot is commit `98c32a6` through WP-089/retrospective 032. WP-090 and this updated local progress document require a separately verified synchronization; local saving is not a public push.\n';p.write_text(s0)
p=r/'docs/roadmap.md';s0=p.read_text().replace('四十八族有实际阅读','四十九族有实际阅读').replace('/332/153四十二族全文草稿1061','/332/153/113四十三族全文草稿1123').replace('470次十域尝试及十七项需求反查不等于487候选','480次十域尝试及十七项需求反查不等于497候选');s0+='\nWP090完成F113两篇7035TeX＋326Bib全文、62结果／26契约／三前提缺口、六形式入口与三原始作品五范围核对；43全文草稿1123带标签结果，完整族／历史仍0。下一WP091限量核实际匹配／f-factor计数调用，先核权重／额外约束／旧基线及成本，不运行已知小例增加初检。复盘032后计数1；WP092后复盘033。\n';p.write_text(s0)
p=r/'state/status.md';s0=p.read_text();head,rest=s0.split('\n\n四十候选',1);head=head.replace('5980节点、15482关系','6155节点、16146关系').replace('5833条来源注释（其中5823','6106条来源注释（其中6096').replace('四十八族有实际阅读','四十九族有实际阅读').replace('/332/153四十二族全文草稿，共1061','/332/153/113四十三族全文草稿，共1123').replace('470次十域尝试及十七项公开需求反查不等于487候选；1061','480次十域尝试及十七项公开需求反查不等于497候选；1123');s0=head+'\n\n四十候选'+rest;s0+='\nWP090实际完成：两稿16TeX7035＋326Bib全文，62结果／三别名、26契约／三前提缺口、44外部作品的48书目绑定、三原文五选段与五公式页像素入GEN086。六选定Lean入口局部B／其余56C／全链未知，静态并集592文件9217声明不等于构建。143新规范391显式边，3546旧规范／旧边原字节不变；无新候选／初检／运行。49阅读43全文草稿1123标签＋2无标签，F238另95；完整族／历史／真人仍0。下一WP091核真实计数调用与旧基线，复盘计数1。当前WP090本地保存，公开快照仍98c32a6通过WP089；后续同步须单独核验。\n';p.write_text(s0)
print('Source report and bilingual current progress updated;historical dated records preserved;WP090 quality completion pending.')
