from pathlib import Path
import json,gzip,hashlib,subprocess,sys,datetime
r=Path('/Users/smzdm/projects/ai_paper');sys.path.insert(0,str(r/'src'))
from ai_value.graph import load,impact_report,theoretical_grade
from ai_value.source_results import named_results
o=r/'reports/reproducibility/20261022-perfect-matching';sha=lambda b:hashlib.sha256(b).hexdigest()
old=subprocess.check_output(['git','show','HEAD:data/graph/nodes.jsonl'],cwd=r);new=(r/'data/graph/nodes.jsonl').read_bytes();assert new.startswith(old)
assert (r/'data/graph/edges.jsonl').read_bytes().startswith(subprocess.check_output(['git','show','HEAD:data/graph/edges.jsonl'],cwd=r))
assert gzip.decompress((r/'data/graph/history/GEN086-reading-coverage-before.json.gz').read_bytes())==subprocess.check_output(['git','show','HEAD:data/graph/reading_coverage.json'],cwd=r)
canon=[json.loads(l) for l in new.splitlines()];assert len(old.splitlines())==3546 and len(canon)==3689
nodes,edges=load(r);local_count=external_count=0
for n in canon:
 for s in n['sources']:
  if 'path'in s:assert sha((r/s['path']).read_bytes())==s['sha256'],(n['id'],s['path']);local_count+=1
  else:external_count+=1
claims=[n for n in canon if n['id'].startswith('CLM-113-')];assert len(claims)==62
assert sum(n['properties']['credibility']=='B' for n in claims)==6
assert sum(n['properties']['credibility']=='C' for n in claims)==56
assert all(theoretical_grade(nodes,edges,n['id'])=='unknown' for n in claims)
a=nodes['ANALYSIS-F-113']['properties'];assert len(a['result_ids_by_label'])==62 and len(a['source_sections'])==16
assert sum(len(x['properties']['natural_label_aliases']) for x in claims)==3
for path,mapping in a['result_ids_by_source'].items():assert {v['label'] for v in named_results((r/path).read_text())}==set(mapping)
assert a['historical_references_by_key']['F::Edmonds1965']!=a['historical_references_by_key']['E::Edmonds1965']
assert a['historical_references_by_key']['F::JerrumSinclairVigoda2004']==a['historical_references_by_key']['E::JerrumSinclairVigoda2004']
assert len([n for n in canon if n['kind']=='connection'])==40
assert not a['full_family_complete'] and not a['historical_lineage_complete']
# Frozen experiment specs/runs and all former research inputs remain byte-identical.
unchanged=[]
for directory in ['experiments','src','tests','configs']:
 result=subprocess.check_output(['git','diff','--name-only','HEAD','--',directory],cwd=r,text=True);assert not result,result
 for p in (r/directory).rglob('*'):
  if p.is_file() and '__pycache__' not in str(p):unchanged.append(str(p.relative_to(r)))
cases=[]
for seed,yes,no in [
('CLM-113-F-LEM-FOUR-HOLES',['CLM-113-F-THM-LOGICAL-HOLE-BOUND','CLM-113-F-THM-MAIN'],['CLM-113-E-ENT-MAIN','CLM-113-E-THM-MAIN','APP-120-01']),
('CLM-113-F-THM-PAIR-ENERGY',['CLM-113-F-LEM-REPLICA-GAP','CLM-113-F-THM-BAG-SAMPLER','CLM-113-F-THM-MAIN'],['CLM-113-E-ENT-MAIN','CLM-113-E-THM-MAIN']),
('CLM-113-F-LEM-FINITE-RANDOM-CHOICE',['CLM-113-F-THM-MAIN','CLM-113-F-COR-PRESCRIBED-DEGREE'],['CLM-113-E-THM-MAIN','CLM-113-E-ENT-MAIN']),
('CLM-113-E-GEOM-PROP-RANK',['CLM-113-E-ENT-MAIN','CLM-113-E-CONS-WEIGHTED'],['CLM-113-F-THM-MAIN','CLM-113-E-THM-MAIN','CLM-113-E-EX-LEM-EXPANSION-FACE']),
('CLM-113-E-D-LEM-UNIT-MINCUT',['CLM-113-E-D-LEM-ODD-CUT-ORACLE','CLM-113-E-THM-MAIN','CLM-113-E-C-PROP-LOOPS'],['CLM-113-F-THM-MAIN','CLM-113-E-ENT-MAIN']),
('CLM-113-E-EX-LEM-EXPANSION-FACE',['CLM-113-E-EX-PROP-KLEE-FACE','CLM-113-E-EX-COR-COEFFICIENT'],['CLM-113-E-ENT-MAIN','CLM-113-F-THM-MAIN','CLM-113-E-GEOM-PROP-RANK']),
('PART-113-REAL-COST-GAP',['XPL-113-TEN-DOMAINS'],['CLM-113-F-THM-MAIN','CLM-113-E-THM-MAIN','CLM-113-E-ENT-MAIN','APP-115-01']),
('PART-120-FACTOR-NETWORK',[],['CLM-113-F-COR-PRESCRIBED-DEGREE','CLM-113-F-THM-MAIN','XPL-113-TEN-DOMAINS']),
('HIST-113-SVW-OBSTRUCTION',[],['CLM-113-F-THM-MAIN','CLM-113-E-THM-MAIN','XPL-113-TEN-DOMAINS']),
('PART-113-MARGINAL-FEASIBILITY-GAP',['XPL-113-TEN-DOMAINS'],['CLM-113-E-ENT-MAIN','CLM-113-E-THM-MAIN','CLM-113-F-THM-MAIN'])]:
 out=impact_report(nodes,edges,{seed});affected=set(out['affected']);assert set(yes)<=affected,(seed,yes);assert not set(no)&affected,(seed,set(no)&affected)
 cases.append(dict(seed=seed,required=yes,excluded=no,affected=sorted(affected)))
ledger=json.loads((r/'data/provenance/readings/F-113.json').read_text());idx=ledger['formal_scope']['indices'];seen={}
for x in idx['roots']:
 p=r/x['path'];assert sha(p.read_bytes())==x['sha256'];raw=gzip.decompress(p.read_bytes());assert sha(raw)==x['uncompressed_sha256']
 for f in json.loads(raw)['local_files']:
  assert sha((r/f['path']).read_bytes())==f['sha256'];assert not f['placeholder_tokens'];seen[f['path']]=f
assert len(seen)==idx['unique_local_files']
q=dict(recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),canonical_total=len(canon),full_graph_nodes=len(nodes),full_graph_edges=len(edges),old_canonical_unchanged=3546,new_canonical=143,all_old_edges_exact=True,coverage_prior_exact=True,source_claims=62,aliases_not_extra=3,selected_grades='6B/56C;completechainunknown',local_source_hashes_verified=local_count,external_annotations=external_count,canonical_citations=local_count+external_count,impact_cases=cases,code_config_experiment_files_unchanged=len(unchanged),formal_index_unique_files=len(seen),formal_index_unique_declarations=idx['unique_declarations'],new_numerical_run=False,new_candidate=0,new_initial_check=0,math_redeployed=False)
(o/'integrity.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps({k:v for k,v in q.items() if k!='impact_cases'}))
