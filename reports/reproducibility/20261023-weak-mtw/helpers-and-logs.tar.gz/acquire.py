from pathlib import Path
import json,hashlib,urllib.request,datetime
R=Path('/private/tmp/ai-paper-WP107'); logs=[]
works=[('FGR2015','https://gallouet.github.io/MTWCLNF.pdf'),('CEMS2001','https://www.math.toronto.edu/mccann/papers/cms.pdf'),('CIL1992v1','https://arxiv.org/pdf/math/9207212v1'),('FKM2013','https://people.math.ethz.ch/~afigalli/papers-pdf/Holder-continuity-and-injectivity-of-optimal-maps.pdf')]
total=0
for key,url in works:
 p=R/(key+'.pdf')
 rec={'id':key,'url':url,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tls':'normal verified TLS'}
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'ai-paper-source-audit/1.0'})
  with urllib.request.urlopen(req,timeout=25) as f:
   b=f.read(8388609-total);rec['final_url']=f.url
  assert b.startswith(b'%PDF') and total+len(b)<=8388608
  p.write_bytes(b);total+=len(b);rec.update(status='acquired',bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),path=str(p))
 except Exception as e:rec.update(status='failed',error=repr(e))
 logs.append(rec);(R/'acquisition.json').write_text(json.dumps({'works_cap':4,'bytes_cap':8388608,'total_downloaded_bytes':total,'items':logs},indent=2)+'\n');print(json.dumps(rec),flush=True)
