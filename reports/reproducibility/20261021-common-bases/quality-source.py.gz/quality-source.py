from pathlib import Path
import json,gzip,hashlib,sys,datetime,xml.etree.ElementTree as ET,tempfile,shutil,subprocess,os
r=Path('/Users/smzdm/projects/ai_paper');sys.path.insert(0,str(r/'src'))
from ai_value.graph import load,validate
out=r/'reports/reproducibility/20261021-common-bases';now=datetime.datetime.now(datetime.timezone.utc).isoformat();nodes,edges=load(r);v=json.loads(gzip.decompress((r/'reports/graph/knowledge.json.gz').read_bytes()));tree=ET.fromstring(gzip.decompress((r/'reports/graph/knowledge.graphml.gz').read_bytes()));ns={'g':'http://graphml.graphdrawing.org/xmlns'}
assert {n['id'] for n in v['nodes']}==set(nodes)=={n.attrib['id'] for n in tree.findall('.//g:node',ns)}
assert {e['id'] for e in v['edges']}=={e['id'] for e in edges}=={e.attrib['id'] for e in tree.findall('.//g:edge',ns)}
assert len({e['id'] for e in edges})==len(edges)
assert all(e['source'] in nodes and e['target'] in nodes for e in edges)
assert all(e.attrib['source'] in nodes and e.attrib['target'] in nodes for e in tree.findall('.//g:edge',ns))
files={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in (r/'reports/graph').iterdir() if p.is_file()}
q={'recorded_at':now,'core_tests_passed':42,'validation':validate(r),'full_graph_and_gzip_exports_consistent':True,'edge_ids_unique':True,'endpoints_valid':True,'files':files,'browser_visual_check':'not repeated;viewer logic unchanged','local_Lean_or_Comparator':False,'remote_CI':False}
(out/'graph-export.json').write_text(json.dumps(q,indent=2)+'\n')

# Check the actual reading ranges/source bytes and all historical version snapshots.
sha=lambda b:hashlib.sha256(b).hexdigest()
j=json.loads((r/'data/provenance/readings/F-114.json').read_text())
for f in j['full_read_files']+j['formal_selected_read_files']:assert sha((r/f['path']).read_bytes())==f['sha256']
idx=json.loads(gzip.decompress((r/j['formal_index']['path']).read_bytes()))
for f in idx['local_files']:assert sha((r/f['path']).read_bytes())==f['sha256']
old=json.loads(gzip.decompress((r/'data/graph/history/GEN-20261021-037-before.json.gz').read_bytes()))['records']
head=subprocess.run(['git','show','HEAD:data/graph/nodes.jsonl'],cwd=r,capture_output=True,text=True,check=True)
prior={n['id']:n for n in map(json.loads,head.stdout.splitlines())}
for n in old:
 if n['id'] in prior:assert n==prior[n['id']]
 else:
  assert n['version']==1
  if n['id']=='APP-114-01':assert not n['properties']['run_ids']
  else:assert n['id'].startswith('CLM-114-') and n['properties']['statement']==n['properties']['statement_tex']
from ai_value.source_results import named_results
analysis=nodes['ANALYSIS-F-114']['properties'];found=[]
for path,mapping in analysis['result_ids_by_source'].items():
 for z in named_results((r/path).read_text()):
  id=mapping[z['label']];assert nodes[id]['properties']['natural_label']==z['label'];found.append(id)
assert len(found)==37
(out/'source-and-history-integrity.json').write_text(json.dumps(dict(natural_files=11,natural_lines=5371,qualified_bindings=len(found),selected_formal_files=4,formal_file_reading='Specified ranges only of26126linefile',indexed_files=1,index_declarations=2963,source_hashes_match=True,prior_nodes_match_HEAD=5,new_candidate_v1_repair_preserved=True,new_claim_v1_readability_records_preserved=37,Lean_or_Comparator_built=False),indent=2)+'\n')
archive_receipts=[]
for d in sorted((r/'experiments/runs').iterdir()):
 if not (d/'manifest.json').exists():continue
 m=json.loads((d/'manifest.json').read_text())
 for name,h in m['outputs'].items():assert sha((d/name).read_bytes())==h
 for name,detail in m.get('compressed_payloads',{}).items():assert sha(gzip.decompress((d/name).read_bytes()))==detail['uncompressed_sha256']
 snapshot=json.loads(gzip.decompress((d/'inputs.json.gz').read_bytes()))
 for name,text in snapshot.items():assert sha(text.encode())==m['inputs'][name]
 archive_receipts.append(dict(run_id=m['run_id'],compressed_output_hashes_match=True,decompressed_payload_hashes_match=True,all_source_snapshot_hashes_match=True))
assert len(archive_receipts)==12
(out/'all-twelve-archives-integrity.json').write_text(json.dumps(dict(recorded_at=now,archives=archive_receipts,actual_experiments_rerun=False),indent=2)+'\n')

with tempfile.TemporaryDirectory(prefix='ai-paper-cleancommonbases-') as td:
 dest=Path(td)
 for directory in ['src','tests','scripts','configs','schemas','data','experiments']:
  if (r/directory).exists():shutil.copytree(r/directory,dest/directory,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
 for n in nodes.values():
  for s in n.get('sources',[]):
   path=s.get('path','')
   if path and not path.startswith('math/'):
    target=dest/path;target.parent.mkdir(parents=True,exist_ok=True)
    if not target.exists():shutil.copy2(r/path,target)
 for d in ['reports/cards','reports/families','reports/failures','state']:(dest/d).mkdir(parents=True,exist_ok=True)
 assert not (dest/'math').exists()
 env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1');result=subprocess.run([sys.executable,'scripts/check.py'],cwd=dest,env=env,capture_output=True,text=True)
 clean={'recorded_at':now,'upstream_clone_present':False,'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr,'cleanup':'TemporaryDirectory removed;minimal referenced files and sources,no upstream clone','remote_CI':False}
(out/'clean-directory.json').write_text(json.dumps(clean,indent=2)+'\n');assert result.returncode==0,result.stderr[-1000:]
print(json.dumps({'nodes':len(nodes),'edges':len(edges),'clean_checks':clean['exit_code'],'temporary_copy_removed':True}))
