from pathlib import Path
import json,gzip,copy,datetime,hashlib
r=Path('/Users/smzdm/projects/ai_paper');now=datetime.datetime.now(datetime.timezone.utc).isoformat()
brief={
'matroid:thm:main':'两个显式等秩拟阵的共同基数存在相对误差FPRAS，零计数每次返回零，预言机与外部比特成本逐次多项式有界。',
'matroid:thm:BH':'齐次Tutte多项式具有Lorentzian性质，所需导数与非负线性代换保持至多一个正方向。',
'matroid:lem:coefficient':'每个部分横截面下，双缺陷总量满足4c_ij c_ji≤z²，三缺陷满足c_ij c_jk≤z c_ik。',
'matroid:lem:transport':'两个缺失单槽的加权均值差平方由单元素交换能量控制，系数含两个端点倒数及全部双孔辅助总量。',
'matroid:lem:transversalvariance':'良好乘子下，横截面条件方差至多n(1+8n)倍的未归一化能量/c0。',
'matroid:lem:defecttransfer':'每个缺陷均值可连接至质量至少1/4的两对固定横截面事件，其偏差由(8+32n)D/c0控制。',
'matroid:prop:observable':'保留每个横截面值、只保留缺陷类均值的投影，满足常数2000n^6的Poincare方差界。',
'matroid:lem:timeaverages':'指定投影观测量在U暖起点下，N次连续时间平均的均方误差至多2U Kobs Var/N。',
'matroid:lem:trace':'横截面迹链可逆、惰性且逆谱隙至多18n^4；U暖起点每次返回的期望底层成本至多5Un²。',
'matroid:cor:intersection':'不同秩拟阵的指定、全部和最大基数共同独立集可近似计数，并作逐次可行的TV误差采样。',
'integer:thm:main':'两个精确秩值预言机的共同整数基可按向量计一次作FPRAS，成本依赖二进制容量位长。',
'integer:prop:oracle-tools':'精确次模最小化以及有理强分离到精确优化的转换具有指定预言机和比特界，包括低维多面体。',
'integer:lem:base-calculus':'次模基多面体满足贪心支撑、Minkowski和、平移反射、分区投影及根方向线段恒等式。',
'integer:lem:expansion-matroid':'整数多拟阵的有标签容量展开满足拟阵公理，子集秩为min_A[r(A)+v(E\\A)]。',
'integer:lem:polyhedral-controls':'两基交集或单基加分区总量的系统具有整性、按违反量控制的距离界，以及整数的正目标斜率。',
'integer:lem:center':'精确优化和单纯形行列式替换产生有理中心，控制所有非负仿射松弛的最大值。',
'integer:lem:balanced-summation':'严格正的完整盒切片上，等容量坐标对的平衡求和与固定坐标保持相应整数二次签名。',
'integer:lem:rank-signatures':'一致方向的分组秩惩罚及不相交坐标因子的非负幂，满足添加和删除的归一化PSD测试。',
'integer:prop:shift-logconcavity':'两个整数基的差计数，沿任意e_j-e_k整数方向有区间正支撑并满足全局对数凹插值。',
'integer:lem:generator-prefixes':'次模松弛的有限生成集可排序其原子，使前缀松弛与各原子总量变化受生成集界控制。',
'integer:lem:partitions':'可用受限次模最小化计算细分块和superblocks，细分块包含于后者，并取得相容的反向前缀序。',
'integer:lem:shift-average':'指定小星形平移的基对计数接近零平移计数；归一化几何或Gaussian平均保持相对近似。',
'integer:lem:refinement-witnesses':'固定superblock整数总量后，存在有限终端细分及近中心见证，同时具备终端和细分块松弛。',
'integer:prop:expansion':'沿所构造细分块根方向扩张后的共同基数，在原计数与exp(20N^-8)倍原计数之间。',
'integer:lem:tree-coordinates':'二部关联图的生成树消元给出端口/自由坐标与代表边差基对之间的整数一一对应。',
'integer:lem:port-penalties':'反向前缀的秩惩罚和硬端口条件控制全部秩违反；小惩罚保证属于指定扩张基。',
'integer:lem:smooth-derivatives':'六重均匀卷积后的积分对数为C3凹函数，其二、三阶导数有统一的尺度界。',
'integer:lem:block-signatures':'平滑、严格曲率和一致方向的失衡因子使每个s∈[0,1]幂次同时满足两个离散签名测试。',
'integer:prop:port-model':'构造完整正短端口切片，其所有退火幂有两个签名，平衡质量在exp(±100N^-7)内近似JZ。',
'integer:lem:weight-bounds':'所有端口权重与积分具有不依赖容量数值的对数幅度界，定义系数及预言机求值具有多项式位长。',
'integer:lem:volume-lift':'指数积分可近似为显式高维有理凸多面体体积，具精确分离和内外球保证。',
'integer:prop:weight-evaluator':'体积近似经截断、正值回退、裁剪及放大得到逐次有界正有理权重求值器，并确定性近似J。',
'integer:lem:counting-lifts':'两个阶乘修正分别给遗漏/添加签名，在横截面相同并精确消掉重数，在实际缺陷类内可比较。',
'integer:prop:counting-transport':'满足完整双签名接口的两权重模型继承伴随稿的输运、投影方差、观测均方误差与迹链控制。',
'integer:lem:counting-initialization':'幂次相邻权重比在1/2到1内；初始横截面和缺陷总量可精确计算，并给出精确初始采样法。',
'integer:prop:counting-reference':'每阶段新起点的带上限参考退火以至少1-1/50概率保持良好乘子，并控制计数比积的误差。',
'integer:lem:counting-bits':'有限公平位实现可与参考路径耦合，且所有失败历史的预言机、比特与输出长度均有确定多项式界。'}
p=r/'data/graph/nodes.jsonl';nodes=[json.loads(l)for l in p.read_text().splitlines()];index={n['id']:n for n in nodes};mapping=index['ANALYSIS-F-114']['properties']['result_ids_by_label'];assert set(mapping)==set(brief)
archive=r/'data/graph/history/GEN-20261021-037-before.json.gz';history=json.loads(gzip.decompress(archive.read_bytes()));old=[]
for key,id in mapping.items():
 n=index[id];assert n['version']==1 and n['properties']['statement']==n['properties']['statement_tex'];old.append(copy.deepcopy(n));n['properties']['statement']=brief[key];n.update(version=2,updated_at=now,prior_version_archive=str(archive.relative_to(r)),updated_by_generation_id='GEN-20261021-037')
history['records']+=old;archive.write_bytes(gzip.compress((json.dumps(history,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0));assert json.loads(gzip.decompress(archive.read_bytes()))['records'][-37:]==old
p.write_text(''.join(json.dumps(n,ensure_ascii=False,sort_keys=True)+'\n'for n in nodes))
out=r/'reports/reproducibility/20261021-common-bases';(out/'claim-readability-repair.json').write_text(json.dumps(dict(reason='Derived Markdown table inspection found multiline raw TeX breaking table rows; replace display statement by concise factual summary while exact statement_tex/sourceconditions/sources/grades unchanged',claims=37,prior_versions_preserved=True,math_or_experiment_status_changed=False),indent=2)+'\n')
print('37 display summaries repaired; exact source statements and v1 records preserved')
