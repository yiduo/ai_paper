from pathlib import Path
from collections import Counter,defaultdict
import gzip,hashlib,json,h5py
r=Path('/Users/smzdm/projects/ai_paper');t=Path('/private/tmp/ai-paper-F094-metadata');p=json.loads(gzip.decompress((t/'profile-ordered.json.gz').read_bytes()));spec=json.loads((r/'configs/data-admission/APP09402-metadata-v1.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest();cols={}
with h5py.File(t/'PapalexiSatija2021_eccite_arrayed_protein.h5ad','r') as f:
 for name in spec['target_fields']:
  x=f[name]
  if isinstance(x,h5py.Group):
   categories=[v.decode('utf8') for v in x['categories'][()].tolist()];code=x['codes'][()].tolist();values=[None if k==-1 else categories[k] for k in code]
  else:values=[v.decode('utf8') for v in x[()].tolist()]
  assert sha(json.dumps(values,ensure_ascii=False,separators=(',',':')).encode())==p['fields_decoded'][name]['decoded_values_sha256'];cols[name]=values
 matrix=[[0.0]*4 for _ in range(8984)];data=f['X/data'][()].tolist();indices=f['X/indices'][()].tolist();pointer=f['X/indptr'][()].tolist()
 for j in range(4):
  for k in range(pointer[j],pointer[j+1]):matrix[indices[k]][j]=data[k]
 groups=defaultdict(list)
 for i,row in enumerate(matrix):groups[tuple(row)].append(i)
 assert len(groups)==p['exact_feature_groups']==8936
 conflicts={}
 for name in ['obs/perturbation','obs/guide_id']:
  rows=error=group_count=0
  for indices in groups.values():
   labels=Counter(cols[name][i] for i in indices if cols[name][i] is not None)
   if len(labels)>1:group_count+=1;rows+=len(indices);error+=sum(labels.values())-max(labels.values())
  expected=p['duplicate_label_profiles'][name];assert (group_count,rows,error)==tuple(expected[k] for k in ['conflicting_duplicate_groups','rows_in_conflicting_groups','empirical_minority_rows']);conflicts[name]=dict(groups=group_count,rows=rows,minority=error)
 control_nperts_mismatches=sum((v=='control')!=(int(n)==0) for v,n in zip(cols['obs/perturbation'],f['obs/nperts'][()].tolist(),strict=True));assert control_nperts_mismatches==0
 guide_hto=Counter(zip(cols['obs/guide_id'],cols['obs/hto'],strict=True));by_guide=defaultdict(set)
 for (g,h),n in guide_hto.items():by_guide[g].add(h)
 out=dict(scope='Independentplain-Python tuples/grouping andrawbytescategoricalreconstruction;no compression or biologicalvalidation',all14decoded_columnhashes_match=True,featuregroups=len(groups),conflicts=conflicts,cell_ids_unique=len(set(cols['obs/_index'])),control_and_zero_nperts_mismatches=control_nperts_mismatches,guide_hto_counts=[dict(guide=g,hto=h,cells=n) for (g,h),n in sorted(guide_hto.items())],guides_with_multiple_hto_labels=sum(len(v)>1 for v in by_guide.values()),reader_independence='SamepinnednativeHDF5decoder;independentaggregation/columnreconstruction,not asecondHDF5implementation or independentbiologicalgroundtruth',new_application_run=False)
raw=(json.dumps(out,ensure_ascii=False,indent=2)+'\n').encode();packed=gzip.compress(raw,mtime=0);assert gzip.decompress(packed)==raw;(t/'independent.json.gz').write_bytes(packed);print(json.dumps(out))
