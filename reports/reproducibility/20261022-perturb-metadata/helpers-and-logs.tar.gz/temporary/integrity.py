from pathlib import Path
import subprocess,json,gzip,hashlib,datetime,sys
r=Path('/Users/smzdm/projects/ai_paper');sys.path.insert(0,str(r/'src'))
from ai_value.graph import load,impact_report,theoretical_grade
o=r/'reports/reproducibility/20261022-perturb-metadata';sha=lambda x:hashlib.sha256(x).hexdigest()
before=subprocess.check_output(['git','show','HEAD:data/graph/nodes.jsonl'],cwd=r).decode().splitlines();after=(r/'data/graph/nodes.jsonl').read_text().splitlines();a={json.loads(l)['id']:l for l in before};b={json.loads(l)['id']:l for l in after};changed=['APP-094-02','ASSET-094-PAPALEXI-PROTEIN','PART-094-PERTURB-SEMANTICS-GATE'];assert len(a)==3530 and len(b)==3538;assert all(a[k]==b[k] for k in a if k not in changed)
prior=json.loads(gzip.decompress((r/'data/graph/history/GEN084-perturb-metadata-before.json.gz').read_bytes()))['records'];p={x['id']:x for x in prior};assert all(json.loads(a[k])==p[k] for k in changed)
assert (r/'data/graph/edges.jsonl').read_bytes().startswith(subprocess.check_output(['git','show','HEAD:data/graph/edges.jsonl'],cwd=r))
paths=['experiments/plans/APP-094-02-conditional.json','data/graph/reading_coverage.json','data/provenance/demand/PapalexiSatija2021-protein-admission-profile.json','data/provenance/demand/F-094-bold-readiness.json','data/samples/perturbation/PapalexiSatija2021_eccite_arrayed_protein.h5ad.gz']
for path in paths:assert (r/path).read_bytes()==subprocess.check_output(['git','show','HEAD:'+path],cwd=r)
app=json.loads(b['APP-094-02'])['properties'];old=json.loads(a['APP-094-02'])['properties']
for field in ['prediction','run_ids','test_spec','theoretical_grade','source_claim_grade','analogy','dedup_key','application_result','workflow']:assert app[field]==old[field],field
assert app['summary']['initial_check_eligible'] is False and not app['run_ids']
nodes,edges=load(r);cases=[]
for seed,yes,no in [
 ('PART-094-ZERO-DISTANCE-BIO-GATE',['PART-094-PERTURB-SEMANTICS-GATE','APP-094-02'],['CLM-094-THM-MAIN','APP-094-01','APP-332-01']),
 ('PART-094-ANNOTATION-JUDGE-GATE',['APP-094-02'],['CLM-094-THM-MAIN','CLM-153-CLS-CLASSIFICATION']),
 ('OBS-094-READOUT-COLLISIONS',['PART-094-ZERO-DISTANCE-BIO-GATE','APP-094-02'],['CLM-094-THM-MAIN','APP-094-01']),
 ('OBS-094-ANNOTATION-GRAIN',['PART-094-ANNOTATION-JUDGE-GATE','APP-094-02'],['CLM-094-THM-MAIN','APP-094-01']),
 ('PART-094-NATIVE-STRING-READER',['CHECK-094-STRING-METADATA','ASSET-094-PAPALEXI-PROTEIN','APP-094-02'],['CLM-094-THM-MAIN','APP-332-01']),
 ('CHECK-094-METADATA-RECONCILE',[],['APP-094-02','CLM-094-THM-MAIN']),
 ('PART-094-FINITE-COMMON-LAW-GATE',['APP-094-02'],['CLM-094-THM-MAIN','CHECK-094-STRING-METADATA']),
]:
 report=impact_report(nodes,edges,{seed});affected=set(report['affected']);assert set(yes)<=affected,(seed,yes,affected);assert not set(no)&affected,(seed,no,affected);cases.append(dict(seed=seed,required=yes,excluded=no,affected=sorted(affected)))
local=external=0
for n in map(json.loads,after):
 for source in n['sources']:
  if 'path' in source:assert sha((r/source['path']).read_bytes())==source['sha256'],(n['id'],source['path']);local+=1
  else:external+=1
assert theoretical_grade(nodes,edges,'APP-094-02')=='unknown'
out=dict(recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),old_unchanged=3527,exact_prior_versions=3,new_canonical=8,new_explicit_edges=17,all_old_edges_exact=True,unchanged_source_and_plan_paths=paths,prediction_and_application_status_unchanged=True,local_source_hashes_verified=local,external_annotations=external,canonical_citations=local+external,impact_cases=cases,candidates=40,application_initials=13,effective_leads=5,new_application_run=False,full_family_or_history_promoted=False)
(o/'integrity.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:out[k] for k in ['local_source_hashes_verified','external_annotations','canonical_citations']})+';7impactcasespassed')
