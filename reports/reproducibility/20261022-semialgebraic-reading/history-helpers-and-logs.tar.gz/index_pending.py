from pathlib import Path
import json,gzip,hashlib,sys
R=Path('/Users/smzdm/projects/ai_paper');sys.path.insert(0,str(R/'src'));from ai_value.source_results import named_results
j=json.loads((R/'state/reading-progress/F-058.json').read_text());out=[];bib=[]
for f in j['files']:
 p=R/f['path'];text=p.read_text();assert hashlib.sha256(p.read_bytes()).hexdigest()==f['sha256']
 if p.suffix=='.tex':
  for r in named_results(text):out.append({'manuscript_id':'P-c3639a0ea6ca2516' if '/Semialgebraic-universal-covers-' in str(p) else 'P-797062f12750f925','path':f['path'],'sha256':f['sha256'],'kind':r['kind'],'natural_label':r['label'],'qualified_label':('U:' if '/Semialgebraic-universal-covers-' in str(p) else 'B:')+r['label'],'title_tex':r['title_tex'],'statement_lines':[text[:r['start']].count('\n')+1,text[:r['statement_end']].count('\n')+1],'result_label_aliases':r['label_aliases'],'input_output_conditions_curated':False})
import re
for f in j['files']:
 text=(R/f['path']).read_text()
 if f['path'].endswith('.bib'):
  for m in re.finditer(r'@\w+\{([^,]+),',text):bib.append({'manuscript':'U','key':m[1],'path':f['path'],'line':text[:m.start()].count('\n')+1})
 if f['path'].endswith('/bibliography.tex'):
  for m in re.finditer(r'\\bibitem(?:\[[^\]]*\])?\{([^}]+)\}',text):bib.append({'manuscript':'B','key':m[1],'path':f['path'],'line':text[:m.start()].count('\n')+1})
assert len(out)==73 and len({r['qualified_label'] for r in out})==73
payload={'family_id':'F-058','upstream_commit':j['upstream_commit'],'status':'locator inventory after actual complete body reading;manual73contracts and bibliography-work identity curation pending','results':out,'qualified_result_count':73,'counts_by_manuscript':{m:sum(r['manuscript_id']==m for r in out) for m in ['P-c3639a0ea6ca2516','P-797062f12750f925']},'bibliography_bindings':bib,'bibliography_key_occurrences':len(bib),'bibliography_keys_not_merged_to_works':True,'not_counted_as_complete_decomposition':True,'current_source_credibility_not_promoted':True}
raw=(json.dumps(payload,ensure_ascii=False,indent=2)+'\n').encode();p=R/'state/reading-progress/F-058-pending-index.json.gz';p.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(p.read_bytes())==raw
j['pending_statement_index']={'path':str(p.relative_to(R)),'raw_sha256':hashlib.sha256(raw).hexdigest(),'gzip_bytes':p.stat().st_size,'qualified_results':73,'manual_contracts_complete':False};j['status']='natural_bodies_selected_formal_original_scopes_read_canonical_decomposition_pending';(R/'state/reading-progress/F-058.json').write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'qualified_results':73,'bibliography_key_occurrences':len(bib),'index_gzip_bytes':p.stat().st_size,'manual_decomposition_complete':False},indent=2))
