from pathlib import Path
import urllib.request,json,hashlib,datetime,sys
root=Path('/private/tmp/ai-paper-WP095');out=root/'originals';out.mkdir(exist_ok=True)
sources=[('kollar-pardon-v2','https://arxiv.org/pdf/1104.2309v2'),('vey-1970','https://www.numdam.org/article/ASENS_1970_4_3_4_479_0.pdf'),('clau-hoer-kollar','https://claudon.pages.math.cnrs.fr/pdf/universal-final.pdf'),('farb-weinberger','https://annals.math.princeton.edu/wp-content/uploads/annals-v168-n3-p05.pdf')]
records=[];total=0
for key,url in sources[:1] if len(sys.argv)>1 and sys.argv[1]=='probe' else sources:
 p=out/(key+'.pdf')
 if p.exists():total+=p.stat().st_size;continue
 row={'source':key,'requested_url':url,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tls':'default verification;not disabled'}
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'ai-paper-source-scope-audit/1.0'}),timeout=25) as res:
   raw=res.read(4*1024*1024+1);assert len(raw)<=4*1024*1024;assert total+len(raw)<=8*1024*1024;assert raw.startswith(b'%PDF');p.write_bytes(raw);total+=len(raw);row.update({'final_url':res.url,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'local_path':str(p),'status':'downloaded_not_yet_read'})
 except Exception as exc:row.update({'status':'failed','error':str(exc)})
 records.append(row)
 print(json.dumps(row,ensure_ascii=False),flush=True)
 with (root/'fetch-observations.jsonl').open('a') as f:f.write(json.dumps(row,ensure_ascii=False)+'\n')
