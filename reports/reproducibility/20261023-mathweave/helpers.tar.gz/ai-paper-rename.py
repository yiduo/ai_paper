import json, subprocess, urllib.request
repo='https://github.com/yiduo/ai_paper'
p=subprocess.run(['git','-c','credential.helper=','-c','credential.helper=store','credential','fill'],input=('url='+repo+'.git\n\n').encode(),capture_output=True,timeout=15)
if p.returncode: raise SystemExit('Configured Git credential helper unavailable; no credential contents displayed')
credential=dict(x.split('=',1) for x in p.stdout.decode().splitlines() if '=' in x)
assert credential.get('password'), 'No configured credential'
req=urllib.request.Request('https://api.github.com/repos/yiduo/ai_paper',data=json.dumps({'name':'mathweave','description':'MathWeave: connecting mathematical results, historical methods, and testable applications through an evidence graph.'}).encode(),headers={'Authorization':'Bearer '+credential['password'],'Accept':'application/vnd.github+json','User-Agent':'MathWeave-publication','Content-Type':'application/json'},method='PATCH')
with urllib.request.urlopen(req,timeout=40) as r: d=json.load(r)
print(json.dumps({k:d.get(k) for k in ['id','name','full_name','html_url','clone_url','private','default_branch']},indent=2))
assert d['id']==1429150108 and d['full_name']=='yiduo/mathweave' and d['private'] is False
