from pathlib import Path
import sys,json,datetime,hashlib
R=Path('/Users/smzdm/projects/ai_paper');p=R/'state/reading-progress/F-239.json';j=json.loads(p.read_bytes());prefix=sys.argv[1];rels=sys.argv[2].split(',');note=sys.argv[3];m=next(m for m in j['manuscripts'] if ('biased-' in m['readme']['path'])==(prefix=='biased'));seen=[]
for rel in rels:
 f=next(f for f in m['files'] if f['path'].endswith('/'+rel));assert hashlib.sha256((R/f['path']).read_bytes()).hexdigest()==f['sha256'];f['actually_read']=True;j['actual_read_ranges'][f['path']]=[[1,f['lines']]];seen.append(f['path'])
j['reading_notes'].append({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manuscript_id':m['id'],'source_files':seen,'note':note});j['at']=datetime.datetime.now(datetime.timezone.utc).isoformat();p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n');print('Recorded',prefix,len(rels),'fullfiles,totalread',len(j['actual_read_ranges']))
