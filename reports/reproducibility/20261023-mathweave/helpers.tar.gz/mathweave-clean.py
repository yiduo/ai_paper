from pathlib import Path
import subprocess,tempfile,tarfile,io,os,shutil,json,gzip,hashlib,datetime
root=Path('/Users/smzdm/projects/ai_paper'); tree=Path('/private/tmp/mathweave-tree.txt').read_text().strip()
copy=Path(tempfile.mkdtemp(prefix='mathweave-clean-',dir='/private/tmp'))
archive=subprocess.check_output(['git','archive',tree],cwd=root)
with tarfile.open(fileobj=io.BytesIO(archive)) as t:
 assert all(not x.name.startswith(('math/','../','/')) for x in t.getmembers()); t.extractall(copy,filter='data')
assert not (copy/'math').exists()
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PATH='/Users/smzdm/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:'+os.environ['PATH'])
log=Path('/private/tmp/mathweave-clean.log')
with log.open('wb') as f:r=subprocess.run(['/Users/smzdm/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3','scripts/check.py'],cwd=copy,env=env,stdout=f,stderr=subprocess.STDOUT)
receipt=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),tree=tree,math_present=False,exit_code=r.returncode,tracked_tree_bytes=len(archive),scope='Exact staged science/docs snapshot, no upstream math;69core tests plus validation/report/provenance; no new science or Lean proof')
p=root/'reports/reproducibility/20261023-mathweave/no-math-clean.json.gz';raw=json.dumps(receipt,indent=2).encode();p.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(p.read_bytes())==raw
if r.returncode==0:shutil.rmtree(copy)
else:receipt['retained_failure_directory']=str(copy)
print(json.dumps(receipt));raise SystemExit(r.returncode)
