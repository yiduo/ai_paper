import urllib.request,json,hashlib,pathlib,datetime
T=pathlib.Path('/private/tmp/ai-paper-WP099');p=T/'acquisition.json';state=json.loads(p.read_text()) if p.exists() else {'limit_bytes':8388608,'original_works_limit':4,'downloaded_bytes':0,'requests':[]}
for name,url in [('Mineyev-revised2026.pdf','https://mineyev.web.illinois.edu/art/top-geom-uzd-origami.pdf'),('GargMineyev2025v2.pdf','https://arxiv.org/pdf/2501.07646v2'),('Shin2026v1.pdf','https://arxiv.org/pdf/2607.01716v1'),('Gardam2021v4.pdf','https://arxiv.org/pdf/2102.11818v4')]:
 if any(x.get('name')==name and x.get('status')==200 for x in state['requests']):continue
 r={'name':name,'url':url,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'ai-paper-source-research'})
  with urllib.request.urlopen(req,timeout=40) as resp:
   limit=state['limit_bytes']-state['downloaded_bytes'];b=resp.read(limit+1);assert len(b)<=limit,'Total8MiB budget exceeded';assert b.startswith(b'%PDF'),'Not a PDF';(T/name).write_bytes(b);state['downloaded_bytes']+=len(b);r.update(status=resp.status,final_url=resp.geturl(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
 except Exception as e:r['error']=type(e).__name__+': '+str(e)
 finally:state['requests'].append(r);p.write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(r))
