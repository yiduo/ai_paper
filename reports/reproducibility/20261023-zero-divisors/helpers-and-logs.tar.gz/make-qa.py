from pathlib import Path
p=Path('/private/tmp/ai-paper-WP099/qa.py');s=p.read_text().replace('ai-paper-WP098','ai-paper-WP099').replace('20261023-group-guard','20261023-zero-divisors')
a=s.index("nodes,edges=load(R)");b=s.index('ex=export(R)')
s=s[:a]+'''nodes,edges=load(R);cases=[];main='CLM-196-THM-MAIN';gate='PART-196-FINITE-WITNESS-GATE'
def check(n,seed,yes,no):
 hit=affected_nodes(nodes,edges,set(seed));assert set(yes)<=hit,(n,'missing',set(yes)-hit);assert not(set(no)&hit),(n,'false',set(no)&hit);cases.append({'name':n,'changed':seed,'expected_review':yes,'expected_unaffected':no,'affected':sorted(hit),'pass':True})
check('entropy_reaches_main',['CLM-196-PROP-BOUNDED-PATTERN'],[main,gate],['CLM-256-N-THM-MAIN'])
check('planar_separation_is_required',['LIT-196-LIPTONTARJAN1979'],['CLM-196-LEM-PLANAR-SEPARATION',main,gate],['APP-256-01'])
check('topology_background_required',['LIT-200-00F68475E7'],['CLM-196-LEM-PICTURES',main,gate],[])
check('cohomology_background_required',['LIT-196-BROWN1982'],['CLM-196-COR-TORSION-FREE',main,gate],['CLM-196-PROP-BOUNDED-PATTERN'])
check('unit_context_not_zero_divisor_proof',['LIT-196-GARDAM2021'],['CHECK-196-UNIT-VS-ZERO-DIVISOR'],[main,gate])
check('old_taiko_context_not_new_proof',['LIT-196-MINEYEV2024'],['CHECK-196-TAIKO-ROUTE-SCOPE'],[main,gate])
check('taiko_negative_scope',['LIT-196-SHIN2026'],['CHECK-196-TAIKO-ROUTE-SCOPE'],[main,gate])
check('root_nonzero_separate_from_parity',['PART-196-ROOT-COEFFICIENT'],[main,gate],['PART-196-PARITY-PRODUCT'])
check('cross_family_context_not_required',['F-256'],[],[main,gate])
check('unqualified_demand_not_source_proof',['PROB-196-CONCRETE-GROUP-RING-FIXTURE'],[],[main,gate])
check('F256_old_admission_preserved',['LIT-256-GAP-FP-INTERFACE'],['APP-256-01'],[main])
check('F058_QE_preserved',['LIT-058-QEPCAD-INTERFACE'],['APP-058-01'],[main])
assert theoretical_grade(nodes,edges,main)=='unknown'
write('impact.json.gz',{'cases':cases,'count':len(cases),'main_dependency_grade':'unknown','meaning':'Review routing,not theorem rejection/build/human or application validation'})
'''+s[b:]
a=s.index('oldraw=subprocess.check_output');s=s[:a]+'''oldraw=subprocess.check_output(['git','show','5684692:data/graph/nodes.jsonl'],cwd=R);olded=subprocess.check_output(['git','show','5684692:data/graph/edges.jsonl'],cwd=R)
newraw=(R/'data/graph/nodes.jsonl').read_bytes();assert newraw.startswith(oldraw) and (R/'data/graph/edges.jsonl').read_bytes().startswith(olded)
old={json.loads(l)['id']:json.loads(l) for l in oldraw.splitlines()};new={json.loads(l)['id']:json.loads(l) for l in newraw.splitlines()};assert len(old)==4133 and len(new)-len(old)==59
assert all(new[k]==v for k,v in old.items())
assert not subprocess.check_output(['git','diff','--name-only','5684692','--','src','tests','experiments'],cwd=R,text=True).strip()
write('canonical-preservation.json.gz',{'base':'5684692','all_old_records_exact':len(old),'old_node_and_edge_bytes_prefix_exact':True,'experimental_code_specs_runs_tests_unchanged':True,'new_records':len(new)-len(old),'human_reviews':0,'second_provider_reviews':0,'new_application_experiments':0})
ledger=json.loads((R/'data/provenance/readings/F-196.json').read_text())
for f in ledger['read_files']+ledger['formal_actual_files']:assert sha((R/f['path']).read_bytes())==f['sha256']
for h in ledger['historical_works'].values():assert sha((T/h['local']).read_bytes())==h['sha256']
for pix in ledger['actual_pdf_pixels']:
 print('pixel_receipt',pix)
write('source-contracts.json.gz',{'natural_tex_files':8,'natural_tex_lines':1453,'results':12,'methods':19,'formal_selected_files':13,'main_definition_match':ledger['formal_definition_block_match_ignoring_comments_whitespace'],'historical_originals_scoped':4,'original_version_and_byte_hashes_verified':True,'actual_pixels':8,'new_download_bytes':ledger['acquisition']['downloaded_bytes'],'new_witness_or_benchmark':False,'human_reviews':0,'second_provider_reviews':0})
print(json.dumps({'nodes':len(nodes),'edges':len(edges),'canonical_records':len(new),'impact_cases':len(cases),'archives':len(archives),'source_members':members,'old_record_preservation':True}))
'''
s=s.replace('WP098 qualification','WP099 source reading');p.write_text(s)
p=Path('/private/tmp/ai-paper-WP099/clean-check.py');p.write_text(p.read_text().replace('ai-paper-WP098','ai-paper-WP099').replace('20261023-group-guard','20261023-zero-divisors').replace('WP098','WP099'))
