from pathlib import Path
import json,gzip,hashlib,sys,re
R=Path('/Users/smzdm/projects/ai_paper');T=Path('/private/tmp/ai-paper-WP099');O=R/'reports/reproducibility/20261023-zero-divisors';sys.path.insert(0,str(R/'src'))
from ai_value.source_results import named_results
sha=lambda b:hashlib.sha256(b).hexdigest()
L=json.loads((R/'data/provenance/readings/F-196.json').read_text());assert len(L['formal_actual_files'])==13
for p in L['actual_pdf_pixels']:
 assert sha(Path(p['source']).read_bytes())==p['source_sha256'];assert sha(Path(p['image']).read_bytes())==p['image_sha256'];assert p['pixels_actually_viewed']
obs={}
for f in L['read_files']:
 b=(R/f['path']).read_bytes();assert sha(b)==f['sha256'];assert len(b.splitlines())==f['lines']
 if f['path'].endswith('.tex'):
  for x in named_results(b.decode()):obs[x['label']]=f['path']
assert obs=={x['label']:x['path'] for x in L['results']}
idx=json.loads(gzip.decompress((R/L['static_index']).read_bytes()));print('index_summary',{k:v for k,v in idx.items() if not isinstance(v,(dict,list))})
sources=[s for n in (json.loads(l) for l in (R/'data/graph/nodes.jsonl').read_text().splitlines()) for s in n['sources']]
summary={'all_canonical':len(sources),'local':sum('path'in s for s in sources),'external':sum('url'in s for s in sources),'external_without_byte_hash':sum('url'in s and not s.get('sha256') for s in sources),'pixels':8,'natural_result_source_bindings_exact':12,'read_file_hashes_and_line_counts_exact':True,'formal_selected_scope_files':13,'literal_main_definition_match':True,'no_Lean_or_Comparator_run':True,'no_math_mutation':True}
b=(json.dumps(summary,indent=2)+'\n').encode();z=gzip.compress(b,mtime=0);assert gzip.decompress(z)==b;(O/'source-scope-and-pixels.json.gz').write_bytes(z);print(json.dumps(summary))
