from pathlib import Path
import json,gzip,hashlib,tarfile,io,datetime,subprocess,shutil
R=Path('/Users/smzdm/projects/ai_paper');T=Path('/private/tmp/ai-paper-WP099');O=R/'reports/reproducibility/20261023-zero-divisors';now=datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda b:hashlib.sha256(b).hexdigest()
def write(p,j):(R/p).write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
clean=json.loads(gzip.decompress((O/'no-math-clean-directory.json.gz').read_bytes()));assert clean['exit_code']==0 and not clean['upstream_math_present'];assert not (T/'no-math-clean').exists()
core=(T/'core.log').read_text();assert 'Ran 68 tests' in core and '\nOK\n' in core
assert subprocess.check_output(['git','-C','math','rev-parse','HEAD'],cwd=R,text=True).strip()=='1581d4cbdd69a0faf34b2089614fe2a814316a6a';assert not subprocess.check_output(['git','-C','math','status','--porcelain'],cwd=R,text=True).strip()
assert sha((R/'722篇AI数学论文应用价值挖掘纲领.md').read_bytes())=='96fad398177fc3a54a87c07867456c5d84e66a7d538500b00ca4797d0a749c6e'
raws=[p for p in T.iterdir() if p.is_file() and p.suffix in {'.pdf','.txt','.png'}];rawmeta=[{'name':p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'retention':'Removed after source/version/page/image provenance was recorded;no external original text redistributed'} for p in sorted(raws)]
ledger=json.loads((R/'data/provenance/readings/F-196.json').read_text())
for h in ledger['historical_works'].values():assert sha((T/h['local']).read_bytes())==h['sha256']
for p in ledger['actual_pdf_pixels']:assert sha(Path(p['image']).read_bytes())==p['image_sha256']
helpers=[p for p in T.iterdir() if p.is_file() and p not in raws];assert all(p.suffix in {'.py','.log','.json'} for p in helpers)
mem={p.name:p.read_bytes() for p in helpers};buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as tar:
 for n,b in sorted(mem.items()):
  inf=tarfile.TarInfo(n);inf.size=len(b);inf.mtime=0;inf.mode=0o644;tar.addfile(inf,io.BytesIO(b))
b=buf.getvalue();packed=gzip.compress(b,mtime=0);assert gzip.decompress(packed)==b
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(packed)),mode='r:') as tar:
 assert set(tar.getnames())==set(mem)
 for n,v in mem.items():assert tar.extractfile(n).read()==v
archive=O/'helpers-and-logs.tar.gz';archive.write_bytes(packed);assert gzip.decompress(archive.read_bytes())==b
storage={'at':now,'temporary_root':str(T),'downloaded_original_pdf_bytes':2047757,'original_PDF_count':4,'temporary_raw_files':rawmeta,'temporary_raw_bytes_removed':sum(x['bytes'] for x in rawmeta),'own_archive':str(archive.relative_to(R)),'compressed_bytes':len(packed),'uncompressed_tar_bytes':len(b),'uncompressed_tar_sha256':sha(b),'compressed_sha256':sha(packed),'member_bytes':sum(len(v) for v in mem.values()),'members':{n:{'bytes':len(v),'sha256':sha(v)} for n,v in sorted(mem.items())},'all_decompressed_member_bytes_and_hashes_verified_before_plaintext_removal':True,'no_math_copy_or_install':True,'no_new_numerical_experiment_data':True,'official_math_commit_and_clean_verified':True,'root_charter_hash_unchanged':True,'external_fulltext_republished':False,'temporary_root_removed':False}
for p in raws:assert sha(p.read_bytes())==next(x['sha256'] for x in rawmeta if x['name']==p.name);p.unlink()
for p in helpers:assert p.read_bytes()==mem[p.name];p.unlink()
T.rmdir();storage['temporary_root_removed']=not T.exists();write('reports/reproducibility/20261023-zero-divisors/storage.json',storage)
quality=f'''# WP099 quality receipt

2026-10-23. Source reading and graph curation only; no new numerical/symbolic application experiment, Lean build, Comparator, human or second-provider review.

- Existing 68 core tests passed with no skips, followed by full canonical validation, regenerated reports and lossless provenance audit. Existing Python3.12.14 / bundled Node; no dependency installation.
- 59 new canonical records / 194 explicit edges. All 4,133 old canonical records and old edge bytes remain exact; experiment code, plans, runs and tests unchanged.
- Full graph: 6,863 nodes / 18,674 relations; 7,194 canonical source annotations, including 7,184 core-validated types. Local hashed annotations 6,709; external annotations without retained original text 485, of which 347 have no byte hash. Scope/version annotations are retained independently.
- Twelve mandatory/contextual dependency-impact cases passed. The selected main and every full proof chain remain unknown; context comparisons do not become mathematical premises. F058/F256 old candidate dependencies remain intact.
- JSON and GraphML full node/edge objects match graph.load. All eight natural source hashes / 12 result-source bindings, 13 actual formal file scopes, four original PDF hashes and eight actually inspected page-image hashes were verified.
- All 15 existing compressed experiment archives and 267 source-snapshot members passed output, decompression and input-member hashes. No scientific replay was needed because experimental code/specifications/data/comparators did not change; archive integrity is not new application validation.
- A clean independent directory containing {clean['files']:,} files / {clean['copied_bytes']:,} bytes, with no math directory, completed the same core/validation/report/provenance workflow with exit 0. Copied bytes were hashed; its manifest records the working-tree scope at copy time. Receipt-only later edits do not add another scientific test. The temporary clean directory was removed.
- Four original PDFs total 2,047,757 bytes. External full texts, extracted text and eight PNGs were hash-checked and removed after source/version/page/image provenance was saved. Own helpers/logs total {storage['member_bytes']:,} bytes, stored in a {len(packed):,}-byte gzip/tar; every decompressed member was checked before plaintext cleanup. Storage manifest retains exact sizes/hashes.
- Official math is clean at the pinned revision; root Chinese charter hash unchanged. No GitHub push or remote write. Work after the last verified public f0c3ddc remains local; GitHub uses meaningful milestone batches.

Current-source decomposition is a draft, not complete-family/history assurance. No actual F196 matching table or independently checkable finite zero-divisor fixture was supplied. Counts remain 43 candidates / 13 preliminary checks / 13 distinct hypotheses / five narrowly supported and eight adverse observations; real human review, separate provider, complete families and full lineages remain zero. WP100 addresses three bounded classical proof-input scopes, not an invented benchmark.
'''
(O/'quality.md').write_text(quality)
c=json.loads((R/'state/checkpoint.json').read_text());c['saved_at']=now;c['recovery_observation'].update(checkpoint_core_check='68core12impact/fullcanonical-source-FK-gates/fullJSONGraphML/15archives267members/no-math exit0;ownhelperscompressed/decompressedhashverified;temporaryrootremoved',research_processes_observation='All WP099 core/QA/no-math sessions completed;no scientific experiment or preview started',current_reading='WP099completed;WP100pending;no re-read/reacquisition necessary');c['storage_receipt']='reports/reproducibility/20261023-zero-divisors/storage.json';write('state/checkpoint.json',c)
print(json.dumps({'clean_files':clean['files'],'clean_bytes':clean['copied_bytes'],'raw_bytes_removed':storage['temporary_raw_bytes_removed'],'own_archive_bytes':len(packed),'temp_removed':not T.exists(),'github_push':False}))
