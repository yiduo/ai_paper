from pathlib import Path
import subprocess,json,hashlib
R=Path('/Users/smzdm/projects/ai_paper');T=Path('/private/tmp/ai-paper-WP099')
current=R/'math/preprints/A-Torsion-Free-Group-Algebra-with-Zero-Divisors-September-23-2026/paper.pdf'
items=[(current,1,'source-main'),(current,11,'source-alignment'),(current,23,'source-surgery'),(current,24,'source-factors'),(T/'Mineyev-revised2026.pdf',29,'Mineyev-th27'),(T/'GargMineyev2025v2.pdf',12,'Garg-T1-T4'),(T/'Shin2026v1.pdf',3,'Shin-th11'),(T/'Gardam2021v4.pdf',1,'Gardam-thA')]
rows=[]
with (T/'render.log').open('w') as log:
 for p,page,name in items:
  subprocess.run(['/opt/homebrew/bin/pdftoppm','-f',str(page),'-l',str(page),'-scale-to','1500','-singlefile','-png',str(p),str(T/name)],check=True,stdout=log,stderr=log)
  im=T/(name+'.png');b=im.read_bytes();rows.append({'source':str(p),'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'page_one_based':page,'image':str(im),'image_bytes':len(b),'image_sha256':hashlib.sha256(b).hexdigest(),'pixels_actually_viewed':False})
(T/'render-inventory.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');print('Rendered8pages;visualinspectionpending')
